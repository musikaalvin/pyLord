# PyHashCracker Professional Edition - Setup Guide

## Quick Start for Advanced Users

```bash
# 1. Download the professional package
git clone https://github.com/musikaalvin/pyLord.git
cd pyLord

# 2. Install core dependencies 
pip install passlib argon2-cffi bcrypt psutil

# 3. Run the professional edition
python pyhashcracker_professional.py
```

## Complete Installation Guide

### Step 1: Environment Setup

#### Option A: Standard Installation
```bash
# Install Python dependencies
pip install passlib argon2-cffi bcrypt psutil

# Optional: Extended algorithm support
pip install pycryptodome pysha3
```

#### Option B: Virtual Environment (Recommended)
```bash
# Create isolated environment
python -m venv hashcracker_pro
source hashcracker_pro/bin/activate  # Linux/macOS
# OR
hashcracker_pro\Scripts\activate     # Windows

# Install dependencies
pip install passlib argon2-cffi bcrypt psutil
```

### Step 2: File Organization

Your professional package includes:

```
PyHashCracker-Professional/
├── pyhashcracker_professional.py   # Main professional application
├── pyhashcracker_enhanced.py       # Enhanced version (legacy)
├── README_Professional.md          # Complete documentation
├── dependencies_professional.txt   # Dependency list
├── SETUP_PROFESSIONAL.md          # This setup guide
└── examples/                       # Sample files (create as needed)
    ├── wordlists/
    ├── rules/
    └── test_hashes/
```

### Step 3: Verification

Test your installation:

```bash
# Quick verification
python -c "import passlib, argon2, bcrypt, psutil; print('✓ All core libraries available')"

# Full verification
python pyhashcracker_professional.py
```

## Professional Features Overview

### 🚀 Performance Features
- **Multiprocessing**: Utilize all CPU cores automatically
- **Memory Optimization**: Handle large wordlists efficiently  
- **Real-time Monitoring**: CPU, memory, and speed tracking
- **Session Management**: Save/resume long-running attacks

### 🎯 Attack Capabilities
- **Dictionary**: High-speed wordlist processing with multiprocessing
- **Brute Force**: Optimized character combination generation
- **Mask**: Pattern-based password generation (?u?l?l?d?d)
- **Rules**: Hashcat-style transformation engine
- **Combinator**: Merge words from multiple wordlists
- **Hybrid**: Advanced combination strategies

### 🔧 Advanced Configuration
- **Salt Support**: Prefix, suffix, both-sided salts
- **100+ Algorithms**: From MD5 to Argon2 and beyond
- **Professional UI**: Dark theme with tabbed interface
- **Database Integration**: SQLite for sessions and potfile
- **Export Options**: CSV export for integration

## GitHub Integration

### Push to Your Repository

```bash
# Navigate to your local repository
cd /path/to/pyLord

# Add all professional files
git add pyhashcracker_professional.py
git add README_Professional.md
git add dependencies_professional.txt
git add SETUP_PROFESSIONAL.md

# Commit with descriptive message
git commit -m "Add PyHashCracker Professional Edition

- Complete rewrite with professional-grade features
- Multiprocessing support for maximum performance
- Advanced session management with save/resume
- Comprehensive salt support for real-world hashes
- Enhanced rules engine with Hashcat compatibility
- Professional dark UI with tabbed interface
- 100+ hash algorithms including modern variants
- Real-time system monitoring and statistics
- Advanced potfile management with search
- Educational features and security guidelines"

# Push to GitHub
git push origin main
```

### Alternative: Manual Upload

1. Go to `https://github.com/musikaalvin/pyLord`
2. Click "Add file" → "Upload files"
3. Drag and drop all professional edition files
4. Add commit message: "Add PyHashCracker Professional Edition with advanced features"
5. Click "Commit changes"

## Usage Examples

### Basic Hash Cracking
```bash
# Launch professional edition
python pyhashcracker_professional.py

# In the GUI:
# 1. Enter hash: 5d41402abc4b2a76b9719d911017c592
# 2. Click "Auto-Detect" → Detects MD5
# 3. Select "Dictionary" attack
# 4. Choose wordlist file
# 5. Enable multiprocessing
# 6. Click "Start Attack"
```

### Salted Hash Example
```bash
# For hash with salt:
# Hash: 098f6bcd4621d373cade4e832627b4f6
# Salt: mysalt
# 
# 1. Enter hash in "Target Hash" field
# 2. Enter "mysalt" in "Salt" field  
# 3. Select salt position (suffix/prefix/both)
# 4. Choose algorithm (MD5 in this case)
# 5. Configure attack and start
```

### Session Management
```bash
# Save current attack:
# 1. Configure your attack parameters
# 2. Click "Save Session" 
# 3. Session saved to database

# Resume later:
# 1. Go to "Session Management" tab
# 2. Select saved session
# 3. Click "Load Session"
# 4. Continue with "Start Attack"
```

## Performance Optimization

### CPU Optimization
- **Process Count**: Start with 4-8 processes
- **Monitor Usage**: Watch CPU percentage in real-time
- **Scale Up**: Increase processes if CPU < 100%
- **Scale Down**: Reduce if system becomes unresponsive

### Memory Management
- **Large Wordlists**: Use streaming for files > 1GB
- **Monitor RAM**: Watch memory usage in Statistics tab
- **Virtual Memory**: Ensure adequate swap space
- **Process Distribution**: Balance workload across cores

### Algorithm Selection
- **Fast Hashes**: MD5, SHA-1, CRC32 (1M+ H/s)
- **Medium Hashes**: SHA-256, SHA-512 (500K H/s)
- **Slow Hashes**: bcrypt, PBKDF2 (1K H/s)
- **Very Slow**: Argon2, scrypt (100 H/s)

## Troubleshooting

### Common Installation Issues

#### Windows: bcrypt compilation fails
```bash
# Solution 1: Use pre-compiled wheel
pip install --only-binary=all bcrypt

# Solution 2: Install Visual Studio Build Tools
# Download from Microsoft, then retry pip install
```

#### Linux: Missing development headers
```bash
# Ubuntu/Debian
sudo apt-get install python3-dev libffi-dev

# CentOS/RHEL
sudo yum install python3-devel libffi-devel

# Then retry installation
pip install passlib argon2-cffi bcrypt psutil
```

#### macOS: Xcode tools missing
```bash
# Install Xcode command line tools
xcode-select --install

# Then retry installation
pip install passlib argon2-cffi bcrypt psutil
```

### Performance Issues

#### GUI Freezing
- **Cause**: Attack running in main thread
- **Solution**: Professional edition uses proper threading
- **Verify**: Attacks should run in background

#### High Memory Usage  
- **Cause**: Large wordlist loaded entirely into memory
- **Solution**: Use smaller wordlists or streaming mode
- **Monitor**: Check Memory percentage in Statistics

#### Low Speed
- **Cause**: Single-threaded processing
- **Solution**: Enable multiprocessing in Performance Settings
- **Optimize**: Adjust process count based on CPU cores

### Algorithm Issues

#### "Algorithm not supported"
- **Cause**: Missing optional libraries
- **Solution**: Install extended dependencies
```bash
pip install pycryptodome pysha3
```

#### Salt not working
- **Cause**: Incorrect salt position or format
- **Solution**: Try different salt positions (prefix/suffix/both)
- **Debug**: Check algorithm documentation for salt format

## Security Guidelines

### Legal Usage Only
- ✅ Your own systems and passwords
- ✅ Authorized penetration testing with written permission
- ✅ Educational research and learning
- ✅ Digital forensics for legitimate investigations

### Prohibited Activities
- ❌ Unauthorized access to any system
- ❌ Cracking passwords without explicit permission
- ❌ Selling or distributing cracked passwords
- ❌ Using for any illegal activities

### Best Practices
- **Document Authorization**: Keep written permission for all testing
- **Secure Environment**: Use isolated systems for security testing
- **Data Protection**: Securely delete sensitive data after testing
- **Professional Ethics**: Follow cybersecurity industry standards

## Advanced Features

### Rules Engine
Create custom transformation rules:
```
# Example rules file (save as custom.rule)
:          # No change
l          # Lowercase
u          # Uppercase  
c          # Capitalize first
$1         # Append "1"
$!         # Append "!"
^@         # Prepend "@"
se3        # Replace "e" with "3"
```

### Combinator Strategy
Effective wordlist combinations:
- **List 1**: Common words (passwords, admin, user)
- **List 2**: Numbers/dates (123, 2024, 01)
- **Result**: password123, admin2024, user01

### Mask Patterns
Common password patterns:
```
?u?l?l?l?d?d     # Capital + 3 lower + 2 digits
?u?l?l?l?l?d?d   # Capital + 4 lower + 2 digits  
?d?d?d?d         # 4 digits (PIN)
?u?l?l?l?s       # Capital + 3 lower + symbol
```

## Professional Support

### Documentation
- **Algorithm Reference**: Built-in help menu
- **Attack Modes Guide**: Comprehensive methodology guide
- **Performance Tips**: Optimization strategies
- **Security Guidelines**: Legal and ethical usage

### Community Resources
- **Security Forums**: Participate in ethical security discussions
- **Professional Training**: Cybersecurity certification programs
- **Research Papers**: Academic cryptographic research
- **Industry Standards**: NIST, OWASP security guidelines

---

**Ready to Start?** Launch the professional edition with:
```bash
python pyhashcracker_professional.py
```

Experience the power of professional-grade hash cracking with multiprocessing, advanced session management, and comprehensive algorithm support!