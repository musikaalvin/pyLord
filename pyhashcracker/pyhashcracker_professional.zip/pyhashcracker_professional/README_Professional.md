# PyHashCracker Professional Edition

**The Ultimate Password Recovery and Hash Cracking Tool**

A comprehensive, professional-grade hash cracking application with advanced features including multiprocessing, session management, salted hash support, and 100+ algorithms.

![Version](https://img.shields.io/badge/version-3.0-blue.svg)
![Python](https://img.shields.io/badge/python-3.7+-green.svg)
![License](https://img.shields.io/badge/license-Educational-orange.svg)

## 🚀 Professional Features

### **Performance Enhancements**
- **Multiprocessing Support**: Utilize all CPU cores for maximum cracking speed
- **Intelligent Load Balancing**: Automatic workload distribution across processes
- **Memory-Efficient Processing**: Optimized for large wordlists and datasets
- **Real-time Progress Tracking**: ETA calculations and speed monitoring

### **Advanced Session Management**
- **Save/Resume Functionality**: Pause attacks and resume exactly where you left off
- **Session Persistence**: SQLite database stores all session data
- **Attack History**: Complete audit trail of all cracking attempts
- **Configuration Backup**: Automatic saving of attack parameters

### **Comprehensive Salt Support**
- **Multiple Salt Positions**: Prefix, suffix, and both-sided salts
- **Algorithm-Specific Salting**: Proper salt handling for each hash type
- **Real-world Hash Support**: Handle salted hashes from actual breaches
- **Salt Detection**: Automatic identification of salted hash formats

### **Advanced Attack Modes**
- **Enhanced Dictionary Attacks**: High-speed wordlist processing
- **Intelligent Brute Force**: Optimized character combination generation
- **Pattern-based Mask Attacks**: Efficient targeted password generation
- **Hashcat-style Rules Engine**: Complex password transformation rules
- **Combinator Attacks**: Merge words from multiple wordlists
- **Hybrid Methodologies**: Combine multiple attack strategies

### **Professional User Experience**
- **Modern Dark UI**: Professional interface with advanced theming
- **Tabbed Interface**: Organized workflow with dedicated sections
- **Real-time Statistics**: Live CPU, memory, and performance monitoring
- **Enhanced Potfile Management**: Searchable cracked password database
- **Comprehensive Logging**: Detailed console output with timestamps

## 🔧 Supported Hash Algorithms (100+)

### **Cryptographic Hash Functions**
| Algorithm | Output Size | Speed Class | Use Case |
|-----------|-------------|-------------|----------|
| MD5 | 128-bit | Very Fast | Legacy systems, file integrity |
| SHA-1 | 160-bit | Fast | Git commits, legacy certificates |
| SHA-224 | 224-bit | Fast | Truncated SHA-256 variant |
| SHA-256 | 256-bit | Fast | Bitcoin, SSL certificates |
| SHA-384 | 384-bit | Medium | High-security applications |
| SHA-512 | 512-bit | Medium | Server authentication |
| SHA3-224 | 224-bit | Medium | Modern cryptographic systems |
| SHA3-256 | 256-bit | Medium | Next-generation hashing |
| SHA3-384 | 384-bit | Medium | Enterprise security |
| SHA3-512 | 512-bit | Medium | Maximum security applications |

### **Password Hashing Functions**
| Algorithm | Configurable Cost | Security Level | Common Usage |
|-----------|------------------|----------------|---------------|
| bcrypt | Yes (rounds) | Very High | Web applications, Linux |
| PBKDF2-SHA256 | Yes (iterations) | High | iOS, macOS, WiFi WPA2 |
| Argon2 | Yes (memory/time) | Maximum | Modern applications |
| scrypt | Yes (memory/time) | High | Litecoin, backup encryption |
| SHA-256 Crypt | Yes (rounds) | High | Linux /etc/shadow |
| SHA-512 Crypt | Yes (rounds) | High | Modern Linux systems |

### **Windows/Microsoft Hashes**
| Algorithm | Description | Vulnerability | Speed |
|-----------|-------------|---------------|-------|
| NTLM | Windows NT hash | Moderate | Very Fast |
| LM Hash | Legacy Windows | High | Very Fast |
| MD4 | NTLM foundation | High | Very Fast |
| NetNTLMv1 | Network authentication | Moderate | Fast |
| NetNTLMv2 | Enhanced network auth | Low | Medium |

### **Database & Application Hashes**
- **MySQL**: Old password hash, MySQL 4.1+ hash
- **PostgreSQL**: MD5-based password hash
- **Oracle**: Multiple variants (10g, 11g, 12c)
- **MSSQL**: Microsoft SQL Server hashes
- **Sybase**: Sybase SQL Server hashes

### **Specialized & Legacy Algorithms**
- **CRC Family**: CRC-16, CRC-32, CRC-32B, ADLER-32
- **BLAKE2**: BLAKE2b, BLAKE2s variants
- **RIPEMD**: RIPEMD-128, RIPEMD-160, RIPEMD-256, RIPEMD-320
- **Whirlpool**: 512-bit cryptographic hash
- **Tiger**: 192-bit hash function
- **GOST**: Russian cryptographic standards
- **HAVAL**: Variable-output hash function

## ⚡ Performance Benchmarks

Performance varies by hardware and algorithm complexity:

| Algorithm Category | Typical Speed (H/s) | Multiprocessing Benefit |
|-------------------|---------------------|------------------------|
| Fast Hashes (MD5, SHA-1) | 1M - 10M+ | 4x - 8x |
| Medium Hashes (SHA-256) | 500K - 2M | 4x - 8x |
| Slow Hashes (bcrypt) | 100 - 1K | 4x - 8x |
| Memory-Hard (Argon2) | 10 - 100 | 2x - 4x |

*Benchmarks from Intel i7-8700K @ 3.7GHz with 8 logical cores*

## 📋 System Requirements

### **Minimum Requirements**
- Python 3.7 or higher
- 4GB RAM
- 1GB free disk space
- Multi-core CPU recommended

### **Recommended Setup**
- Python 3.9+ 
- 8GB+ RAM
- SSD storage
- 4+ CPU cores
- 64-bit operating system

### **Supported Platforms**
- Windows 10/11
- macOS 10.14+
- Linux (Ubuntu 18.04+, CentOS 7+, etc.)

## 🛠️ Installation & Setup

### **Quick Start**
```bash
# Clone or download the professional edition
git clone https://github.com/musikaalvin/pyLord.git
cd pyLord

# Install dependencies
pip install passlib argon2-cffi bcrypt psutil

# Run the professional edition
python pyhashcracker_professional.py
```

### **Full Installation**
```bash
# Install all dependencies including optional libraries
pip install passlib argon2-cffi bcrypt psutil pycryptodome pysha3

# Verify installation
python -c "import passlib, argon2, bcrypt, psutil; print('All libraries installed successfully')"
```

### **Virtual Environment (Recommended)**
```bash
# Create virtual environment
python -m venv hashcracker_env

# Activate virtual environment
# Windows:
hashcracker_env\Scripts\activate
# Linux/macOS:
source hashcracker_env/bin/activate

# Install dependencies
pip install -r dependencies_professional.txt
```

## 🎯 Usage Guide

### **Basic Workflow**
1. **Launch Application**: Run `python pyhashcracker_professional.py`
2. **Input Target Hash**: Enter the hash you want to crack
3. **Configure Salt** (if applicable): Add salt value and position
4. **Select Algorithm**: Use auto-detection or manual selection
5. **Choose Attack Mode**: Dictionary, brute force, mask, rules, or combinator
6. **Configure Performance**: Set multiprocessing options
7. **Start Attack**: Monitor progress with real-time statistics

### **Advanced Features**

#### **Session Management**
- **Save Sessions**: Preserve attack configuration and progress
- **Resume Attacks**: Continue interrupted attacks from last position
- **Session History**: View and manage all previous attacks

#### **Potfile Management**
- **Automatic Storage**: All cracked passwords saved automatically
- **Search & Filter**: Find specific hashes or passwords quickly
- **Export Options**: CSV export for integration with other tools
- **Duplicate Prevention**: Avoid re-cracking known passwords

#### **Performance Optimization**
- **CPU Utilization**: Monitor and optimize processor usage
- **Memory Management**: Track RAM consumption during attacks
- **Process Scaling**: Adjust worker processes for optimal performance
- **Priority Queuing**: Intelligent work distribution

## 🔒 Security Features

### **Responsible Usage**
- Built-in warnings about legal usage
- Audit trail for all activities
- Educational focus with professional capabilities
- Clear documentation of intended use cases

### **Data Protection**
- Local processing only (no cloud dependencies)
- Secure session storage with SQLite
- Memory-safe password handling
- Automatic cleanup of sensitive data

## 📊 Attack Strategies

### **Dictionary Attacks**
- **High-Quality Wordlists**: Use curated password collections
- **Multiprocessing**: Distribute wordlist across CPU cores
- **Progress Tracking**: Real-time progress with ETA calculations
- **Memory Optimization**: Efficient handling of large wordlists

### **Brute Force Attacks**
- **Character Set Selection**: Customize character combinations
- **Length Optimization**: Set minimum and maximum password lengths
- **Pattern Recognition**: Skip impossible combinations
- **Incremental Approach**: Start with shorter passwords

### **Rules-Based Attacks**
- **Hashcat Compatibility**: Support for standard rule syntax
- **Common Transformations**: Capitalization, number appending, etc.
- **Custom Rules**: Create specialized transformation rules
- **Rule Chaining**: Apply multiple transformations sequentially

### **Combinator Attacks**
- **Multi-Wordlist Support**: Combine words from different sources
- **Memory Efficiency**: Stream combinations without full memory load
- **Pattern Matching**: Identify common password construction patterns
- **Scalable Processing**: Handle large wordlist combinations

## 🎓 Educational Features

### **Learning Resources**
- **Algorithm Reference**: Comprehensive documentation of all hash types
- **Attack Guide**: Detailed explanation of each attack methodology
- **Performance Tips**: Optimization strategies for different scenarios
- **Security Insights**: Understanding password security implications

### **Practical Applications**
- **Penetration Testing**: Authorized security assessments
- **Digital Forensics**: Password recovery for legitimate investigations
- **Security Research**: Understanding hash algorithm weaknesses
- **Educational Demonstrations**: Teaching cryptographic concepts

## 🔧 Advanced Configuration

### **Multiprocessing Tuning**
```python
# Optimal process count calculation
import multiprocessing
optimal_processes = min(multiprocessing.cpu_count(), 8)
```

### **Memory Management**
- **Large Wordlists**: Streaming processing for files > 1GB
- **Batch Processing**: Process wordlists in manageable chunks
- **Memory Monitoring**: Real-time RAM usage tracking
- **Garbage Collection**: Automatic cleanup of processed data

### **Custom Rules Development**
```
# Example rule transformations
:           # Do nothing
l           # Lowercase all
u           # Uppercase all
c           # Capitalize first letter
$1          # Append "1"
^@          # Prepend "@"
se3         # Substitute "e" with "3"
```

## 📈 Performance Optimization

### **Hardware Recommendations**
- **CPU**: Modern multi-core processor (Intel i5/i7, AMD Ryzen)
- **RAM**: 8GB+ for large wordlists
- **Storage**: SSD for faster wordlist access
- **Cooling**: Adequate cooling for sustained high CPU usage

### **Software Optimizations**
- **Process Priority**: Set high priority for cracking processes
- **Background Apps**: Close unnecessary applications
- **Power Settings**: Use high-performance power plan
- **Antivirus**: Add exclusions for cracking directories

## 🛡️ Legal & Ethical Guidelines

### **Authorized Usage Only**
- **Written Permission**: Only use on systems you own or have explicit permission to test
- **Legal Compliance**: Follow all local, state, and federal laws
- **Professional Ethics**: Adhere to security industry standards
- **Responsible Disclosure**: Report vulnerabilities through proper channels

### **Prohibited Activities**
- ❌ Unauthorized access to computer systems
- ❌ Cracking passwords without permission
- ❌ Selling cracked passwords or tools for malicious use
- ❌ Violating terms of service or user agreements

## 🐛 Troubleshooting

### **Common Issues**

#### **Installation Problems**
```bash
# If passlib installation fails
pip install --upgrade pip setuptools wheel
pip install passlib

# If bcrypt compilation fails on Windows
pip install --only-binary=all bcrypt
```

#### **Performance Issues**
- **High Memory Usage**: Reduce wordlist size or use streaming mode
- **Slow Performance**: Enable multiprocessing and check CPU usage
- **GUI Freezing**: Ensure attacks are running in separate threads

#### **Algorithm Errors**
- **Missing Libraries**: Install optional dependencies for extended support
- **Salt Issues**: Verify salt format and position settings
- **Hash Format**: Confirm hash format matches selected algorithm

### **Getting Help**
- **Documentation**: Check built-in help menus and algorithm reference
- **Logs**: Review console output for detailed error messages
- **Community**: Participate in security research communities
- **Professional Support**: Consult with cybersecurity professionals

## 📝 Changelog

### **Version 3.0 - Professional Edition**
- ✅ Complete multiprocessing implementation
- ✅ Advanced session management with save/resume
- ✅ Comprehensive salt support for all algorithms
- ✅ Enhanced rules engine with Hashcat compatibility
- ✅ Professional dark UI with tabbed interface
- ✅ Real-time system monitoring and statistics
- ✅ Advanced potfile management with search
- ✅ Combinator and hybrid attack modes
- ✅ 100+ hash algorithm support
- ✅ Enhanced error handling and logging

### **Version 2.0 - Enhanced Edition**
- Added 70+ new hash algorithms
- Implemented CRC and checksum support
- Enhanced hash detection accuracy
- Added basic session functionality
- Improved GUI design and usability

### **Version 1.0 - Original**
- Basic hash support (MD5, SHA family, bcrypt)
- Dictionary and brute force attacks
- Simple GUI interface
- Rainbow table functionality

## 🤝 Contributing

This project is designed for educational and authorized security testing purposes. Contributions that enhance the educational value, improve performance, or add legitimate security testing capabilities are welcome.

### **Development Guidelines**
- Follow Python PEP 8 style guidelines
- Include comprehensive documentation
- Add unit tests for new algorithms
- Ensure backward compatibility
- Focus on educational and legitimate use cases

## 📄 License

This software is provided for educational and authorized security testing purposes only. Users are responsible for ensuring compliance with all applicable laws and regulations.

## 🔗 Related Resources

### **Educational Materials**
- [OWASP Password Security Guidelines](https://owasp.org/www-project-authentication-cheat-sheet/)
- [NIST Password Guidelines](https://pages.nist.gov/800-63-3/)
- [Hashcat Documentation](https://hashcat.net/hashcat/)
- [John the Ripper Documentation](https://www.openwall.com/john/)

### **Professional Tools**
- **Hashcat**: GPU-accelerated password cracking
- **John the Ripper**: Traditional password cracking tool
- **Hydra**: Network login cracker
- **Medusa**: Parallel login brute-forcer

---

**⚠️ Disclaimer**: This tool is provided for educational and authorized security testing purposes only. The authors are not responsible for any misuse or illegal activities performed with this software. Always ensure you have proper authorization before testing security on any system.

**🎯 Mission**: To provide security professionals, researchers, and students with a comprehensive, educational tool for understanding password security and hash algorithm implementations while promoting responsible and legal usage practices.