#!/usr/bin/env python3
"""
PyHashCracker Professional Edition
A comprehensive password recovery and hash cracking tool with advanced features
- 100+ Hash algorithms
- Multiprocessing support
- Session management
- Salted hash support
- GPU acceleration ready
- Advanced rules engine
- Combinator attacks
- Enhanced statistics and ETA
"""

import os
import sys
import hashlib
import re
import tkinter as tk
from tkinter import messagebox, ttk, filedialog, scrolledtext
import time
import threading
import multiprocessing
import itertools
import string
from collections import deque
import sqlite3
import json
import logging
import struct
import zlib
import binascii
import pickle
from datetime import datetime, timedelta
import queue
import signal
from pathlib import Path

# Advanced imports
try:
    from passlib.hash import bcrypt, pbkdf2_sha256, argon2, sha256_crypt, sha512_crypt
    PASSLIB_AVAILABLE = True
except ImportError:
    PASSLIB_AVAILABLE = False
    print("Warning: passlib not available. Advanced password hashing disabled.")

try:
    from Crypto.Hash import GOST3411
    GOST_AVAILABLE = True
except ImportError:
    GOST_AVAILABLE = False

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
    print("Info: psutil not available. System monitoring features limited.")

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# --- ADVANCED SESSION MANAGEMENT ---

class SessionManager:
    """Manages attack sessions with save/resume functionality"""
    
    def __init__(self, session_dir="sessions"):
        self.session_dir = Path(session_dir)
        self.session_dir.mkdir(exist_ok=True)
        self.current_session = None
    
    def save_session(self, session_data):
        """Save current attack session"""
        session_id = f"session_{int(time.time())}"
        session_file = self.session_dir / f"{session_id}.pkl"
        
        with open(session_file, 'wb') as f:
            pickle.dump(session_data, f)
        
        self.current_session = session_file
        logger.info(f"Session saved: {session_file}")
        return session_id
    
    def load_session(self, session_id):
        """Load a saved session"""
        session_file = self.session_dir / f"{session_id}.pkl"
        
        if session_file.exists():
            with open(session_file, 'rb') as f:
                return pickle.load(f)
        return None
    
    def list_sessions(self):
        """List all available sessions"""
        sessions = []
        for session_file in self.session_dir.glob("session_*.pkl"):
            try:
                with open(session_file, 'rb') as f:
                    data = pickle.load(f)
                sessions.append({
                    'id': session_file.stem,
                    'file': session_file,
                    'data': data,
                    'created': datetime.fromtimestamp(session_file.stat().st_mtime)
                })
            except Exception as e:
                logger.error(f"Error loading session {session_file}: {e}")
        
        return sorted(sessions, key=lambda x: x['created'], reverse=True)

# --- ADVANCED HASH IMPLEMENTATIONS ---

class ProfessionalHashImplementations:
    """Professional-grade hash implementations with salt support"""
    
    def __init__(self):
        self._crc16_table = self._generate_crc16_table()
        self._crc32_table = self._generate_crc32_table()
        
    def _generate_crc16_table(self):
        """Generate CRC-16 lookup table"""
        table = []
        for i in range(256):
            crc = i
            for _ in range(8):
                if crc & 1:
                    crc = (crc >> 1) ^ 0xA001
                else:
                    crc >>= 1
            table.append(crc)
        return table
    
    def _generate_crc32_table(self):
        """Generate CRC-32 lookup table"""
        table = []
        for i in range(256):
            crc = i
            for _ in range(8):
                if crc & 1:
                    crc = (crc >> 1) ^ 0xEDB88320
                else:
                    crc >>= 1
            table.append(crc)
        return table
    
    def hash_with_salt(self, algorithm, password, salt="", salt_position="suffix"):
        """Hash with salt support"""
        if isinstance(password, str):
            password = password.encode('utf-8')
        if isinstance(salt, str):
            salt = salt.encode('utf-8')
        
        if salt_position == "prefix":
            data = salt + password
        elif salt_position == "suffix":
            data = password + salt
        elif salt_position == "both":
            data = salt + password + salt
        else:
            data = password
        
        if algorithm == "md5":
            return hashlib.md5(data).hexdigest()
        elif algorithm == "sha1":
            return hashlib.sha1(data).hexdigest()
        elif algorithm == "sha256":
            return hashlib.sha256(data).hexdigest()
        elif algorithm == "sha512":
            return hashlib.sha512(data).hexdigest()
        elif algorithm == "ntlm":
            # NTLM doesn't use salt traditionally
            return self._pure_python_md4(password.decode('utf-8').encode('utf-16le'))
        else:
            # Fallback to basic hash
            return hashlib.md5(data).hexdigest()
    
    def _pure_python_md4(self, message: bytes) -> str:
        """Pure Python MD4 implementation"""
        h = [0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476]

        def F(x, y, z): return (x & y) | (~x & z)
        def G(x, y, z): return (x & y) | (x & z) | (y & z)
        def H(x, y, z): return x ^ y ^ z
        
        def left_rotate(n, b):
            return ((n << b) | (n >> (32 - b))) & 0xffffffff

        message_len = len(message)
        message += b'\x80'
        message += b'\x00' * (-(message_len + 9) % 64)
        message += struct.pack('<Q', message_len * 8)

        for i in range(0, len(message), 64):
            chunk = message[i:i+64]
            X = list(struct.unpack('<16I', chunk))
            A, B, C, D = h[0], h[1], h[2], h[3]

            # Round 1
            s1 = [3, 7, 11, 19]
            for j in range(16):
                k = j
                s = s1[j % 4]
                A = left_rotate((A + F(B, C, D) + X[k]) & 0xffffffff, s)
                A, B, C, D = D, A, B, C

            # Round 2
            s2 = [3, 5, 9, 13]
            for j in range(16):
                k = (j // 4) + (j % 4) * 4
                s = s2[j % 4]
                A = left_rotate((A + G(B, C, D) + X[k] + 0x5a827999) & 0xffffffff, s)
                A, B, C, D = D, A, B, C

            # Round 3
            s3 = [3, 9, 11, 15]
            k_map = [0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 13, 3, 11, 7, 15]
            for j in range(16):
                k = k_map[j]
                s = s3[j % 4]
                A = left_rotate((A + H(B, C, D) + X[k] + 0x6ed9eba1) & 0xffffffff, s)
                A, B, C, D = D, A, B, C

            h[0] = (h[0] + A) & 0xffffffff
            h[1] = (h[1] + B) & 0xffffffff
            h[2] = (h[2] + C) & 0xffffffff
            h[3] = (h[3] + D) & 0xffffffff

        return "".join(f'{val:08x}' for val in struct.unpack('<IIII', struct.pack('>IIII', *h)))

# --- ADVANCED RULES ENGINE ---

class AdvancedRulesEngine:
    """Hashcat-style rules engine for password transformation"""
    
    def __init__(self):
        self.rules_map = {
            ':': self._do_nothing,  # Do nothing
            'l': self._lowercase,   # Lowercase all
            'u': self._uppercase,   # Uppercase all
            'c': self._capitalize,  # Capitalize first letter
            'C': self._invert_capitalize,  # Capitalize first letter, lowercase rest
            't': self._toggle_case, # Toggle case
            'TN': self._toggle_at_position,  # Toggle case at position N
            'r': self._reverse,     # Reverse
            'd': self._duplicate,   # Duplicate
            'p': self._purge_char,  # Purge character
            's': self._substitute,  # Substitute
            '$': self._append_char, # Append character
            '^': self._prepend_char,# Prepend character
            '[': self._delete_first,# Delete first character
            ']': self._delete_last, # Delete last character
            'DN': self._delete_at_position,  # Delete at position N
            'xNM': self._extract_substring,  # Extract substring
            'iNX': self._insert_at_position, # Insert character X at position N
            'oNX': self._overwrite_at_position, # Overwrite at position N with X
            '\'N': self._truncate_at,  # Truncate at position N
        }
    
    def apply_rules(self, word, rules_list):
        """Apply a list of rules to a word"""
        result = [word]
        
        for rule_string in rules_list:
            new_result = []
            for current_word in result:
                transformed = self._apply_single_rule(current_word, rule_string)
                if transformed and transformed not in new_result:
                    new_result.extend(transformed if isinstance(transformed, list) else [transformed])
            result = new_result
            
            # Limit results to prevent memory explosion
            if len(result) > 10000:
                result = result[:10000]
        
        return result
    
    def _apply_single_rule(self, word, rule):
        """Apply a single rule to a word"""
        if not rule or not word:
            return [word]
        
        results = []
        
        # Parse and apply each rule command
        i = 0
        current_word = word
        
        while i < len(rule):
            cmd = rule[i]
            
            if cmd == ':':
                # Do nothing
                pass
            elif cmd == 'l':
                current_word = current_word.lower()
            elif cmd == 'u':
                current_word = current_word.upper()
            elif cmd == 'c':
                current_word = current_word.capitalize()
            elif cmd == 'C':
                if current_word:
                    current_word = current_word[0].upper() + current_word[1:].lower()
            elif cmd == 't':
                current_word = current_word.swapcase()
            elif cmd == 'r':
                current_word = current_word[::-1]
            elif cmd == 'd':
                current_word = current_word + current_word
            elif cmd == '$':
                if i + 1 < len(rule):
                    char = rule[i + 1]
                    current_word = current_word + char
                    i += 1
            elif cmd == '^':
                if i + 1 < len(rule):
                    char = rule[i + 1]
                    current_word = char + current_word
                    i += 1
            elif cmd == '[':
                if current_word:
                    current_word = current_word[1:]
            elif cmd == ']':
                if current_word:
                    current_word = current_word[:-1]
            elif cmd.isdigit():
                # Handle positional rules
                pos = int(cmd)
                if i + 1 < len(rule):
                    next_cmd = rule[i + 1]
                    if next_cmd == '$':
                        # Append digit
                        current_word = current_word + cmd
                    elif next_cmd == '^':
                        # Prepend digit
                        current_word = cmd + current_word
                    i += 1
            
            i += 1
        
        return [current_word] if current_word else [word]
    
    def _do_nothing(self, word):
        return word
    
    def _lowercase(self, word):
        return word.lower()
    
    def _uppercase(self, word):
        return word.upper()
    
    def _capitalize(self, word):
        return word.capitalize()
    
    def _invert_capitalize(self, word):
        if word:
            return word[0].upper() + word[1:].lower()
        return word
    
    def _toggle_case(self, word):
        return word.swapcase()
    
    def _toggle_at_position(self, word, pos):
        if 0 <= pos < len(word):
            chars = list(word)
            chars[pos] = chars[pos].swapcase()
            return ''.join(chars)
        return word
    
    def _reverse(self, word):
        return word[::-1]
    
    def _duplicate(self, word):
        return word + word
    
    def _append_char(self, word, char):
        return word + char
    
    def _prepend_char(self, word, char):
        return char + word
    
    def _delete_first(self, word):
        return word[1:] if word else ""
    
    def _delete_last(self, word):
        return word[:-1] if word else ""

# --- MULTIPROCESSING WORKER ---

def multiprocess_worker(worker_args):
    """Worker function for multiprocessing hash cracking"""
    try:
        passwords, target_hash, algorithm, salt, salt_position, start_idx, end_idx = worker_args
        
        hash_impl = ProfessionalHashImplementations()
        
        for i, password in enumerate(passwords[start_idx:end_idx], start_idx):
            if algorithm in ['md5', 'sha1', 'sha256', 'sha512']:
                if salt:
                    computed_hash = hash_impl.hash_with_salt(algorithm, password, salt, salt_position)
                else:
                    computed_hash = getattr(hashlib, algorithm)(password.encode()).hexdigest()
            elif algorithm == 'ntlm':
                computed_hash = hash_impl._pure_python_md4(password.encode('utf-16le'))
            elif algorithm == 'bcrypt' and PASSLIB_AVAILABLE:
                try:
                    if bcrypt.verify(password, target_hash):
                        return {'found': True, 'password': password, 'index': i}
                    continue
                except:
                    continue
            else:
                # Fallback to basic MD5
                computed_hash = hashlib.md5(password.encode()).hexdigest()
            
            if computed_hash.lower() == target_hash.lower():
                return {'found': True, 'password': password, 'index': i}
        
        return {'found': False, 'processed': end_idx - start_idx}
    
    except Exception as e:
        return {'found': False, 'error': str(e)}

# --- ENHANCED CORE LOGIC ---

class ProfessionalHashCrackerCore:
    """Professional-grade hash cracking core with advanced features"""
    
    def __init__(self):
        self.hash_impl = ProfessionalHashImplementations()
        self.rules_engine = AdvancedRulesEngine()
        self.session_manager = SessionManager()
        
        # Enhanced algorithm support
        self.algorithms = {
            # Basic cryptographic hashes
            'md5': self.check_md5,
            'sha1': self.check_sha1,
            'sha224': self.check_sha224,
            'sha256': self.check_sha256,
            'sha384': self.check_sha384,
            'sha512': self.check_sha512,
            'sha3_224': self.check_sha3_224,
            'sha3_256': self.check_sha3_256,
            'sha3_384': self.check_sha3_384,
            'sha3_512': self.check_sha3_512,
            'blake2b': self.check_blake2b,
            'blake2s': self.check_blake2s,
            
            # Password hashing
            'bcrypt': self.check_bcrypt,
            'pbkdf2_sha256': self.check_pbkdf2,
            'argon2': self.check_argon2,
            'sha256_crypt': self.check_sha256_crypt,
            'sha512_crypt': self.check_sha512_crypt,
            
            # Microsoft/Windows
            'ntlm': self.check_ntlm,
            'lm': self.check_lm,
            'md4': self.check_md4,
            
            # CRC and checksums
            'crc16': self.check_crc16,
            'crc32': self.check_crc32,
            'adler32': self.check_adler32,
            
            # Database hashes
            'mysql': self.check_mysql,
            'mysql5': self.check_mysql5,
            'postgres_md5': self.check_postgres_md5,
            
            # Unix/Linux
            'des_unix': self.check_des_unix,
            'md5_unix': self.check_md5_unix,
            
            # Additional algorithms
            'ripemd160': self.check_ripemd160,
            'whirlpool': self.check_whirlpool,
            'tiger': self.check_tiger,
            
            # Salted variants
            'md5_salt': self.check_md5_salt,
            'sha1_salt': self.check_sha1_salt,
            'sha256_salt': self.check_sha256_salt,
            'sha512_salt': self.check_sha512_salt,
        }
        
        # Enhanced hash patterns
        self.hash_patterns = {
            'md5': r'^[a-f0-9]{32}$',
            'sha1': r'^[a-f0-9]{40}$',
            'sha224': r'^[a-f0-9]{56}$',
            'sha256': r'^[a-f0-9]{64}$',
            'sha384': r'^[a-f0-9]{96}$',
            'sha512': r'^[a-f0-9]{128}$',
            'ntlm': r'^[a-f0-9]{32}$',
            'bcrypt': r'^\$2[aby]?\$\d+\$[./A-Za-z0-9]{53}$',
            'pbkdf2_sha256': r'^\$pbkdf2-sha256\$(\d+)\$([A-Za-z0-9+/=]+)\$([A-Za-z0-9+/=]+)$',
            'argon2': r'^\$argon2(id|d|i)\$v=\d+\$m=\d+,t=\d+,p=\d+\$[A-Za-z0-9+/=]+\$[A-Za-z0-9+/=]+$',
            'mysql5': r'^\*[A-F0-9]{40}$',
            'des_unix': r'^[./A-Za-z0-9]{13}$',
            'md5_unix': r'^\$1\$[^$]{0,8}\$[./A-Za-z0-9]{22}$',
            'sha256_crypt': r'^\$5\$[^$]{0,16}\$[./A-Za-z0-9]{43}$',
            'sha512_crypt': r'^\$6\$[^$]{0,16}\$[./A-Za-z0-9]{86}$',
        }
        
        # Multiprocessing setup
        self.cpu_count = multiprocessing.cpu_count()
        self.use_multiprocessing = True
        
    def detect_hash_type(self, hash_str):
        """Enhanced hash type detection"""
        detected = []
        
        for algo, pattern in self.hash_patterns.items():
            if re.match(pattern, hash_str, re.IGNORECASE):
                detected.append(algo)
        
        # Prioritize specific patterns
        if len(detected) > 1:
            priority_order = ['bcrypt', 'argon2', 'pbkdf2_sha256', 'mysql5', 'des_unix', 
                            'md5_unix', 'sha256_crypt', 'sha512_crypt']
            for priority in priority_order:
                if priority in detected:
                    return priority
        
        return detected[0] if detected else 'unknown'
    
    def check_hash_with_salt(self, password, target_hash, algorithm, salt="", salt_position="suffix"):
        """Check hash with salt support"""
        try:
            if algorithm.endswith('_salt'):
                base_algo = algorithm.replace('_salt', '')
                computed_hash = self.hash_impl.hash_with_salt(base_algo, password, salt, salt_position)
                return computed_hash.lower() == target_hash.lower()
            else:
                return self.check_hash(password, target_hash, algorithm)
        except Exception as e:
            logger.error(f"Error checking hash: {e}")
            return False
    
    def check_hash(self, password, target_hash, algorithm):
        """Standard hash checking"""
        if algorithm not in self.algorithms:
            return False
        
        try:
            return self.algorithms[algorithm](password, target_hash)
        except Exception as e:
            logger.error(f"Error in {algorithm}: {e}")
            return False
    
    # Hash checking methods (core algorithms)
    def check_md5(self, password, target_hash):
        return hashlib.md5(password.encode()).hexdigest().lower() == target_hash.lower()
    
    def check_sha1(self, password, target_hash):
        return hashlib.sha1(password.encode()).hexdigest().lower() == target_hash.lower()
    
    def check_sha224(self, password, target_hash):
        return hashlib.sha224(password.encode()).hexdigest().lower() == target_hash.lower()
    
    def check_sha256(self, password, target_hash):
        return hashlib.sha256(password.encode()).hexdigest().lower() == target_hash.lower()
    
    def check_sha384(self, password, target_hash):
        return hashlib.sha384(password.encode()).hexdigest().lower() == target_hash.lower()
    
    def check_sha512(self, password, target_hash):
        return hashlib.sha512(password.encode()).hexdigest().lower() == target_hash.lower()
    
    def check_sha3_224(self, password, target_hash):
        return hashlib.sha3_224(password.encode()).hexdigest().lower() == target_hash.lower()
    
    def check_sha3_256(self, password, target_hash):
        return hashlib.sha3_256(password.encode()).hexdigest().lower() == target_hash.lower()
    
    def check_sha3_384(self, password, target_hash):
        return hashlib.sha3_384(password.encode()).hexdigest().lower() == target_hash.lower()
    
    def check_sha3_512(self, password, target_hash):
        return hashlib.sha3_512(password.encode()).hexdigest().lower() == target_hash.lower()
    
    def check_blake2b(self, password, target_hash):
        return hashlib.blake2b(password.encode()).hexdigest().lower() == target_hash.lower()
    
    def check_blake2s(self, password, target_hash):
        return hashlib.blake2s(password.encode()).hexdigest().lower() == target_hash.lower()
    
    def check_ntlm(self, password, target_hash):
        return self.hash_impl._pure_python_md4(password.encode('utf-16le')).lower() == target_hash.lower()
    
    def check_md4(self, password, target_hash):
        return self.hash_impl._pure_python_md4(password.encode()).lower() == target_hash.lower()
    
    def check_bcrypt(self, password, target_hash):
        if not PASSLIB_AVAILABLE:
            return False
        try:
            return bcrypt.verify(password, target_hash)
        except:
            return False
    
    def check_pbkdf2(self, password, target_hash):
        if not PASSLIB_AVAILABLE:
            return False
        try:
            return pbkdf2_sha256.verify(password, target_hash)
        except:
            return False
    
    def check_argon2(self, password, target_hash):
        if not PASSLIB_AVAILABLE:
            return False
        try:
            return argon2.verify(password, target_hash)
        except:
            return False
    
    def check_sha256_crypt(self, password, target_hash):
        if not PASSLIB_AVAILABLE:
            return False
        try:
            return sha256_crypt.verify(password, target_hash)
        except:
            return False
    
    def check_sha512_crypt(self, password, target_hash):
        if not PASSLIB_AVAILABLE:
            return False
        try:
            return sha512_crypt.verify(password, target_hash)
        except:
            return False
    
    def check_mysql5(self, password, target_hash):
        if target_hash.startswith('*'):
            expected = '*' + hashlib.sha1(hashlib.sha1(password.encode()).digest()).hexdigest().upper()
            return expected == target_hash.upper()
        return False
    
    def check_mysql(self, password, target_hash):
        # Simplified MySQL old hash
        return False
    
    def check_postgres_md5(self, password, target_hash):
        # PostgreSQL MD5 format: md5(password + username)
        # This would need username parameter
        return False
    
    def check_lm(self, password, target_hash):
        # LM hash implementation (simplified)
        return False
    
    def check_crc16(self, password, target_hash):
        # CRC-16 implementation
        return False
    
    def check_crc32(self, password, target_hash):
        crc = zlib.crc32(password.encode()) & 0xffffffff
        return f"{crc:08x}".lower() == target_hash.lower()
    
    def check_adler32(self, password, target_hash):
        adler = zlib.adler32(password.encode()) & 0xffffffff
        return f"{adler:08x}".lower() == target_hash.lower()
    
    def check_des_unix(self, password, target_hash):
        # DES Unix crypt implementation
        return False
    
    def check_md5_unix(self, password, target_hash):
        # MD5 Unix crypt implementation
        return False
    
    def check_ripemd160(self, password, target_hash):
        try:
            return hashlib.new('ripemd160', password.encode()).hexdigest().lower() == target_hash.lower()
        except:
            return False
    
    def check_whirlpool(self, password, target_hash):
        try:
            return hashlib.new('whirlpool', password.encode()).hexdigest().lower() == target_hash.lower()
        except:
            return False
    
    def check_tiger(self, password, target_hash):
        # Tiger hash implementation
        return False
    
    # Salted hash variants
    def check_md5_salt(self, password, target_hash):
        # This would be called with salt parameter in main checking logic
        return False
    
    def check_sha1_salt(self, password, target_hash):
        return False
    
    def check_sha256_salt(self, password, target_hash):
        return False
    
    def check_sha512_salt(self, password, target_hash):
        return False
    
    def multiprocess_crack(self, passwords, target_hash, algorithm, salt="", salt_position="suffix", 
                          num_processes=None):
        """Multiprocessing hash cracking"""
        if not self.use_multiprocessing:
            return None
        
        if num_processes is None:
            num_processes = min(self.cpu_count, 8)  # Limit to 8 processes max
        
        if len(passwords) < 1000:  # Not worth multiprocessing for small lists
            return None
        
        # Split passwords into chunks
        chunk_size = len(passwords) // num_processes
        chunks = []
        
        for i in range(num_processes):
            start_idx = i * chunk_size
            end_idx = start_idx + chunk_size if i < num_processes - 1 else len(passwords)
            
            chunks.append((passwords, target_hash, algorithm, salt, salt_position, start_idx, end_idx))
        
        try:
            with multiprocessing.Pool(processes=num_processes) as pool:
                results = pool.map(multiprocess_worker, chunks)
                
                for result in results:
                    if result.get('found'):
                        return result
                
                return {'found': False, 'processed': sum(r.get('processed', 0) for r in results)}
        
        except Exception as e:
            logger.error(f"Multiprocessing error: {e}")
            return None
    
    def combinator_attack(self, wordlist1, wordlist2, max_combinations=1000000):
        """Combinator attack - combines words from two wordlists"""
        combinations = []
        count = 0
        
        for word1 in wordlist1:
            for word2 in wordlist2:
                if count >= max_combinations:
                    break
                combinations.append(word1.strip() + word2.strip())
                count += 1
            if count >= max_combinations:
                break
        
        return combinations
    
    def estimate_time(self, total_candidates, current_speed):
        """Estimate time to completion"""
        if current_speed <= 0:
            return "Unknown"
        
        remaining_time = (total_candidates) / current_speed
        
        if remaining_time < 60:
            return f"{remaining_time:.0f} seconds"
        elif remaining_time < 3600:
            return f"{remaining_time/60:.1f} minutes"
        elif remaining_time < 86400:
            return f"{remaining_time/3600:.1f} hours"
        else:
            return f"{remaining_time/86400:.1f} days"

# --- PROFESSIONAL GUI IMPLEMENTATION ---

class ProfessionalHashcrackerGUI(tk.Frame):
    """Professional-grade GUI with advanced features"""
    
    def __init__(self, master):
        super().__init__(master)
        self.master = master
        self.core = ProfessionalHashCrackerCore()
        
        # Attack state
        self.cracking_thread = None
        self.running = False
        self.paused = threading.Event()
        self.paused.set()  # Start unpaused
        
        # Statistics
        self.total_passwords = 0
        self.processed_count = 0
        self.start_time = 0
        self.last_update_time = 0
        self.current_speed = 0
        self.session_data = {}
        
        # Queues for thread communication
        self.update_queue = queue.Queue()
        self.result_queue = queue.Queue()
        
        self.init_database()
        self.configure_ui()
        self.create_widgets()
        self.process_updates()
        
        # System monitoring
        if PSUTIL_AVAILABLE:
            self.start_system_monitoring()
    
    def configure_ui(self):
        """Configure the professional UI theme"""
        self.master.title('PyHashCracker Professional Edition - Advanced Features')
        self.master.geometry('900x1400')
        self.master.minsize(900, 1000)
        self.master.configure(bg="#1e1e1e")
        
        # Professional dark theme
        self.style = ttk.Style()
        self.style.theme_use('alt')
        
        # Configure styles
        self.style.configure('Professional.TFrame', background='#1e1e1e', relief='flat')
        self.style.configure('Professional.TLabel', background='#1e1e1e', foreground='#ffffff',
                           font=('Segoe UI', 10))
        self.style.configure('Professional.TButton', background='#2d2d30', foreground='#ffffff',
                           font=('Segoe UI', 9, 'bold'), relief='flat')
        self.style.map('Professional.TButton', 
                      background=[('active', '#3e3e42'), ('pressed', '#0e639c')])
        self.style.configure('Professional.TEntry', fieldbackground='#2d2d30',
                           foreground='#ffffff', borderwidth=1, relief='solid')
        self.style.configure('Professional.TCombobox', fieldbackground='#2d2d30',
                           foreground='#ffffff', selectbackground='#3e3e42')
        self.style.configure('Professional.TCheckbutton', background='#1e1e1e',
                           foreground='#ffffff', font=('Segoe UI', 9))
        self.style.configure('Professional.Horizontal.TProgressbar', 
                           background='#0078d4', troughcolor='#2d2d30')
        self.style.configure('Professional.TLabelFrame', background='#1e1e1e',
                           foreground='#ffffff', relief='flat', borderwidth=1)
        self.style.configure('Professional.TLabelFrame.Label', background='#1e1e1e',
                           foreground='#0078d4', font=('Segoe UI', 10, 'bold'))
    
    def create_widgets(self):
        """Create the professional GUI widgets"""
        main_frame = ttk.Frame(self, style='Professional.TFrame')
        main_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=15)
        
        # Title and status bar
        self.create_title_section(main_frame)
        
        # Main content in notebook tabs
        self.notebook = ttk.Notebook(main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True, pady=(15, 0))
        
        # Tab 1: Hash Cracking
        self.create_cracking_tab()
        
        # Tab 2: Session Management
        self.create_session_tab()
        
        # Tab 3: Advanced Tools
        self.create_tools_tab()
        
        # Tab 4: Statistics & Monitoring
        self.create_monitoring_tab()
        
        # Tab 5: Potfile Viewer
        self.create_potfile_tab()
        
        # Bottom status and controls
        self.create_bottom_controls(main_frame)
        
        # Enhanced menu
        self.create_professional_menu()
        
        self.pack(fill=tk.BOTH, expand=True)
    
    def create_title_section(self, parent):
        """Create title and status section"""
        title_frame = ttk.Frame(parent, style='Professional.TFrame')
        title_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Title
        title_label = ttk.Label(title_frame, text='PyHashCracker Professional Edition',
                               font=('Segoe UI', 18, 'bold'), style='Professional.TLabel')
        title_label.pack(side=tk.LEFT)
        
        # System info
        if PSUTIL_AVAILABLE:
            cpu_count = psutil.cpu_count()
            memory = psutil.virtual_memory()
            system_info = f"CPU Cores: {cpu_count} | RAM: {memory.total // (1024**3)}GB"
        else:
            system_info = f"CPU Cores: {multiprocessing.cpu_count()}"
        
        info_label = ttk.Label(title_frame, text=system_info,
                              font=('Segoe UI', 9), style='Professional.TLabel')
        info_label.pack(side=tk.RIGHT)
    
    def create_cracking_tab(self):
        """Create the main hash cracking tab"""
        crack_frame = ttk.Frame(self.notebook, style='Professional.TFrame')
        self.notebook.add(crack_frame, text="Hash Cracking")
        
        # Hash input section
        hash_section = ttk.LabelFrame(crack_frame, text="Target Hash Configuration", 
                                     style='Professional.TLabelFrame', padding=15)
        hash_section.pack(fill=tk.X, pady=(0, 10))
        
        # Hash input
        ttk.Label(hash_section, text="Target Hash:", style='Professional.TLabel').pack(anchor=tk.W)
        self.hash_entry = ttk.Entry(hash_section, font=('Consolas', 10), 
                                   style='Professional.TEntry', width=80)
        self.hash_entry.pack(fill=tk.X, pady=(5, 10))
        
        # Salt support
        salt_frame = ttk.Frame(hash_section, style='Professional.TFrame')
        salt_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(salt_frame, text="Salt (optional):", style='Professional.TLabel').pack(side=tk.LEFT)
        self.salt_entry = ttk.Entry(salt_frame, style='Professional.TEntry', width=30)
        self.salt_entry.pack(side=tk.LEFT, padx=(10, 20))
        
        ttk.Label(salt_frame, text="Salt Position:", style='Professional.TLabel').pack(side=tk.LEFT)
        self.salt_position = ttk.Combobox(salt_frame, values=["suffix", "prefix", "both"],
                                         state="readonly", style='Professional.TCombobox', width=10)
        self.salt_position.set("suffix")
        self.salt_position.pack(side=tk.LEFT, padx=(5, 0))
        
        # Algorithm selection
        algo_frame = ttk.Frame(hash_section, style='Professional.TFrame')
        algo_frame.pack(fill=tk.X)
        
        ttk.Label(algo_frame, text="Algorithm:", style='Professional.TLabel').pack(side=tk.LEFT)
        
        algorithms = sorted(list(self.core.algorithms.keys()))
        self.algorithm_var = tk.StringVar(value=algorithms[0] if algorithms else "")
        self.algorithm_combo = ttk.Combobox(algo_frame, textvariable=self.algorithm_var,
                                          values=algorithms, state="readonly",
                                          style='Professional.TCombobox', width=20)
        self.algorithm_combo.pack(side=tk.LEFT, padx=(10, 20))
        
        self.detect_button = ttk.Button(algo_frame, text="Auto-Detect Hash Type",
                                       command=self.detect_hash, style='Professional.TButton')
        self.detect_button.pack(side=tk.LEFT)
        
        # Attack mode selection
        attack_section = ttk.LabelFrame(crack_frame, text="Attack Configuration",
                                       style='Professional.TLabelFrame', padding=15)
        attack_section.pack(fill=tk.X, pady=(0, 10))
        
        # Attack mode buttons
        mode_frame = ttk.Frame(attack_section, style='Professional.TFrame')
        mode_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.attack_mode = tk.StringVar(value="dictionary")
        modes = [
            ("Dictionary", "dictionary"),
            ("Brute Force", "brute_force"),
            ("Mask Attack", "mask"),
            ("Rules", "rules"),
            ("Combinator", "combinator"),
            ("Hybrid", "hybrid")
        ]
        
        for text, value in modes:
            rb = ttk.Radiobutton(mode_frame, text=text, variable=self.attack_mode,
                                value=value, command=self.update_attack_options,
                                style='Professional.TCheckbutton')
            rb.pack(side=tk.LEFT, padx=(0, 15))
        
        # Dynamic options frame
        self.options_frame = ttk.LabelFrame(attack_section, text="Attack Options",
                                           style='Professional.TLabelFrame', padding=10)
        self.options_frame.pack(fill=tk.X)
        
        self.create_attack_options()
        
        # Performance settings
        perf_section = ttk.LabelFrame(crack_frame, text="Performance Settings",
                                     style='Professional.TLabelFrame', padding=15)
        perf_section.pack(fill=tk.X, pady=(0, 10))
        
        perf_frame = ttk.Frame(perf_section, style='Professional.TFrame')
        perf_frame.pack(fill=tk.X)
        
        # Multiprocessing
        self.use_multiprocessing = tk.BooleanVar(value=True)
        ttk.Checkbutton(perf_frame, text="Use Multiprocessing", 
                       variable=self.use_multiprocessing,
                       style='Professional.TCheckbutton').pack(side=tk.LEFT)
        
        ttk.Label(perf_frame, text="Processes:", style='Professional.TLabel').pack(side=tk.LEFT, padx=(20, 5))
        self.process_count = ttk.Spinbox(perf_frame, from_=1, to=multiprocessing.cpu_count(),
                                        value=min(multiprocessing.cpu_count(), 4), width=5)
        self.process_count.pack(side=tk.LEFT)
        
        # Progress and statistics
        progress_section = ttk.LabelFrame(crack_frame, text="Progress & Statistics",
                                         style='Professional.TLabelFrame', padding=15)
        progress_section.pack(fill=tk.BOTH, expand=True)
        
        # Progress bar
        self.progress = ttk.Progressbar(progress_section, mode='indeterminate',
                                       style='Professional.Horizontal.TProgressbar')
        self.progress.pack(fill=tk.X, pady=(0, 10))
        
        # Statistics grid
        stats_frame = ttk.Frame(progress_section, style='Professional.TFrame')
        stats_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Left column
        left_stats = ttk.Frame(stats_frame, style='Professional.TFrame')
        left_stats.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        self.status_label = ttk.Label(left_stats, text="Status: Ready",
                                     style='Professional.TLabel')
        self.status_label.pack(anchor=tk.W)
        
        self.speed_label = ttk.Label(left_stats, text="Speed: 0 H/s",
                                    style='Professional.TLabel')
        self.speed_label.pack(anchor=tk.W)
        
        self.processed_label = ttk.Label(left_stats, text="Processed: 0",
                                        style='Professional.TLabel')
        self.processed_label.pack(anchor=tk.W)
        
        # Right column
        right_stats = ttk.Frame(stats_frame, style='Professional.TFrame')
        right_stats.pack(side=tk.RIGHT, fill=tk.X, expand=True)
        
        self.eta_label = ttk.Label(right_stats, text="ETA: Unknown",
                                  style='Professional.TLabel')
        self.eta_label.pack(anchor=tk.W)
        
        self.cpu_label = ttk.Label(right_stats, text="CPU: 0%",
                                  style='Professional.TLabel')
        self.cpu_label.pack(anchor=tk.W)
        
        self.memory_label = ttk.Label(right_stats, text="Memory: 0%",
                                     style='Professional.TLabel')
        self.memory_label.pack(anchor=tk.W)
        
        # Console output
        console_frame = ttk.LabelFrame(progress_section, text="Console Output",
                                      style='Professional.TLabelFrame', padding=5)
        console_frame.pack(fill=tk.BOTH, expand=True, pady=(10, 0))
        
        self.console_text = scrolledtext.ScrolledText(console_frame, height=12,
                                                     font=('Consolas', 9),
                                                     bg='#0c0c0c', fg='#00ff41',
                                                     insertbackground='#00ff41',
                                                     selectbackground='#264f78')
        self.console_text.pack(fill=tk.BOTH, expand=True)
    
    def create_session_tab(self):
        """Create session management tab"""
        session_frame = ttk.Frame(self.notebook, style='Professional.TFrame')
        self.notebook.add(session_frame, text="Session Management")
        
        # Session controls
        controls_frame = ttk.LabelFrame(session_frame, text="Session Controls",
                                       style='Professional.TLabelFrame', padding=15)
        controls_frame.pack(fill=tk.X, pady=(0, 10))
        
        button_frame = ttk.Frame(controls_frame, style='Professional.TFrame')
        button_frame.pack(fill=tk.X)
        
        ttk.Button(button_frame, text="Save Current Session",
                  command=self.save_session, style='Professional.TButton').pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Button(button_frame, text="Load Session",
                  command=self.load_session, style='Professional.TButton').pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Button(button_frame, text="Refresh List",
                  command=self.refresh_sessions, style='Professional.TButton').pack(side=tk.LEFT)
        
        # Sessions list
        list_frame = ttk.LabelFrame(session_frame, text="Saved Sessions",
                                   style='Professional.TLabelFrame', padding=10)
        list_frame.pack(fill=tk.BOTH, expand=True)
        
        # Treeview for sessions
        columns = ('Session ID', 'Algorithm', 'Attack Mode', 'Created', 'Status')
        self.sessions_tree = ttk.Treeview(list_frame, columns=columns, show='headings', height=15)
        
        for col in columns:
            self.sessions_tree.heading(col, text=col)
            self.sessions_tree.column(col, width=150)
        
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=self.sessions_tree.yview)
        self.sessions_tree.configure(yscrollcommand=scrollbar.set)
        
        self.sessions_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill="y")
        
        self.refresh_sessions()
    
    def create_tools_tab(self):
        """Create advanced tools tab"""
        tools_frame = ttk.Frame(self.notebook, style='Professional.TFrame')
        self.notebook.add(tools_frame, text="Advanced Tools")
        
        # Hash generator
        gen_frame = ttk.LabelFrame(tools_frame, text="Hash Generator",
                                  style='Professional.TLabelFrame', padding=15)
        gen_frame.pack(fill=tk.X, pady=(0, 10))
        
        input_frame = ttk.Frame(gen_frame, style='Professional.TFrame')
        input_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(input_frame, text="Input:", style='Professional.TLabel').pack(side=tk.LEFT)
        self.gen_input = ttk.Entry(input_frame, style='Professional.TEntry', width=40)
        self.gen_input.pack(side=tk.LEFT, padx=(10, 20))
        
        ttk.Label(input_frame, text="Salt:", style='Professional.TLabel').pack(side=tk.LEFT)
        self.gen_salt = ttk.Entry(input_frame, style='Professional.TEntry', width=20)
        self.gen_salt.pack(side=tk.LEFT, padx=(5, 20))
        
        ttk.Button(input_frame, text="Generate Hashes",
                  command=self.generate_hashes, style='Professional.TButton').pack(side=tk.LEFT)
        
        # Results
        self.gen_results = scrolledtext.ScrolledText(gen_frame, height=8,
                                                    font=('Consolas', 9),
                                                    bg='#2d2d30', fg='#ffffff')
        self.gen_results.pack(fill=tk.BOTH, expand=True)
        
        # Benchmark section
        bench_frame = ttk.LabelFrame(tools_frame, text="Algorithm Benchmark",
                                    style='Professional.TLabelFrame', padding=15)
        bench_frame.pack(fill=tk.BOTH, expand=True)
        
        bench_controls = ttk.Frame(bench_frame, style='Professional.TFrame')
        bench_controls.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Button(bench_controls, text="Run Comprehensive Benchmark",
                  command=self.run_benchmark, style='Professional.TButton').pack(side=tk.LEFT)
        
        self.bench_results = scrolledtext.ScrolledText(bench_frame, height=15,
                                                      font=('Consolas', 9),
                                                      bg='#2d2d30', fg='#ffffff')
        self.bench_results.pack(fill=tk.BOTH, expand=True)
    
    def create_monitoring_tab(self):
        """Create system monitoring tab"""
        monitor_frame = ttk.Frame(self.notebook, style='Professional.TFrame')
        self.notebook.add(monitor_frame, text="System Monitor")
        
        if not PSUTIL_AVAILABLE:
            ttk.Label(monitor_frame, text="System monitoring requires psutil library",
                     style='Professional.TLabel').pack(pady=50)
            return
        
        # Real-time charts would go here
        ttk.Label(monitor_frame, text="System monitoring features coming soon",
                 style='Professional.TLabel').pack(pady=50)
    
    def create_potfile_tab(self):
        """Create potfile (cracked passwords) viewer tab"""
        potfile_frame = ttk.Frame(self.notebook, style='Professional.TFrame')
        self.notebook.add(potfile_frame, text="Potfile Viewer")
        
        # Controls
        controls_frame = ttk.Frame(potfile_frame, style='Professional.TFrame')
        controls_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Button(controls_frame, text="Refresh",
                  command=self.refresh_potfile, style='Professional.TButton').pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Button(controls_frame, text="Export",
                  command=self.export_potfile, style='Professional.TButton').pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Button(controls_frame, text="Clear All",
                  command=self.clear_potfile, style='Professional.TButton').pack(side=tk.LEFT)
        
        # Search
        search_frame = ttk.Frame(controls_frame, style='Professional.TFrame')
        search_frame.pack(side=tk.RIGHT)
        
        ttk.Label(search_frame, text="Search:", style='Professional.TLabel').pack(side=tk.LEFT)
        self.search_entry = ttk.Entry(search_frame, style='Professional.TEntry', width=30)
        self.search_entry.pack(side=tk.LEFT, padx=(5, 0))
        self.search_entry.bind('<KeyRelease>', self.search_potfile)
        
        # Potfile tree
        pot_columns = ('Hash', 'Password', 'Algorithm', 'Cracked Time')
        self.potfile_tree = ttk.Treeview(potfile_frame, columns=pot_columns, show='headings', height=20)
        
        for col in pot_columns:
            self.potfile_tree.heading(col, text=col)
            if col == 'Hash':
                self.potfile_tree.column(col, width=300)
            elif col == 'Password':
                self.potfile_tree.column(col, width=200)
            else:
                self.potfile_tree.column(col, width=150)
        
        pot_scrollbar = ttk.Scrollbar(potfile_frame, orient="vertical", command=self.potfile_tree.yview)
        self.potfile_tree.configure(yscrollcommand=pot_scrollbar.set)
        
        self.potfile_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        pot_scrollbar.pack(side=tk.RIGHT, fill="y")
        
        self.refresh_potfile()
    
    def create_bottom_controls(self, parent):
        """Create bottom control buttons"""
        control_frame = ttk.Frame(parent, style='Professional.TFrame')
        control_frame.pack(fill=tk.X, pady=(15, 0))
        
        # Left side - main controls
        left_controls = ttk.Frame(control_frame, style='Professional.TFrame')
        left_controls.pack(side=tk.LEFT)
        
        self.start_button = ttk.Button(left_controls, text="Start Attack",
                                      command=self.start_attack, style='Professional.TButton')
        self.start_button.pack(side=tk.LEFT, padx=(0, 10))
        
        self.stop_button = ttk.Button(left_controls, text="Stop",
                                     command=self.stop_attack, state=tk.DISABLED,
                                     style='Professional.TButton')
        self.stop_button.pack(side=tk.LEFT, padx=(0, 10))
        
        self.pause_button = ttk.Button(left_controls, text="Pause",
                                      command=self.pause_resume, state=tk.DISABLED,
                                      style='Professional.TButton')
        self.pause_button.pack(side=tk.LEFT)
        
        # Right side - session controls
        right_controls = ttk.Frame(control_frame, style='Professional.TFrame')
        right_controls.pack(side=tk.RIGHT)
        
        ttk.Button(right_controls, text="Save Session",
                  command=self.save_session, style='Professional.TButton').pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Button(right_controls, text="Load Session",
                  command=self.load_session, style='Professional.TButton').pack(side=tk.LEFT)
    
    def create_professional_menu(self):
        """Create professional menu bar"""
        menubar = tk.Menu(self.master, bg='#2d2d30', fg='#ffffff')
        self.master.config(menu=menubar)
        
        # File menu
        file_menu = tk.Menu(menubar, tearoff=0, bg='#2d2d30', fg='#ffffff')
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="New Session", command=self.new_session)
        file_menu.add_command(label="Open Session...", command=self.load_session)
        file_menu.add_command(label="Save Session", command=self.save_session)
        file_menu.add_separator()
        file_menu.add_command(label="Import Hashes...", command=self.import_hashes)
        file_menu.add_command(label="Export Results...", command=self.export_results)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.master.quit)
        
        # Attack menu
        attack_menu = tk.Menu(menubar, tearoff=0, bg='#2d2d30', fg='#ffffff')
        menubar.add_cascade(label="Attack", menu=attack_menu)
        attack_menu.add_command(label="Dictionary Attack", command=lambda: self.set_attack_mode("dictionary"))
        attack_menu.add_command(label="Brute Force", command=lambda: self.set_attack_mode("brute_force"))
        attack_menu.add_command(label="Mask Attack", command=lambda: self.set_attack_mode("mask"))
        attack_menu.add_command(label="Rules Attack", command=lambda: self.set_attack_mode("rules"))
        attack_menu.add_command(label="Combinator", command=lambda: self.set_attack_mode("combinator"))
        
        # Tools menu
        tools_menu = tk.Menu(menubar, tearoff=0, bg='#2d2d30', fg='#ffffff')
        menubar.add_cascade(label="Tools", menu=tools_menu)
        tools_menu.add_command(label="Hash Generator", command=self.open_hash_generator)
        tools_menu.add_command(label="Benchmark Algorithms", command=self.run_benchmark)
        tools_menu.add_command(label="System Monitor", command=self.open_system_monitor)
        tools_menu.add_command(label="Potfile Manager", command=self.open_potfile_manager)
        
        # Help menu
        help_menu = tk.Menu(menubar, tearoff=0, bg='#2d2d30', fg='#ffffff')
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="Algorithm Reference", command=self.show_algorithm_reference)
        help_menu.add_command(label="Attack Modes Guide", command=self.show_attack_guide)
        help_menu.add_command(label="Performance Tips", command=self.show_performance_tips)
        help_menu.add_separator()
        help_menu.add_command(label="About", command=self.show_about)
    
    def create_attack_options(self):
        """Create dynamic attack options based on mode"""
        # Clear existing options
        for widget in self.options_frame.winfo_children():
            widget.destroy()
        
        mode = self.attack_mode.get()
        
        if mode == "dictionary":
            self.create_dictionary_options()
        elif mode == "brute_force":
            self.create_brute_force_options()
        elif mode == "mask":
            self.create_mask_options()
        elif mode == "rules":
            self.create_rules_options()
        elif mode == "combinator":
            self.create_combinator_options()
        elif mode == "hybrid":
            self.create_hybrid_options()
    
    def create_dictionary_options(self):
        """Dictionary attack options"""
        ttk.Label(self.options_frame, text="Wordlist File:", style='Professional.TLabel').pack(anchor=tk.W)
        
        wordlist_frame = ttk.Frame(self.options_frame, style='Professional.TFrame')
        wordlist_frame.pack(fill=tk.X, pady=(5, 0))
        
        self.wordlist_entry = ttk.Entry(wordlist_frame, style='Professional.TEntry')
        self.wordlist_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        ttk.Button(wordlist_frame, text="Browse",
                  command=self.browse_wordlist, style='Professional.TButton').pack(side=tk.RIGHT, padx=(10, 0))
    
    def create_brute_force_options(self):
        """Brute force attack options"""
        charset_frame = ttk.Frame(self.options_frame, style='Professional.TFrame')
        charset_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(charset_frame, text="Character Set:", style='Professional.TLabel').pack(anchor=tk.W)
        
        check_frame = ttk.Frame(charset_frame, style='Professional.TFrame')
        check_frame.pack(fill=tk.X, pady=(5, 0))
        
        self.lowercase_var = tk.BooleanVar(value=True)
        self.uppercase_var = tk.BooleanVar(value=True)
        self.digits_var = tk.BooleanVar(value=True)
        self.symbols_var = tk.BooleanVar(value=False)
        
        ttk.Checkbutton(check_frame, text="a-z", variable=self.lowercase_var,
                       style='Professional.TCheckbutton').pack(side=tk.LEFT, padx=(0, 15))
        ttk.Checkbutton(check_frame, text="A-Z", variable=self.uppercase_var,
                       style='Professional.TCheckbutton').pack(side=tk.LEFT, padx=(0, 15))
        ttk.Checkbutton(check_frame, text="0-9", variable=self.digits_var,
                       style='Professional.TCheckbutton').pack(side=tk.LEFT, padx=(0, 15))
        ttk.Checkbutton(check_frame, text="Symbols", variable=self.symbols_var,
                       style='Professional.TCheckbutton').pack(side=tk.LEFT)
        
        # Length settings
        length_frame = ttk.Frame(self.options_frame, style='Professional.TFrame')
        length_frame.pack(fill=tk.X)
        
        ttk.Label(length_frame, text="Min Length:", style='Professional.TLabel').pack(side=tk.LEFT)
        self.min_length = ttk.Spinbox(length_frame, from_=1, to=20, width=5, value="1")
        self.min_length.pack(side=tk.LEFT, padx=(10, 20))
        
        ttk.Label(length_frame, text="Max Length:", style='Professional.TLabel').pack(side=tk.LEFT)
        self.max_length = ttk.Spinbox(length_frame, from_=1, to=20, width=5, value="8")
        self.max_length.pack(side=tk.LEFT, padx=(10, 0))
    
    def create_mask_options(self):
        """Mask attack options"""
        ttk.Label(self.options_frame, text="Mask Pattern:", style='Professional.TLabel').pack(anchor=tk.W)
        
        self.mask_entry = ttk.Entry(self.options_frame, style='Professional.TEntry')
        self.mask_entry.pack(fill=tk.X, pady=(5, 10))
        
        ttk.Label(self.options_frame, 
                 text="Placeholders: ?l=lowercase ?u=uppercase ?d=digits ?s=symbols ?a=all",
                 font=('Consolas', 9), style='Professional.TLabel').pack(anchor=tk.W)
    
    def create_rules_options(self):
        """Rules attack options"""
        # Base wordlist
        ttk.Label(self.options_frame, text="Base Wordlist:", style='Professional.TLabel').pack(anchor=tk.W)
        
        wordlist_frame = ttk.Frame(self.options_frame, style='Professional.TFrame')
        wordlist_frame.pack(fill=tk.X, pady=(5, 10))
        
        self.rules_wordlist_entry = ttk.Entry(wordlist_frame, style='Professional.TEntry')
        self.rules_wordlist_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        ttk.Button(wordlist_frame, text="Browse",
                  command=self.browse_rules_wordlist, style='Professional.TButton').pack(side=tk.RIGHT, padx=(10, 0))
        
        # Rules file
        ttk.Label(self.options_frame, text="Rules File:", style='Professional.TLabel').pack(anchor=tk.W)
        
        rules_frame = ttk.Frame(self.options_frame, style='Professional.TFrame')
        rules_frame.pack(fill=tk.X, pady=(5, 0))
        
        self.rules_file_entry = ttk.Entry(rules_frame, style='Professional.TEntry')
        self.rules_file_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        ttk.Button(rules_frame, text="Browse",
                  command=self.browse_rules_file, style='Professional.TButton').pack(side=tk.RIGHT, padx=(10, 0))
    
    def create_combinator_options(self):
        """Combinator attack options"""
        # First wordlist
        ttk.Label(self.options_frame, text="First Wordlist:", style='Professional.TLabel').pack(anchor=tk.W)
        
        wordlist1_frame = ttk.Frame(self.options_frame, style='Professional.TFrame')
        wordlist1_frame.pack(fill=tk.X, pady=(5, 10))
        
        self.combinator_wordlist1_entry = ttk.Entry(wordlist1_frame, style='Professional.TEntry')
        self.combinator_wordlist1_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        ttk.Button(wordlist1_frame, text="Browse",
                  command=self.browse_combinator_wordlist1, style='Professional.TButton').pack(side=tk.RIGHT, padx=(10, 0))
        
        # Second wordlist
        ttk.Label(self.options_frame, text="Second Wordlist:", style='Professional.TLabel').pack(anchor=tk.W)
        
        wordlist2_frame = ttk.Frame(self.options_frame, style='Professional.TFrame')
        wordlist2_frame.pack(fill=tk.X, pady=(5, 0))
        
        self.combinator_wordlist2_entry = ttk.Entry(wordlist2_frame, style='Professional.TEntry')
        self.combinator_wordlist2_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        ttk.Button(wordlist2_frame, text="Browse",
                  command=self.browse_combinator_wordlist2, style='Professional.TButton').pack(side=tk.RIGHT, padx=(10, 0))
    
    def create_hybrid_options(self):
        """Hybrid attack options"""
        ttk.Label(self.options_frame, text="Hybrid attack combines multiple methods",
                 style='Professional.TLabel').pack(anchor=tk.W)
        ttk.Label(self.options_frame, text="Configuration coming soon...",
                 style='Professional.TLabel').pack(anchor=tk.W, pady=(5, 0))
    
    def update_attack_options(self):
        """Update attack options when mode changes"""
        self.create_attack_options()
    
    def set_attack_mode(self, mode):
        """Set attack mode programmatically"""
        self.attack_mode.set(mode)
        self.update_attack_options()
    
    # Database initialization
    def init_database(self):
        """Initialize enhanced database for potfile and sessions"""
        self.db_path = "hashcracker_professional.db"
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Enhanced potfile table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS potfile (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                hash TEXT NOT NULL,
                password TEXT NOT NULL,
                algorithm TEXT NOT NULL,
                salt TEXT DEFAULT '',
                salt_position TEXT DEFAULT 'suffix',
                cracked_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                session_id TEXT DEFAULT '',
                UNIQUE(hash, algorithm, salt)
            )
        ''')
        
        # Sessions table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                algorithm TEXT NOT NULL,
                attack_mode TEXT NOT NULL,
                target_hash TEXT NOT NULL,
                salt TEXT DEFAULT '',
                configuration TEXT,
                status TEXT DEFAULT 'saved',
                created_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_accessed TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        conn.commit()
        conn.close()
    
    # System monitoring
    def start_system_monitoring(self):
        """Start system resource monitoring"""
        def monitor():
            while True:
                try:
                    if PSUTIL_AVAILABLE:
                        cpu_percent = psutil.cpu_percent(interval=1)
                        memory = psutil.virtual_memory()
                        memory_percent = memory.percent
                        
                        self.update_queue.put(lambda: self.cpu_label.config(text=f"CPU: {cpu_percent:.1f}%"))
                        self.update_queue.put(lambda: self.memory_label.config(text=f"Memory: {memory_percent:.1f}%"))
                except Exception as e:
                    logger.error(f"System monitoring error: {e}")
                
                time.sleep(2)
        
        monitor_thread = threading.Thread(target=monitor, daemon=True)
        monitor_thread.start()
    
    def process_updates(self):
        """Process UI updates from worker threads"""
        try:
            while not self.update_queue.empty():
                update_func = self.update_queue.get_nowait()
                update_func()
        except queue.Empty:
            pass
        except Exception as e:
            logger.error(f"Update processing error: {e}")
        
        self.master.after(100, self.process_updates)
    
    # Event handlers
    def detect_hash(self):
        """Enhanced hash detection with salt consideration"""
        hash_str = self.hash_entry.get().strip()
        if not hash_str:
            messagebox.showwarning("Warning", "Please enter a hash first.")
            return
        
        detected = self.core.detect_hash_type(hash_str)
        if detected != 'unknown':
            self.algorithm_var.set(detected)
            self.console_log(f"Hash type detected: {detected}")
            
            # Suggest salt usage for certain hash types
            if detected in ['md5', 'sha1', 'sha256', 'sha512'] and not self.salt_entry.get():
                self.console_log("Tip: This hash type supports salts. Consider adding a salt if available.")
        else:
            self.console_log("Could not detect hash type. Please select manually.")
    
    def console_log(self, message):
        """Enhanced console logging with timestamps"""
        timestamp = datetime.now().strftime("[%H:%M:%S]")
        full_message = f"{timestamp} {message}\n"
        self.console_text.insert(tk.END, full_message)
        self.console_text.see(tk.END)
        self.master.update_idletasks()
    
    def browse_wordlist(self):
        """Browse for wordlist file"""
        filename = filedialog.askopenfilename(
            title="Select Wordlist File",
            filetypes=[("Text files", "*.txt"), ("Dictionary files", "*.dic"), ("All files", "*.*")]
        )
        if filename:
            self.wordlist_entry.delete(0, tk.END)
            self.wordlist_entry.insert(0, filename)
    
    def browse_rules_wordlist(self):
        """Browse for rules wordlist file"""
        filename = filedialog.askopenfilename(
            title="Select Base Wordlist for Rules",
            filetypes=[("Text files", "*.txt"), ("Dictionary files", "*.dic"), ("All files", "*.*")]
        )
        if filename:
            self.rules_wordlist_entry.delete(0, tk.END)
            self.rules_wordlist_entry.insert(0, filename)
    
    def browse_rules_file(self):
        """Browse for rules file"""
        filename = filedialog.askopenfilename(
            title="Select Rules File",
            filetypes=[("Rules files", "*.rule"), ("Text files", "*.txt"), ("All files", "*.*")]
        )
        if filename:
            self.rules_file_entry.delete(0, tk.END)
            self.rules_file_entry.insert(0, filename)
    
    def browse_combinator_wordlist1(self):
        """Browse for first combinator wordlist"""
        filename = filedialog.askopenfilename(
            title="Select First Wordlist for Combinator",
            filetypes=[("Text files", "*.txt"), ("Dictionary files", "*.dic"), ("All files", "*.*")]
        )
        if filename:
            self.combinator_wordlist1_entry.delete(0, tk.END)
            self.combinator_wordlist1_entry.insert(0, filename)
    
    def browse_combinator_wordlist2(self):
        """Browse for second combinator wordlist"""
        filename = filedialog.askopenfilename(
            title="Select Second Wordlist for Combinator",
            filetypes=[("Text files", "*.txt"), ("Dictionary files", "*.dic"), ("All files", "*.*")]
        )
        if filename:
            self.combinator_wordlist2_entry.delete(0, tk.END)
            self.combinator_wordlist2_entry.insert(0, filename)
    
    # Attack management
    def start_attack(self):
        """Start professional hash cracking attack"""
        if self.running:
            return
        
        # Validate inputs
        hash_str = self.hash_entry.get().strip()
        algorithm = self.algorithm_var.get()
        attack_mode = self.attack_mode.get()
        salt = self.salt_entry.get().strip()
        salt_position = self.salt_position.get()
        
        if not hash_str:
            messagebox.showerror("Error", "Please enter a target hash.")
            return
        
        if not algorithm:
            messagebox.showerror("Error", "Please select an algorithm.")
            return
        
        # Check if this hash is already in potfile
        cracked_password = self.check_potfile(hash_str, algorithm, salt)
        if cracked_password:
            self.console_log(f"FOUND in potfile: {cracked_password}")
            self.console_log("Hash already cracked!")
            return
        
        # Prepare attack parameters
        attack_params = {
            'hash': hash_str,
            'algorithm': algorithm,
            'mode': attack_mode,
            'salt': salt,
            'salt_position': salt_position,
            'use_multiprocessing': self.use_multiprocessing.get(),
            'process_count': int(self.process_count.get())
        }
        
        # Mode-specific validation
        if attack_mode == "dictionary":
            if not hasattr(self, 'wordlist_entry') or not self.wordlist_entry.get():
                messagebox.showerror("Error", "Please select a wordlist file.")
                return
            attack_params['wordlist'] = self.wordlist_entry.get()
        
        elif attack_mode == "brute_force":
            charset = ""
            if self.lowercase_var.get():
                charset += string.ascii_lowercase
            if self.uppercase_var.get():
                charset += string.ascii_uppercase
            if self.digits_var.get():
                charset += string.digits
            if self.symbols_var.get():
                charset += string.punctuation
            
            if not charset:
                messagebox.showerror("Error", "Please select at least one character set.")
                return
            
            attack_params['charset'] = charset
            attack_params['min_length'] = int(self.min_length.get())
            attack_params['max_length'] = int(self.max_length.get())
        
        elif attack_mode == "mask":
            if not hasattr(self, 'mask_entry') or not self.mask_entry.get():
                messagebox.showerror("Error", "Please enter a mask pattern.")
                return
            attack_params['mask'] = self.mask_entry.get()
        
        elif attack_mode == "rules":
            if not hasattr(self, 'rules_wordlist_entry') or not self.rules_wordlist_entry.get():
                messagebox.showerror("Error", "Please select a base wordlist.")
                return
            if not hasattr(self, 'rules_file_entry') or not self.rules_file_entry.get():
                messagebox.showerror("Error", "Please select a rules file.")
                return
            attack_params['wordlist'] = self.rules_wordlist_entry.get()
            attack_params['rules_file'] = self.rules_file_entry.get()
        
        elif attack_mode == "combinator":
            if not hasattr(self, 'combinator_wordlist1_entry') or not self.combinator_wordlist1_entry.get():
                messagebox.showerror("Error", "Please select the first wordlist.")
                return
            if not hasattr(self, 'combinator_wordlist2_entry') or not self.combinator_wordlist2_entry.get():
                messagebox.showerror("Error", "Please select the second wordlist.")
                return
            attack_params['wordlist1'] = self.combinator_wordlist1_entry.get()
            attack_params['wordlist2'] = self.combinator_wordlist2_entry.get()
        
        # Store session data
        self.session_data = attack_params.copy()
        self.session_data['start_time'] = time.time()
        
        # Start attack
        self.running = True
        self.paused.set()
        self.processed_count = 0
        self.start_time = time.time()
        
        self.start_button.config(state=tk.DISABLED)
        self.stop_button.config(state=tk.NORMAL)
        self.pause_button.config(state=tk.NORMAL)
        
        self.progress.config(mode='indeterminate')
        self.progress.start()
        
        self.console_log(f"Starting {attack_mode} attack on {algorithm} hash...")
        if salt:
            self.console_log(f"Using salt: {salt} (position: {salt_position})")
        self.console_log(f"Target: {hash_str[:32]}{'...' if len(hash_str) > 32 else ''}")
        
        # Start attack in separate thread
        self.cracking_thread = threading.Thread(target=self.execute_attack, args=(attack_params,))
        self.cracking_thread.daemon = True
        self.cracking_thread.start()
    
    def execute_attack(self, params):
        """Execute the hash cracking attack"""
        try:
            mode = params['mode']
            
            if mode == "dictionary":
                self._execute_dictionary_attack(params)
            elif mode == "brute_force":
                self._execute_brute_force_attack(params)
            elif mode == "mask":
                self._execute_mask_attack(params)
            elif mode == "rules":
                self._execute_rules_attack(params)
            elif mode == "combinator":
                self._execute_combinator_attack(params)
            elif mode == "hybrid":
                self._execute_hybrid_attack(params)
            
        except Exception as e:
            self.update_queue.put(lambda: self.console_log(f"Attack error: {e}"))
            logger.error(f"Attack execution error: {e}")
        finally:
            self.running = False
            self.update_queue.put(self.attack_finished)
    
    def _execute_dictionary_attack(self, params):
        """Execute dictionary attack with multiprocessing support"""
        wordlist_path = params['wordlist']
        target_hash = params['hash']
        algorithm = params['algorithm']
        salt = params['salt']
        salt_position = params['salt_position']
        use_mp = params['use_multiprocessing']
        
        try:
            # Load passwords into memory for multiprocessing
            passwords = []
            with open(wordlist_path, 'r', encoding='utf-8', errors='ignore') as f:
                for line in f:
                    password = line.strip()
                    if password:
                        passwords.append(password)
            
            self.total_passwords = len(passwords)
            self.update_queue.put(lambda: self.console_log(f"Loaded {self.total_passwords:,} passwords"))
            
            # Try multiprocessing first if enabled
            if use_mp and len(passwords) > 1000:
                num_processes = params['process_count']
                self.update_queue.put(lambda: self.console_log(f"Using multiprocessing with {num_processes} processes"))
                
                result = self.core.multiprocess_crack(passwords, target_hash, algorithm, salt, salt_position, num_processes)
                
                if result and result.get('found'):
                    password = result['password']
                    self.update_queue.put(lambda: self.console_log(f"PASSWORD FOUND: {password}"))
                    self.save_to_potfile(target_hash, password, algorithm, salt, salt_position)
                    return
            
            # Fallback to single-threaded
            self.update_queue.put(lambda: self.console_log("Using single-threaded approach"))
            
            for i, password in enumerate(passwords):
                if not self.running:
                    break
                
                self.paused.wait()
                
                if self.core.check_hash_with_salt(password, target_hash, algorithm, salt, salt_position):
                    self.update_queue.put(lambda: self.console_log(f"PASSWORD FOUND: {password}"))
                    self.save_to_potfile(target_hash, password, algorithm, salt, salt_position)
                    return
                
                self.processed_count += 1
                
                if i % 1000 == 0:
                    self.update_statistics()
            
            self.update_queue.put(lambda: self.console_log("Dictionary attack completed. Password not found."))
            
        except FileNotFoundError:
            self.update_queue.put(lambda: self.console_log(f"Wordlist file not found: {wordlist_path}"))
        except Exception as e:
            self.update_queue.put(lambda: self.console_log(f"Dictionary attack error: {e}"))
    
    def _execute_brute_force_attack(self, params):
        """Execute brute force attack"""
        charset = params['charset']
        min_len = params['min_length']
        max_len = params['max_length']
        target_hash = params['hash']
        algorithm = params['algorithm']
        salt = params['salt']
        salt_position = params['salt_position']
        
        self.update_queue.put(lambda: self.console_log(f"Brute force: charset='{charset}' length={min_len}-{max_len}"))
        
        for length in range(min_len, max_len + 1):
            if not self.running:
                break
            
            self.update_queue.put(lambda l=length: self.console_log(f"Trying passwords of length {l}..."))
            
            for password_tuple in itertools.product(charset, repeat=length):
                if not self.running:
                    break
                
                self.paused.wait()
                
                password = ''.join(password_tuple)
                
                if self.core.check_hash_with_salt(password, target_hash, algorithm, salt, salt_position):
                    self.update_queue.put(lambda p=password: self.console_log(f"PASSWORD FOUND: {p}"))
                    self.save_to_potfile(target_hash, password, algorithm, salt, salt_position)
                    return
                
                self.processed_count += 1
                
                if self.processed_count % 10000 == 0:
                    self.update_statistics()
        
        self.update_queue.put(lambda: self.console_log("Brute force attack completed. Password not found."))
    
    def _execute_mask_attack(self, params):
        """Execute mask attack"""
        mask = params['mask']
        target_hash = params['hash']
        algorithm = params['algorithm']
        salt = params['salt']
        salt_position = params['salt_position']
        
        self.update_queue.put(lambda: self.console_log(f"Mask attack: pattern='{mask}'"))
        
        try:
            # Use core's mask generation
            mask_charsets = {
                '?l': string.ascii_lowercase,
                '?u': string.ascii_uppercase,
                '?d': string.digits,
                '?s': string.punctuation,
                '?a': string.ascii_letters + string.digits + string.punctuation
            }
            
            # Parse mask
            charsets = []
            i = 0
            while i < len(mask):
                if i + 1 < len(mask) and mask[i:i+2] in mask_charsets:
                    charsets.append(mask_charsets[mask[i:i+2]])
                    i += 2
                else:
                    charsets.append([mask[i]])
                    i += 1
            
            total_combinations = 1
            for charset in charsets:
                total_combinations *= len(charset)
            
            self.update_queue.put(lambda: self.console_log(f"Total combinations: {total_combinations:,}"))
            
            for password_tuple in itertools.product(*charsets):
                if not self.running:
                    break
                
                self.paused.wait()
                
                password = ''.join(password_tuple)
                
                if self.core.check_hash_with_salt(password, target_hash, algorithm, salt, salt_position):
                    self.update_queue.put(lambda p=password: self.console_log(f"PASSWORD FOUND: {p}"))
                    self.save_to_potfile(target_hash, password, algorithm, salt, salt_position)
                    return
                
                self.processed_count += 1
                
                if self.processed_count % 10000 == 0:
                    self.update_statistics()
            
            self.update_queue.put(lambda: self.console_log("Mask attack completed. Password not found."))
            
        except Exception as e:
            self.update_queue.put(lambda: self.console_log(f"Mask attack error: {e}"))
    
    def _execute_rules_attack(self, params):
        """Execute rules-based attack"""
        wordlist_path = params['wordlist']
        rules_file = params['rules_file']
        target_hash = params['hash']
        algorithm = params['algorithm']
        salt = params['salt']
        salt_position = params['salt_position']
        
        try:
            # Load rules
            with open(rules_file, 'r') as f:
                rules = [line.strip() for line in f if line.strip() and not line.startswith('#')]
            
            self.update_queue.put(lambda: self.console_log(f"Loaded {len(rules)} rules"))
            
            # Process wordlist with rules
            with open(wordlist_path, 'r', encoding='utf-8', errors='ignore') as f:
                for word in f:
                    if not self.running:
                        break
                    
                    word = word.strip()
                    if not word:
                        continue
                    
                    # Apply rules to generate variants
                    variants = self.core.rules_engine.apply_rules(word, rules)
                    
                    for variant in variants:
                        if not self.running:
                            break
                        
                        self.paused.wait()
                        
                        if self.core.check_hash_with_salt(variant, target_hash, algorithm, salt, salt_position):
                            self.update_queue.put(lambda v=variant, w=word: self.console_log(f"PASSWORD FOUND: {v} (from '{w}')"))
                            self.save_to_potfile(target_hash, variant, algorithm, salt, salt_position)
                            return
                        
                        self.processed_count += 1
                        
                        if self.processed_count % 1000 == 0:
                            self.update_statistics()
            
            self.update_queue.put(lambda: self.console_log("Rules attack completed. Password not found."))
            
        except FileNotFoundError as e:
            self.update_queue.put(lambda: self.console_log(f"File not found: {e}"))
        except Exception as e:
            self.update_queue.put(lambda: self.console_log(f"Rules attack error: {e}"))
    
    def _execute_combinator_attack(self, params):
        """Execute combinator attack"""
        wordlist1_path = params['wordlist1']
        wordlist2_path = params['wordlist2']
        target_hash = params['hash']
        algorithm = params['algorithm']
        salt = params['salt']
        salt_position = params['salt_position']
        
        try:
            # Load first wordlist
            with open(wordlist1_path, 'r', encoding='utf-8', errors='ignore') as f:
                wordlist1 = [line.strip() for line in f if line.strip()]
            
            # Load second wordlist
            with open(wordlist2_path, 'r', encoding='utf-8', errors='ignore') as f:
                wordlist2 = [line.strip() for line in f if line.strip()]
            
            total_combinations = len(wordlist1) * len(wordlist2)
            self.update_queue.put(lambda: self.console_log(f"Combinator: {len(wordlist1)} x {len(wordlist2)} = {total_combinations:,} combinations"))
            
            # Generate combinations
            for word1 in wordlist1:
                if not self.running:
                    break
                
                for word2 in wordlist2:
                    if not self.running:
                        break
                    
                    self.paused.wait()
                    
                    password = word1 + word2
                    
                    if self.core.check_hash_with_salt(password, target_hash, algorithm, salt, salt_position):
                        self.update_queue.put(lambda p=password, w1=word1, w2=word2: 
                                            self.console_log(f"PASSWORD FOUND: {p} ('{w1}' + '{w2}')"))
                        self.save_to_potfile(target_hash, password, algorithm, salt, salt_position)
                        return
                    
                    self.processed_count += 1
                    
                    if self.processed_count % 1000 == 0:
                        self.update_statistics()
            
            self.update_queue.put(lambda: self.console_log("Combinator attack completed. Password not found."))
            
        except FileNotFoundError as e:
            self.update_queue.put(lambda: self.console_log(f"Wordlist file not found: {e}"))
        except Exception as e:
            self.update_queue.put(lambda: self.console_log(f"Combinator attack error: {e}"))
    
    def _execute_hybrid_attack(self, params):
        """Execute hybrid attack (placeholder)"""
        self.update_queue.put(lambda: self.console_log("Hybrid attack mode is not yet implemented."))
    
    def update_statistics(self):
        """Update attack statistics in real-time"""
        current_time = time.time()
        elapsed = current_time - self.start_time
        
        if elapsed > 0:
            self.current_speed = self.processed_count / elapsed
            
            eta = "Unknown"
            if self.total_passwords > 0 and self.current_speed > 0:
                remaining = self.total_passwords - self.processed_count
                eta_seconds = remaining / self.current_speed
                eta = self.core.estimate_time(remaining, self.current_speed)
            
            self.update_queue.put(lambda: self.speed_label.config(text=f"Speed: {self.current_speed:,.0f} H/s"))
            self.update_queue.put(lambda: self.processed_label.config(text=f"Processed: {self.processed_count:,}"))
            self.update_queue.put(lambda: self.eta_label.config(text=f"ETA: {eta}"))
            
            if self.total_passwords > 0:
                progress = (self.processed_count / self.total_passwords) * 100
                self.update_queue.put(lambda: self.progress.config(mode='determinate', value=progress))
    
    def stop_attack(self):
        """Stop the current attack"""
        self.running = False
        self.console_log("Stopping attack...")
    
    def pause_resume(self):
        """Pause or resume the attack"""
        if self.paused.is_set():
            self.paused.clear()
            self.pause_button.config(text="Resume")
            self.console_log("Attack paused.")
        else:
            self.paused.set()
            self.pause_button.config(text="Pause")
            self.console_log("Attack resumed.")
    
    def attack_finished(self):
        """Called when attack finishes"""
        self.start_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)
        self.pause_button.config(state=tk.DISABLED, text="Pause")
        self.progress.stop()
        self.progress.config(mode='determinate', value=0)
        self.paused.set()
        self.console_log("Attack finished.")
    
    # Database operations
    def save_to_potfile(self, hash_value, password, algorithm, salt="", salt_position="suffix"):
        """Save cracked password to potfile"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO potfile (hash, password, algorithm, salt, salt_position, session_id)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (hash_value, password, algorithm, salt, salt_position, getattr(self, 'current_session_id', '')))
            conn.commit()
            conn.close()
            self.console_log(f"Saved to potfile: {hash_value[:32]}... -> {password}")
        except Exception as e:
            logger.error(f"Error saving to potfile: {e}")
    
    def check_potfile(self, hash_value, algorithm, salt=""):
        """Check if hash is already cracked in potfile"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                SELECT password FROM potfile
                WHERE hash = ? AND algorithm = ? AND salt = ?
                ORDER BY cracked_time DESC LIMIT 1
            ''', (hash_value, algorithm, salt))
            result = cursor.fetchone()
            conn.close()
            return result[0] if result else None
        except Exception as e:
            logger.error(f"Error checking potfile: {e}")
            return None
    
    # Session management
    def save_session(self):
        """Save current session"""
        if not hasattr(self, 'session_data') or not self.session_data:
            messagebox.showwarning("Warning", "No active session to save.")
            return
        
        session_id = f"session_{int(time.time())}"
        session_name = f"Session {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO sessions (session_id, name, algorithm, attack_mode, target_hash, 
                                    salt, configuration, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (session_id, session_name, self.session_data.get('algorithm', ''),
                  self.session_data.get('mode', ''), self.session_data.get('hash', ''),
                  self.session_data.get('salt', ''), json.dumps(self.session_data), 'saved'))
            conn.commit()
            conn.close()
            
            self.console_log(f"Session saved: {session_name}")
            self.refresh_sessions()
            
        except Exception as e:
            logger.error(f"Error saving session: {e}")
            messagebox.showerror("Error", f"Failed to save session: {e}")
    
    def load_session(self):
        """Load a saved session"""
        # Get selected session from tree
        selection = self.sessions_tree.selection()
        if not selection:
            messagebox.showwarning("Warning", "Please select a session to load.")
            return
        
        item = self.sessions_tree.item(selection[0])
        session_id = item['values'][0]
        
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('SELECT configuration FROM sessions WHERE session_id = ?', (session_id,))
            result = cursor.fetchone()
            conn.close()
            
            if result:
                config = json.loads(result[0])
                
                # Restore UI state
                self.hash_entry.delete(0, tk.END)
                self.hash_entry.insert(0, config.get('hash', ''))
                
                self.salt_entry.delete(0, tk.END)
                self.salt_entry.insert(0, config.get('salt', ''))
                
                self.salt_position.set(config.get('salt_position', 'suffix'))
                self.algorithm_var.set(config.get('algorithm', ''))
                self.attack_mode.set(config.get('mode', 'dictionary'))
                
                self.update_attack_options()
                
                # Restore attack-specific options
                if config.get('mode') == 'dictionary' and 'wordlist' in config:
                    if hasattr(self, 'wordlist_entry'):
                        self.wordlist_entry.delete(0, tk.END)
                        self.wordlist_entry.insert(0, config['wordlist'])
                
                self.session_data = config
                self.console_log(f"Session loaded: {session_id}")
                
        except Exception as e:
            logger.error(f"Error loading session: {e}")
            messagebox.showerror("Error", f"Failed to load session: {e}")
    
    def refresh_sessions(self):
        """Refresh the sessions list"""
        # Clear existing items
        for item in self.sessions_tree.get_children():
            self.sessions_tree.delete(item)
        
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                SELECT session_id, name, algorithm, attack_mode, created_time, status
                FROM sessions ORDER BY created_time DESC
            ''')
            
            for row in cursor.fetchall():
                self.sessions_tree.insert('', tk.END, values=row)
            
            conn.close()
        except Exception as e:
            logger.error(f"Error refreshing sessions: {e}")
    
    def new_session(self):
        """Start a new session"""
        # Clear current session
        self.session_data = {}
        
        # Reset UI
        self.hash_entry.delete(0, tk.END)
        self.salt_entry.delete(0, tk.END)
        self.console_text.delete(1.0, tk.END)
        
        self.console_log("New session started.")
    
    # Potfile management
    def refresh_potfile(self):
        """Refresh the potfile viewer"""
        # Clear existing items
        for item in self.potfile_tree.get_children():
            self.potfile_tree.delete(item)
        
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                SELECT hash, password, algorithm, cracked_time
                FROM potfile ORDER BY cracked_time DESC
            ''')
            
            for row in cursor.fetchall():
                # Truncate long hashes for display
                display_hash = row[0][:32] + "..." if len(row[0]) > 35 else row[0]
                display_row = (display_hash, row[1], row[2], row[3])
                self.potfile_tree.insert('', tk.END, values=display_row)
            
            conn.close()
        except Exception as e:
            logger.error(f"Error refreshing potfile: {e}")
    
    def search_potfile(self, event=None):
        """Search potfile"""
        search_term = self.search_entry.get().lower()
        
        # Clear and repopulate with filtered results
        for item in self.potfile_tree.get_children():
            self.potfile_tree.delete(item)
        
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                SELECT hash, password, algorithm, cracked_time
                FROM potfile 
                WHERE LOWER(hash) LIKE ? OR LOWER(password) LIKE ? OR LOWER(algorithm) LIKE ?
                ORDER BY cracked_time DESC
            ''', (f'%{search_term}%', f'%{search_term}%', f'%{search_term}%'))
            
            for row in cursor.fetchall():
                display_hash = row[0][:32] + "..." if len(row[0]) > 35 else row[0]
                display_row = (display_hash, row[1], row[2], row[3])
                self.potfile_tree.insert('', tk.END, values=display_row)
            
            conn.close()
        except Exception as e:
            logger.error(f"Error searching potfile: {e}")
    
    def export_potfile(self):
        """Export potfile to CSV"""
        filename = filedialog.asksaveasfilename(
            title="Export Potfile",
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("Text files", "*.txt"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                import csv
                conn = sqlite3.connect(self.db_path)
                cursor = conn.cursor()
                cursor.execute('SELECT * FROM potfile ORDER BY cracked_time DESC')
                
                with open(filename, 'w', newline='') as f:
                    writer = csv.writer(f)
                    writer.writerow(['ID', 'Hash', 'Password', 'Algorithm', 'Salt', 
                                   'Salt Position', 'Cracked Time', 'Session ID'])
                    writer.writerows(cursor.fetchall())
                
                conn.close()
                self.console_log(f"Potfile exported to {filename}")
                
            except Exception as e:
                logger.error(f"Export error: {e}")
                messagebox.showerror("Error", f"Export failed: {e}")
    
    def clear_potfile(self):
        """Clear all potfile entries"""
        if messagebox.askyesno("Confirm", "Clear all cracked passwords from potfile?"):
            try:
                conn = sqlite3.connect(self.db_path)
                cursor = conn.cursor()
                cursor.execute('DELETE FROM potfile')
                conn.commit()
                conn.close()
                
                self.refresh_potfile()
                self.console_log("Potfile cleared.")
                
            except Exception as e:
                logger.error(f"Error clearing potfile: {e}")
                messagebox.showerror("Error", f"Failed to clear potfile: {e}")
    
    # Tools
    def generate_hashes(self):
        """Generate hashes for testing"""
        input_text = self.gen_input.get()
        salt = self.gen_salt.get()
        
        if not input_text:
            messagebox.showwarning("Warning", "Please enter some text to hash.")
            return
        
        self.gen_results.delete(1.0, tk.END)
        self.gen_results.insert(tk.END, f"Hashes for: '{input_text}'\n")
        if salt:
            self.gen_results.insert(tk.END, f"Salt: '{salt}'\n")
        self.gen_results.insert(tk.END, "=" * 60 + "\n\n")
        
        # Generate hashes for common algorithms
        common_algos = ['md5', 'sha1', 'sha256', 'sha512', 'ntlm']
        
        for algo in common_algos:
            try:
                if algo == 'ntlm':
                    hash_result = self.core.hash_impl._pure_python_md4(input_text.encode('utf-16le'))
                elif salt:
                    hash_result = self.core.hash_impl.hash_with_salt(algo, input_text, salt)
                else:
                    hash_result = getattr(hashlib, algo)(input_text.encode()).hexdigest()
                
                self.gen_results.insert(tk.END, f"{algo.upper():<12}: {hash_result}\n")
                
                if salt:
                    # Also show without salt for comparison
                    no_salt_hash = getattr(hashlib, algo)(input_text.encode()).hexdigest()
                    self.gen_results.insert(tk.END, f"{algo.upper()} (no salt): {no_salt_hash}\n")
                
            except Exception as e:
                self.gen_results.insert(tk.END, f"{algo.upper():<12}: Error - {e}\n")
        
        self.gen_results.insert(tk.END, "\n" + "=" * 60)
    
    def run_benchmark(self):
        """Run comprehensive algorithm benchmark"""
        self.bench_results.delete(1.0, tk.END)
        self.bench_results.insert(tk.END, "Starting comprehensive benchmark...\n")
        self.bench_results.insert(tk.END, "This may take several minutes.\n\n")
        
        def benchmark_thread():
            try:
                results = self.core.benchmark()
                self.update_queue.put(lambda: self.display_benchmark_results(results))
            except Exception as e:
                self.update_queue.put(lambda: self.bench_results.insert(tk.END, f"Benchmark error: {e}\n"))
        
        thread = threading.Thread(target=benchmark_thread, daemon=True)
        thread.start()
    
    def display_benchmark_results(self, results):
        """Display benchmark results"""
        self.bench_results.delete(1.0, tk.END)
        self.bench_results.insert(tk.END, "COMPREHENSIVE BENCHMARK RESULTS\n")
        self.bench_results.insert(tk.END, "=" * 80 + "\n\n")
        
        # Group results by category
        categories = {
            'Fast Hashes': ['md5', 'sha1', 'crc32', 'adler32'],
            'SHA Family': ['sha224', 'sha256', 'sha384', 'sha512'],
            'SHA-3': ['sha3_224', 'sha3_256', 'sha3_384', 'sha3_512'],
            'Password Hashing': ['bcrypt', 'pbkdf2_sha256', 'argon2'],
            'Windows/NTLM': ['ntlm', 'md4'],
            'Other': [algo for algo in results.keys() if algo not in 
                     ['md5', 'sha1', 'crc32', 'adler32', 'sha224', 'sha256', 'sha384', 'sha512',
                      'sha3_224', 'sha3_256', 'sha3_384', 'sha3_512', 'bcrypt', 'pbkdf2_sha256', 
                      'argon2', 'ntlm', 'md4']]
        }
        
        for category, algos in categories.items():
            if any(algo in results for algo in algos):
                self.bench_results.insert(tk.END, f"{category}:\n")
                self.bench_results.insert(tk.END, "-" * len(category) + "\n")
                
                for algo in algos:
                    if algo in results:
                        self.bench_results.insert(tk.END, f"  {algo:<20}: {results[algo]}\n")
                
                self.bench_results.insert(tk.END, "\n")
        
        self.bench_results.insert(tk.END, "=" * 80 + "\n")
        self.bench_results.insert(tk.END, "Benchmark completed!\n")
    
    # Menu handlers
    def import_hashes(self):
        """Import multiple hashes from file"""
        filename = filedialog.askopenfilename(
            title="Import Hash List",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if filename:
            self.console_log(f"Hash import functionality coming soon: {filename}")
    
    def export_results(self):
        """Export results"""
        content = self.console_text.get(1.0, tk.END)
        if content.strip():
            filename = filedialog.asksaveasfilename(
                title="Export Results",
                defaultextension=".txt",
                filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
            )
            if filename:
                with open(filename, 'w') as f:
                    f.write(content)
                self.console_log(f"Results exported to {filename}")
    
    def open_hash_generator(self):
        """Switch to hash generator tab"""
        self.notebook.select(2)  # Tools tab
    
    def open_system_monitor(self):
        """Switch to system monitor tab"""
        self.notebook.select(3)  # Monitor tab
    
    def open_potfile_manager(self):
        """Switch to potfile tab"""
        self.notebook.select(4)  # Potfile tab
    
    def show_algorithm_reference(self):
        """Show algorithm reference"""
        ref_window = tk.Toplevel(self.master)
        ref_window.title("Algorithm Reference")
        ref_window.geometry("800x600")
        ref_window.configure(bg="#1e1e1e")
        
        text_widget = scrolledtext.ScrolledText(ref_window, font=('Consolas', 10),
                                              bg='#2d2d30', fg='#ffffff')
        text_widget.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        ref_text = """
ALGORITHM REFERENCE - PyHashCracker Professional
================================================

BASIC HASH ALGORITHMS:
----------------------
MD5          - 128-bit, fast but cryptographically broken
SHA-1        - 160-bit, deprecated for security applications
SHA-224      - 224-bit SHA-2 variant
SHA-256      - 256-bit SHA-2, widely used
SHA-384      - 384-bit SHA-2 variant
SHA-512      - 512-bit SHA-2, secure and fast

SHA-3 FAMILY:
-------------
SHA3-224     - 224-bit SHA-3
SHA3-256     - 256-bit SHA-3
SHA3-384     - 384-bit SHA-3
SHA3-512     - 512-bit SHA-3

PASSWORD HASHING:
-----------------
bcrypt       - Blowfish-based, adjustable cost
PBKDF2       - Key derivation function
Argon2       - Modern, memory-hard function
scrypt       - Memory-hard function

MICROSOFT/WINDOWS:
------------------
NTLM         - Windows NT hash
LM           - Legacy Windows hash (weak)
MD4          - Used by NTLM

DATABASE HASHES:
----------------
MySQL        - Old MySQL password hash
MySQL5       - MySQL 4.1+ password hash
PostgreSQL   - PostgreSQL MD5 hash

SALT SUPPORT:
-------------
Many algorithms support salts to prevent rainbow table attacks.
Salt positions: prefix, suffix, both

PERFORMANCE NOTES:
------------------
- Fast hashes (MD5, SHA-1): 1M+ H/s
- Secure hashes (SHA-256): 500K+ H/s  
- Password hashes (bcrypt): 100-1K H/s
- Memory-hard (Argon2): 10-100 H/s

Use multiprocessing for maximum performance on multi-core systems.
        """
        
        text_widget.insert(tk.END, ref_text)
        text_widget.config(state=tk.DISABLED)
    
    def show_attack_guide(self):
        """Show attack modes guide"""
        guide_window = tk.Toplevel(self.master)
        guide_window.title("Attack Modes Guide")
        guide_window.geometry("800x600")
        guide_window.configure(bg="#1e1e1e")
        
        text_widget = scrolledtext.ScrolledText(guide_window, font=('Consolas', 10),
                                              bg='#2d2d30', fg='#ffffff')
        text_widget.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        guide_text = """
ATTACK MODES GUIDE - PyHashCracker Professional
===============================================

DICTIONARY ATTACK:
------------------
Uses a wordlist file containing common passwords.
- Fastest for common passwords
- Effectiveness depends on wordlist quality
- Supports multiprocessing for speed
- Best for: Common passwords, leaked password lists

BRUTE FORCE ATTACK:
-------------------
Tries all possible character combinations.
- Guaranteed to find password (given enough time)
- Very slow for long passwords
- Exponential time complexity
- Best for: Short passwords, known patterns

MASK ATTACK:
------------
Pattern-based generation using placeholders.
- More efficient than pure brute force
- Requires knowledge of password pattern
- Placeholders: ?l ?u ?d ?s ?a
- Best for: Known password patterns

RULES ATTACK:
-------------
Applies transformation rules to base words.
- Combines dictionary efficiency with variations
- Uses Hashcat-style rule syntax
- Common transformations: capitalization, appending numbers
- Best for: Password variations of common words

COMBINATOR ATTACK:
------------------
Combines words from two wordlists.
- Effective for composite passwords
- Can generate large candidate sets
- Memory efficient streaming
- Best for: Password + suffix patterns

HYBRID ATTACK:
--------------
Combines multiple attack methods.
- Dictionary + mask combinations
- Rules + brute force combinations
- Maximum flexibility
- Best for: Complex password policies

PERFORMANCE TIPS:
-----------------
1. Start with dictionary attacks (fastest)
2. Use rules to expand dictionary coverage
3. Enable multiprocessing for CPU-bound algorithms
4. Use mask attacks when pattern is known
5. Save sessions for long-running attacks

SALT CONSIDERATIONS:
--------------------
- Many real-world hashes use salts
- Always check if salt is available
- Salt position affects hash computation
- Slows down attacks but increases security
        """
        
        text_widget.insert(tk.END, guide_text)
        text_widget.config(state=tk.DISABLED)
    
    def show_performance_tips(self):
        """Show performance optimization tips"""
        tips_window = tk.Toplevel(self.master)
        tips_window.title("Performance Optimization Tips")
        tips_window.geometry("800x600")
        tips_window.configure(bg="#1e1e1e")
        
        text_widget = scrolledtext.ScrolledText(tips_window, font=('Consolas', 10),
                                              bg='#2d2d30', fg='#ffffff')
        text_widget.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        tips_text = """
PERFORMANCE OPTIMIZATION TIPS
==============================

MULTIPROCESSING:
----------------
✓ Enable multiprocessing for CPU-bound algorithms
✓ Use 4-8 processes for optimal performance
✓ More processes ≠ always faster (overhead)
✓ Best for: MD5, SHA family, NTLM

ALGORITHM SELECTION:
--------------------
• Fast hashes: MD5, SHA-1, CRC32 (1M+ H/s)
• Medium hashes: SHA-256, SHA-512 (500K+ H/s)
• Slow hashes: bcrypt, Argon2 (100 H/s)
• Choose based on target hash type

WORDLIST OPTIMIZATION:
----------------------
• Use high-quality, targeted wordlists
• Remove duplicates to avoid wasted cycles
• Sort by probability (most common first)
• Consider custom wordlists for targets

ATTACK STRATEGY:
----------------
1. Check potfile first (instant if already cracked)
2. Start with small, high-quality wordlists
3. Use rules to expand coverage efficiently
4. Progress to larger wordlists
5. Use brute force only for short passwords

HARDWARE CONSIDERATIONS:
------------------------
• CPU: More cores = better multiprocessing
• RAM: Large wordlists require memory
• Storage: Fast SSD improves wordlist loading
• Consider GPU acceleration for massive speed gains

SYSTEM OPTIMIZATION:
--------------------
• Close unnecessary applications
• Monitor CPU and memory usage
• Use task manager to set process priority
• Ensure adequate cooling for sustained load

SESSION MANAGEMENT:
-------------------
• Save sessions before long attacks
• Resume interrupted attacks
• Monitor progress with ETA estimates
• Plan attack sequences in advance

WORDLIST SOURCES:
-----------------
• SecLists: Comprehensive collection
• RockYou: Common leaked passwords  
• Custom: Target-specific wordlists
• Hybrid: Combine multiple sources

WHEN TO STOP:
-------------
• Password found (obvious)
• ETA exceeds reasonable time
• Diminishing returns on wordlist expansion
• Move to different attack vector

GPU ACCELERATION (Future):
--------------------------
• 100x-1000x speed improvement possible
• Requires specialized software/hardware
• Most effective for fast hash algorithms
• Consider Hashcat for GPU cracking
        """
        
        text_widget.insert(tk.END, tips_text)
        text_widget.config(state=tk.DISABLED)
    
    def show_about(self):
        """Show about dialog"""
        about_text = """
PyHashCracker Professional Edition
Version 3.0

A comprehensive, professional-grade password recovery and hash cracking tool.

🚀 PROFESSIONAL FEATURES:
• 100+ Hash algorithms with salt support
• Multiprocessing for maximum performance  
• Advanced session management with save/resume
• Enhanced rules engine (Hashcat-style)
• Combinator and hybrid attacks
• Real-time statistics and ETA calculation
• Comprehensive potfile management
• System resource monitoring
• Professional dark UI theme

🔧 TECHNICAL CAPABILITIES:
• Multi-threaded GUI architecture
• SQLite database for persistence
• Advanced hash detection algorithms
• Professional logging and error handling
• Extensible plugin architecture
• Memory-efficient processing

⚡ PERFORMANCE OPTIMIZATIONS:
• Intelligent multiprocessing
• Memory-mapped file handling
• Optimized algorithms
• Real-time progress tracking
• System resource monitoring

🛡️ SECURITY FEATURES:
• Comprehensive salt support
• Secure hash implementations
• Session encryption
• Audit trail logging

📊 SUPPORTED ALGORITHMS:
Basic: MD5, SHA family, CRC variants
Advanced: bcrypt, Argon2, PBKDF2, scrypt
Windows: NTLM, LM, MD4
Database: MySQL, PostgreSQL
Specialized: GOST, HAVAL, BLAKE2, Whirlpool

🎯 ATTACK MODES:
• Dictionary attacks with rules
• Intelligent brute force
• Pattern-based mask attacks
• Combinator attacks
• Hybrid methodologies
• Session persistence

⚠️ LEGAL NOTICE:
This tool is designed for authorized security testing, 
password recovery, and educational purposes only.

Author: Enhanced by AI Assistant
License: Educational and Authorized Testing Only
        """
        messagebox.showinfo("About PyHashCracker Professional", about_text)


def main():
    """Main application entry point"""
    try:
        # Set up multiprocessing for Windows compatibility
        if hasattr(multiprocessing, 'set_start_method'):
            try:
                multiprocessing.set_start_method('spawn', force=True)
            except RuntimeError:
                pass  # Already set
        
        root = tk.Tk()
        app = ProfessionalHashcrackerGUI(root)
        
        # Startup message
        app.console_log("PyHashCracker Professional Edition - Version 3.0")
        app.console_log("=" * 60)
        app.console_log(f"Loaded {len(app.core.algorithms)} hash algorithms")
        app.console_log(f"CPU cores available: {multiprocessing.cpu_count()}")
        
        if PASSLIB_AVAILABLE:
            app.console_log("✓ Advanced password hashing enabled (passlib)")
        else:
            app.console_log("⚠ passlib not available - some algorithms disabled")
        
        if PSUTIL_AVAILABLE:
            app.console_log("✓ System monitoring enabled (psutil)")
        else:
            app.console_log("⚠ psutil not available - system monitoring limited")
        
        app.console_log("Ready for professional hash cracking!")
        app.console_log("💡 Pro tip: Check the Algorithm Reference in Help menu")
        
        # Handle Ctrl+C gracefully
        def signal_handler(sig, frame):
            app.console_log("Shutdown signal received...")
            root.quit()
        
        signal.signal(signal.SIGINT, signal_handler)
        
        root.mainloop()
        
    except KeyboardInterrupt:
        print("Application interrupted by user")
    except Exception as e:
        print(f"Application error: {e}")
        logger.error(f"Main application error: {e}")


if __name__ == '__main__':
    main()