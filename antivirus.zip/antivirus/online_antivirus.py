import os
import hashlib
import requests
import threading
import json
import time
import base64
import customtkinter as ctk
from tkinter import filedialog, messagebox, simpledialog
from datetime import datetime
import sys # For platform check

# --- Constants ---
API_BASE = "https://www.virustotal.com/api/v3"
CONFIG_FILE = "vt_config.json"
HISTORY_FILE = "vt_scan_history.json"
DEFAULT_POLL_INTERVAL = 15 # Increased polling interval for public API
DEFAULT_POLL_TIMEOUT = 300 # Increased timeout
# Basic rate limiting for public API (4 requests/min) - sleep slightly more than 15s
RATE_LIMIT_SLEEP = 16
# Define colors for results (adjust as needed for theme)
COLOR_MALICIOUS = "#FF5555" # Red
COLOR_SUSPICIOUS = "#FFAF00" # Orange
COLOR_CLEAN = "#50FA7B" # Green
COLOR_INFO = "#8BE9FD" # Cyan
COLOR_ERROR = "#FFB86C" # Orange/Yellow for errors

# --- Helper Functions ---

def compute_hash(file_path, algo="sha256"):
    """Computes the hash of a file."""
    try:
        h = hashlib.new(algo)
        with open(file_path, "rb") as f:
            while chunk := f.read(8192):
                h.update(chunk)
        return h.hexdigest()
    except FileNotFoundError:
        print(f"Error: File not found for hashing: {file_path}")
        return None
    except PermissionError:
        print(f"Error: Permission denied for hashing: {file_path}")
        return None
    except Exception as e:
        print(f"Error hashing file {file_path} ({algo}): {e}")
        return None

def url_to_id(url):
    """Encodes a URL to the format VirusTotal uses for IDs."""
    return base64.urlsafe_b64encode(url.encode()).decode().strip("=")

def get_vt_report_url(item_id, is_url=False):
    """Generates the VirusTotal web report URL."""
    base = "https://www.virustotal.com/gui"
    return f"{base}/url/{item_id}/detection" if is_url else f"{base}/file/{item_id}/detection"

# --- Toast Notification ---
# (Keep existing show_toast function - it's good)
def show_toast(parent, msg, duration=3000, bgcolor="#282A36", fgcolor="#F8F8F2"):
    """Displays a temporary notification window."""
    try:
        t = ctk.CTkToplevel(parent)
        t.overrideredirect(True)
        # Added padding and improved look
        lbl = ctk.CTkLabel(t, text=msg, fg_color=bgcolor, text_color=fgcolor, corner_radius=8, padx=15, pady=8, font=("Roboto", 12))
        lbl.pack(padx=1, pady=1) # Pack inside with border effect

        # Center toast relative to parent approx
        parent.update_idletasks() # Ensure parent geometry is updated
        parent_x = parent.winfo_x()
        parent_y = parent.winfo_y()
        parent_width = parent.winfo_width()
        # parent_height = parent.winfo_height() # Not needed for top position

        t.update_idletasks() # Ensure toast geometry is updated
        toast_width = t.winfo_width()
        # toast_height = t.winfo_height() # Not needed

        # Position near top-center of parent window
        x = parent_x + (parent_width // 2) - (toast_width // 2)
        y = parent_y + 30 # Offset from top
        t.geometry(f"+{x}+{y}")

        t.attributes("-topmost", True) # Keep toast on top
        t.after(duration, t.destroy)
    except Exception as e:
        print(f"Error showing toast: {e}") # Log error if toast fails


# --- Main Application Class ---
class AntivirusApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("pyGuard Antivirus v2.0") # Renamed title
        self.geometry("700x1050") # Slightly larger window

        # State Variables
        self.api_key = ""
        self.headers = {}
        self.config = {}
        self.history = []
        self.scanning = False
        self.scan_thread = None
        self.start_time = 0
        self.current_scan_item_count = 0
        self.total_scan_items = 0
        self.exclusions = [] # List of lowercase file extensions to exclude

        # Load configuration and history first
        self.load_config()
        self.load_history()

        # Appearance (Set based on loaded config)
        ctk.set_appearance_mode(self.config.get("theme", "dark"))
        ctk.set_default_color_theme("dark-blue")

        # Build UI
        self.build_ui()
        self.refresh_history_display() # Refresh history display after UI build

        # Pydroid 3 Check (Informational)
        if hasattr(sys, 'getandroidapilevel'):
            self.log("Info: Running on Android (Pydroid 3). File system access might be restricted by OS.")

    # --- UI Building ---
    def build_ui(self):
        """Builds the main user interface."""
        main_frame = ctk.CTkFrame(self)
        main_frame.pack(fill="both", expand=True, padx=10, pady=10)

        # --- Tabs ---
        self.tabs = ctk.CTkTabview(main_frame, anchor="nw")
        self.tabs.pack(fill="both", expand=True, padx=5, pady=5)
        tab_names = ["Dashboard", "Scan", "Results", "History", "Logs", "Settings"]
        for tab_name in tab_names:
            self.tabs.add(tab_name)

        # Build individual tabs
        self.build_dashboard_tab()
        self.build_scan_tab()
        self.build_results_tab() # Added separate Results tab
        self.build_history_tab()
        self.build_logs_tab()
        self.build_settings_tab()

        # --- Status Bar ---
        status_bar_frame = ctk.CTkFrame(self, height=30)
        status_bar_frame.pack(fill="x", side="bottom", padx=10, pady=(0, 10))
        self.status_label = ctk.CTkLabel(status_bar_frame, text="Status: Ready", anchor="w")
        self.status_label.pack(side="left", fill="x", padx=10, pady=5)

        # Select Scan tab by default
        self.tabs.set("Scan")


    def build_dashboard_tab(self):
        """Builds the Dashboard tab content."""
        dashboard_tab = self.tabs.tab("Dashboard")
        ctk.CTkLabel(dashboard_tab, text="Welcome to pyGuard", font=("Roboto", 28, "bold")).pack(pady=(20, 10)) # Renamed text

        # Quick Stats Frame
        stats_frame = ctk.CTkFrame(dashboard_tab)
        stats_frame.pack(pady=10, padx=20, fill="x")
        ctk.CTkLabel(stats_frame, text="Scan Summary:", font=("Roboto", 16, "bold")).pack(anchor="w", pady=(5,10))

        self.dashboard_total_scans_label = ctk.CTkLabel(stats_frame, text="Total Scans: 0", font=("Roboto", 14))
        self.dashboard_total_scans_label.pack(anchor="w", padx=10)
        self.dashboard_malicious_label = ctk.CTkLabel(stats_frame, text="Malicious Found: 0", font=("Roboto", 14), text_color=COLOR_MALICIOUS)
        self.dashboard_malicious_label.pack(anchor="w", padx=10)
        self.dashboard_suspicious_label = ctk.CTkLabel(stats_frame, text="Suspicious Found: 0", font=("Roboto", 14), text_color=COLOR_SUSPICIOUS)
        self.dashboard_suspicious_label.pack(anchor="w", padx=10)

        # Quick Actions Frame
        actions_frame = ctk.CTkFrame(dashboard_tab)
        actions_frame.pack(pady=10, padx=20, fill="x")
        ctk.CTkLabel(actions_frame, text="Quick Actions:", font=("Roboto", 16, "bold")).pack(anchor="w", pady=(5,10))
        ctk.CTkButton(actions_frame, text="Start New File Scan", command=self.select_file).pack(pady=5, fill="x")
        ctk.CTkButton(actions_frame, text="Start New URL Scan", command=lambda: self.tabs.set("Scan")).pack(pady=5, fill="x") # Go to Scan tab

        self.update_dashboard_stats() # Initial update


    def build_scan_tab(self):
        """Builds the Scan tab content."""
        scan_tab = self.tabs.tab("Scan")

        # --- Scan Options Frame ---
        options_frame = ctk.CTkFrame(scan_tab)
        options_frame.pack(fill="x", pady=10, padx=10)

        ctk.CTkLabel(options_frame, text="Scan Mode:", anchor="w").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.scan_mode_button = ctk.CTkSegmentedButton(options_frame, values=["hash-only", "auto-upload"], command=self.update_config_from_ui)
        self.scan_mode_button.set(self.config.get("scan_mode", "hash-only"))
        self.scan_mode_button.grid(row=0, column=1, padx=5, pady=5, sticky="w")

        ctk.CTkLabel(options_frame, text="Hash Algorithm:", anchor="w").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.hash_algo_button = ctk.CTkSegmentedButton(options_frame, values=["sha256", "sha1", "md5"], command=self.update_config_from_ui)
        self.hash_algo_button.set(self.config.get("hash_algo", "sha256"))
        self.hash_algo_button.grid(row=1, column=1, padx=5, pady=5, sticky="w")


        # --- Input Frame (URL/Hash) ---
        input_frame = ctk.CTkFrame(scan_tab)
        input_frame.pack(fill="x", pady=10, padx=10)

        self.url_entry = ctk.CTkEntry(input_frame, placeholder_text="Enter URL to scan...")
        self.url_entry.pack(side="left", expand=True, fill="x", padx=(0,5), pady=5)
        ctk.CTkButton(input_frame, text="Scan URL", width=100, command=self.scan_url).pack(side="left", padx=5, pady=5)

        input_frame2 = ctk.CTkFrame(scan_tab)
        input_frame2.pack(fill="x", pady=(0,10), padx=10)

        self.hash_entry = ctk.CTkEntry(input_frame2, placeholder_text="Enter Hash (SHA256/SHA1/MD5) to lookup...")
        self.hash_entry.pack(side="left", expand=True, fill="x", padx=(0,5), pady=5)
        ctk.CTkButton(input_frame2, text="Lookup Hash", width=100, command=self.lookup_hash).pack(side="left", padx=5, pady=5)


        # --- File/Folder Selection Frame ---
        file_frame = ctk.CTkFrame(scan_tab)
        file_frame.pack(fill="x", pady=10, padx=10)

        ctk.CTkButton(file_frame, text="Scan File", command=self.select_file).pack(side="left", padx=5, pady=5)
        ctk.CTkButton(file_frame, text="Scan Folder", command=self.select_folder).pack(side="left", padx=5, pady=5)

        # --- Progress & Cancel Frame ---
        progress_frame = ctk.CTkFrame(scan_tab)
        progress_frame.pack(fill="x", pady=10, padx=10)

        self.progress_bar = ctk.CTkProgressBar(progress_frame, progress_color=COLOR_CLEAN)
        self.progress_bar.set(0)
        self.progress_bar.pack(side="left", fill="x", expand=True, padx=(0, 5), pady=5)

        self.progress_label = ctk.CTkLabel(progress_frame, text="0%", width=40)
        self.progress_label.pack(side="left", padx=5, pady=5)

        self.cancel_button = ctk.CTkButton(progress_frame, text="Cancel Scan", state="disabled", command=self.cancel_scan)
        self.cancel_button.pack(side="right", padx=5, pady=5)


    def build_results_tab(self):
        """Builds the Results tab content."""
        results_tab = self.tabs.tab("Results")
        ctk.CTkLabel(results_tab, text="Current Scan Results:", font=("Roboto", 16)).pack(anchor="w", padx=10, pady=(10,5))
        self.results_textbox = ctk.CTkTextbox(results_tab, state="disabled", wrap="word", font=("monospace", 11), border_width=1)
        self.results_textbox.pack(fill="both", expand=True, pady=(0,10), padx=10)
        # Add tags for coloring
        self.results_textbox.tag_config("MALICIOUS", foreground=COLOR_MALICIOUS)
        self.results_textbox.tag_config("SUSPICIOUS", foreground=COLOR_SUSPICIOUS)
        self.results_textbox.tag_config("CLEAN", foreground=COLOR_CLEAN)
        self.results_textbox.tag_config("INFO", foreground=COLOR_INFO)
        self.results_textbox.tag_config("ERROR", foreground=COLOR_ERROR)

        results_button_frame = ctk.CTkFrame(results_tab)
        results_button_frame.pack(fill="x", padx=10, pady=(0, 5))
        ctk.CTkButton(results_button_frame, text="Copy Results", command=self.copy_results).pack(side="left", padx=5)
        ctk.CTkButton(results_button_frame, text="Clear Results", command=self.clear_results).pack(side="left", padx=5)


    def build_logs_tab(self):
        """Builds the Logs tab content."""
        logs_tab = self.tabs.tab("Logs")
        ctk.CTkLabel(logs_tab, text="Application Logs:", font=("Roboto", 16)).pack(anchor="w", padx=10, pady=(10,5))
        self.log_textbox = ctk.CTkTextbox(logs_tab, state="disabled", wrap="word", font=("monospace", 10), border_width=1)
        self.log_textbox.pack(fill="both", expand=True, pady=(0,10), padx=10)

        log_button_frame = ctk.CTkFrame(logs_tab)
        log_button_frame.pack(fill="x", padx=10, pady=(0, 5))
        ctk.CTkButton(log_button_frame, text="Copy Logs", command=self.copy_logs).pack(side="left", padx=5)
        ctk.CTkButton(log_button_frame, text="Clear Logs", command=self.clear_logs).pack(side="left", padx=5)
        ctk.CTkButton(log_button_frame, text="Save Logs to File", command=self.save_logs).pack(side="left", padx=5)


    def build_history_tab(self):
        """Builds the History tab content."""
        history_tab = self.tabs.tab("History")
        ctk.CTkLabel(history_tab, text="Scan History:", font=("Roboto", 16)).pack(anchor="w", padx=10, pady=(10,5))
        self.history_textbox = ctk.CTkTextbox(history_tab, state="disabled", wrap="word", font=("monospace", 11), border_width=1)
        self.history_textbox.pack(fill="both", expand=True, pady=(0,10), padx=10)
        # Add tags for coloring history items
        self.history_textbox.tag_config("H_MALICIOUS", foreground=COLOR_MALICIOUS)
        self.history_textbox.tag_config("H_SUSPICIOUS", foreground=COLOR_SUSPICIOUS)
        self.history_textbox.tag_config("H_CLEAN", foreground=COLOR_CLEAN)
        self.history_textbox.tag_config("H_ERROR", foreground=COLOR_ERROR) # For scans that errored


        history_button_frame = ctk.CTkFrame(history_tab)
        history_button_frame.pack(fill="x", padx=10, pady=(0, 5))
        ctk.CTkButton(history_button_frame, text="Copy History", command=self.copy_history).pack(side="left", padx=5)
        ctk.CTkButton(history_button_frame, text="Clear All History", command=self.clear_all_history).pack(side="left", padx=5)
        ctk.CTkButton(history_button_frame, text="Delete Entry", command=self.delete_history_entry).pack(side="left", padx=5)


    def build_settings_tab(self):
        """Builds the Settings tab content."""
        settings_tab = self.tabs.tab("Settings")
        ctk.CTkLabel(settings_tab, text="Application Settings", font=("Roboto", 18, "bold")).pack(anchor="w", padx=10, pady=(10, 15))

        # API Key Section
        api_frame = ctk.CTkFrame(settings_tab)
        api_frame.pack(fill="x", padx=10, pady=5)
        ctk.CTkLabel(api_frame, text="VirusTotal API Key:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.api_key_entry = ctk.CTkEntry(api_frame, show="*", width=350)
        self.api_key_entry.insert(0, self.api_key)
        self.api_key_entry.grid(row=0, column=1, padx=5, pady=5, sticky="ew")
        api_frame.grid_columnconfigure(1, weight=1)
        ctk.CTkButton(api_frame, text="Test Connection", command=self.test_vt_connection).grid(row=0, column=2, padx=5, pady=5)


        # Appearance Section
        appearance_frame = ctk.CTkFrame(settings_tab)
        appearance_frame.pack(fill="x", padx=10, pady=10)
        ctk.CTkLabel(appearance_frame, text="Appearance:", font=("Roboto", 16)).pack(anchor="w", pady=(0,5))
        self.theme_switch = ctk.CTkSwitch(appearance_frame, text="Dark Mode", command=self.toggle_theme)
        if ctk.get_appearance_mode().lower() == "dark":
            self.theme_switch.select()
        self.theme_switch.pack(anchor="w", padx=5)

        # Exclusions Section
        exclusion_frame = ctk.CTkFrame(settings_tab)
        exclusion_frame.pack(fill="x", padx=10, pady=10)
        ctk.CTkLabel(exclusion_frame, text="Scan Exclusions:", font=("Roboto", 16)).pack(anchor="w", pady=(0,5))
        ctk.CTkLabel(exclusion_frame, text="Enter file extensions to exclude (comma-separated, e.g., .log,.tmp,.bak):").pack(anchor="w", padx=5)
        self.exclusion_entry = ctk.CTkEntry(exclusion_frame)
        self.exclusion_entry.insert(0, ",".join(self.config.get("exclusions", [])))
        self.exclusion_entry.pack(fill="x", padx=5, pady=5)

        # Save Button
        ctk.CTkButton(settings_tab, text="Save Settings", command=self.save_settings).pack(pady=20)

    # --- Logging ---
    def log(self, message, level="INFO"):
        """Logs a message to the Logs tab."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        formatted_message = f"{timestamp} [{level:<8}] {message}\n"
        try:
            self.log_textbox.configure(state="normal")
            self.log_textbox.insert("end", formatted_message)
            self.log_textbox.configure(state="disabled")
            self.log_textbox.see("end") # Auto-scroll
        except Exception as e:
            print(f"Error logging to textbox: {e}") # Fallback to console

    def clear_logs(self):
        """Clears the log display."""
        try:
            self.log_textbox.configure(state="normal")
            self.log_textbox.delete("1.0", "end")
            self.log_textbox.configure(state="disabled")
            self.log("Logs cleared.", level="INFO")
        except Exception as e:
            print(f"Error clearing logs: {e}")

    def copy_logs(self):
        """Copies log content to the clipboard."""
        try:
            log_content = self.log_textbox.get("1.0", "end-1c") # Exclude final newline
            self.clipboard_clear()
            self.clipboard_append(log_content)
            show_toast(self, "Logs copied to clipboard")
            self.log("Logs copied to clipboard.", level="INFO")
        except Exception as e:
            self.log(f"Error copying logs: {e}", level="ERROR")
            show_toast(self, "Error copying logs", bgcolor=COLOR_ERROR, fgcolor="white")

    def save_logs(self):
        """Saves log content to a user-selected file."""
        try:
            log_content = self.log_textbox.get("1.0", "end-1c")
            file_path = filedialog.asksaveasfilename(
                defaultextension=".log",
                filetypes=[("Log files", "*.log"), ("Text files", "*.txt"), ("All files", "*.*")],
                title="Save Logs As"
            )
            if file_path:
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(log_content)
                show_toast(self, f"Logs saved to {os.path.basename(file_path)}")
                self.log(f"Logs saved to file: {file_path}", level="INFO")
        except Exception as e:
            self.log(f"Error saving logs: {e}", level="ERROR")
            show_toast(self, "Error saving logs", bgcolor=COLOR_ERROR, fgcolor="white")

    # --- History Management ---
    def add_history_entry(self, entry_details, summary, item_identifier, status="INFO", scan_type="unknown", item_hash=None):
        """Adds an entry to the scan history."""
        timestamp = time.time()
        entry = {
            "timestamp": timestamp,
            "details": entry_details, # Full multiline report
            "summary": summary, # Single line summary for display
            "identifier": item_identifier, # File path, URL, or hash
            "status": status, # 'CLEAN', 'SUSPICIOUS', 'MALICIOUS', 'ERROR', 'INFO'
            "type": scan_type, # 'file', 'url', 'hash'
            "hash": item_hash # Store the hash if available
        }
        self.history.insert(0, entry) # Add to the beginning
        self.save_history()
        self.refresh_history_display()
        self.update_dashboard_stats()

    def refresh_history_display(self):
        """Updates the history text box display."""
        try:
            self.history_textbox.configure(state="normal")
            self.history_textbox.delete("1.0", "end")
            if not self.history:
                self.history_textbox.insert("1.0", "No scan history yet.")
            else:
                for i, entry in enumerate(self.history):
                    ts = datetime.fromtimestamp(entry.get("timestamp", 0)).strftime('%Y-%m-%d %H:%M:%S')
                    status = entry.get("status", "INFO")
                    summary = entry.get("summary", "No summary")
                    identifier = entry.get("identifier", "Unknown Item")
                    scan_type = entry.get("type", "scan")

                    # Determine tag based on status for coloring
                    tag = f"H_{status.upper()}" if status else None

                    line = f"[{i:03d}] {ts} [{status}] ({scan_type.upper()}) {identifier}\n"
                    self.history_textbox.insert("end", line, tag)
                    # Optionally add full details, but keep it concise for the list view
                    # self.history_textbox.insert("end", entry.get("details", "") + "\n" + "="*60 + "\n")

            self.history_textbox.configure(state="disabled")
        except Exception as e:
            self.log(f"Error refreshing history display: {e}", level="ERROR")

    def clear_all_history(self):
        """Clears all history entries."""
        if messagebox.askyesno("Confirm Clear History", "Are you sure you want to delete ALL scan history? This cannot be undone."):
            self.history = []
            self.save_history()
            self.refresh_history_display()
            self.update_dashboard_stats()
            show_toast(self, "Scan history cleared")
            self.log("Scan history cleared.", level="WARN")

    def copy_history(self):
        """Copies history summary to the clipboard."""
        try:
            history_content = self.history_textbox.get("1.0", "end-1c")
            self.clipboard_clear()
            self.clipboard_append(history_content)
            show_toast(self, "History summary copied to clipboard")
            self.log("History summary copied.", level="INFO")
        except Exception as e:
            self.log(f"Error copying history: {e}", level="ERROR")
            show_toast(self, "Error copying history", bgcolor=COLOR_ERROR, fgcolor="white")

    def delete_history_entry(self):
        """Deletes a specific history entry by index."""
        if not self.history:
            show_toast(self, "History is empty.", bgcolor=COLOR_INFO)
            return

        try:
            entry_index_str = simpledialog.askstring("Delete History Entry", "Enter the index number (e.g., 001) of the history entry to delete:", parent=self)
            if entry_index_str:
                entry_index = int(entry_index_str)
                if 0 <= entry_index < len(self.history):
                    # Confirm deletion
                    entry = self.history[entry_index]
                    identifier = entry.get("identifier", f"Entry {entry_index}")
                    if messagebox.askyesno("Confirm Deletion", f"Are you sure you want to delete history entry {entry_index} for '{identifier}'?"):
                        del self.history[entry_index]
                        self.save_history()
                        self.refresh_history_display()
                        self.update_dashboard_stats()
                        show_toast(self, f"History entry {entry_index} deleted.")
                        self.log(f"Deleted history entry {entry_index} ('{identifier}').", level="INFO")
                else:
                    messagebox.showerror("Error", f"Invalid index: {entry_index}. Please enter a number between 0 and {len(self.history)-1}.")
            else:
                 show_toast(self, "Deletion cancelled.", bgcolor=COLOR_INFO) # User cancelled dialog
        except ValueError:
            messagebox.showerror("Error", "Invalid input. Please enter a valid number.")
        except Exception as e:
            self.log(f"Error deleting history entry: {e}", level="ERROR")
            show_toast(self, "Error deleting entry", bgcolor=COLOR_ERROR, fgcolor="white")

    def save_history(self):
        """Saves the current history list to the JSON file."""
        try:
            with open(HISTORY_FILE, 'w') as f:
                json.dump(self.history, f, indent=2)
        except Exception as e:
            self.log(f"Error saving history: {e}", level="ERROR")
            show_toast(self, "Error saving history", bgcolor=COLOR_ERROR, fgcolor="white")

    def load_history(self):
        """Loads history from the JSON file."""
        if os.path.exists(HISTORY_FILE):
            try:
                with open(HISTORY_FILE, 'r') as f:
                    self.history = json.load(f)
                # Ensure it's a list
                if not isinstance(self.history, list):
                    self.log(f"History file '{HISTORY_FILE}' is corrupted. Starting fresh.", level="WARN")
                    self.history = []
                else:
                     # Sort by timestamp descending just in case it wasn't saved that way
                     self.history.sort(key=lambda x: x.get('timestamp', 0), reverse=True)
            except json.JSONDecodeError:
                self.log(f"Error decoding history file '{HISTORY_FILE}'. Starting fresh.", level="ERROR")
                self.history = []
            except Exception as e:
                self.log(f"Error loading history: {e}", level="ERROR")
                self.history = []
        else:
            self.history = [] # Initialize if file doesn't exist

    # --- Configuration ---
    def save_settings(self):
        """Saves current settings to the config file."""
        new_api_key = self.api_key_entry.get().strip()
        if not new_api_key:
             if messagebox.askokcancel("API Key Missing", "The API Key field is empty. VirusTotal scanning will not work. Save anyway?"):
                 self.api_key = ""
             else:
                 return # Don't save if user cancels

        self.api_key = new_api_key
        self.headers = {"x-apikey": self.api_key} if self.api_key else {}

        # Update config dictionary from UI elements
        self.update_config_from_ui()

        try:
            with open(CONFIG_FILE, 'w') as f:
                json.dump(self.config, f, indent=2)
            show_toast(self, "Settings saved successfully")
            self.log("Configuration saved.", level="INFO")
            # Reload exclusions after saving
            self.exclusions = [ext.strip().lower() for ext in self.config.get("exclusions", []) if ext.strip()]
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save settings: {e}")
            self.log(f"Error saving configuration: {e}", level="ERROR")


    def load_config(self):
        """Loads settings from the config file."""
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, 'r') as f:
                    self.config = json.load(f)
            except json.JSONDecodeError:
                self.log(f"Error decoding config file '{CONFIG_FILE}'. Using defaults.", level="ERROR")
                self.config = {} # Reset to defaults if corrupted
            except Exception as e:
                self.log(f"Error loading config: {e}", level="ERROR")
                self.config = {}
        else:
            self.config = {} # Initialize empty config if file doesn't exist

        # Set attributes from loaded config or defaults
        self.api_key = self.config.get("api_key", "")
        self.headers = {"x-apikey": self.api_key} if self.api_key else {}
        # Load exclusions and ensure they are lowercase and stripped
        self.exclusions = [ext.strip().lower() for ext in self.config.get("exclusions", []) if ext.strip() and ext.startswith('.')]


    def update_config_from_ui(self, *args): # Added *args to handle command callbacks
         """Updates the self.config dictionary based on current UI settings."""
         self.config["api_key"] = self.api_key_entry.get().strip() if hasattr(self, 'api_key_entry') else self.api_key
         self.config["theme"] = ctk.get_appearance_mode().lower()
         self.config["scan_mode"] = self.scan_mode_button.get() if hasattr(self, 'scan_mode_button') else self.config.get("scan_mode", "hash-only")
         self.config["hash_algo"] = self.hash_algo_button.get() if hasattr(self, 'hash_algo_button') else self.config.get("hash_algo", "sha256")
         # Process exclusions from entry field
         exclusion_text = self.exclusion_entry.get().strip() if hasattr(self, 'exclusion_entry') else ""
         self.config["exclusions"] = [ext.strip() for ext in exclusion_text.split(',') if ext.strip() and ext.startswith('.')]


    def toggle_theme(self):
        """Toggles between light and dark mode."""
        current_mode = ctk.get_appearance_mode()
        new_mode = "light" if current_mode.lower() == "dark" else "dark"
        ctk.set_appearance_mode(new_mode)
        self.log(f"Theme changed to {new_mode} mode.", level="INFO")
        # Update config immediately (doesn't require saving explicitly here)
        self.config["theme"] = new_mode
        # We might need to redraw parts of the UI or update colors if not automatic


    def test_vt_connection(self):
        """Tests the VirusTotal API key."""
        test_api_key = self.api_key_entry.get().strip()
        if not test_api_key:
            messagebox.showwarning("API Key Missing", "Please enter an API key to test.")
            return

        test_headers = {"x-apikey": test_api_key}
        test_url = f"{API_BASE}/ip_addresses/8.8.8.8" # Use a known, simple endpoint

        self.log("Testing VirusTotal API connection...", level="INFO")
        self.status_label.configure(text="Status: Testing API Key...")
        self.update() # Force UI update

        try:
            response = requests.get(test_url, headers=test_headers, timeout=10) # Add timeout
            if response.status_code == 200:
                messagebox.showinfo("Connection Successful", "API Key is valid and connection successful.")
                self.log("API connection test successful.", level="INFO")
                self.status_label.configure(text="Status: API Key OK")
            elif response.status_code == 401:
                 messagebox.showerror("Authentication Error", "API Key is invalid or unauthorized.")
                 self.log("API connection test failed: Invalid Key (401).", level="ERROR")
                 self.status_label.configure(text="Status: Invalid API Key")
            elif response.status_code == 429:
                 messagebox.showwarning("Rate Limit", "API key is likely valid, but you are rate limited (429). Wait and try again.")
                 self.log("API connection test failed: Rate Limited (429).", level="WARN")
                 self.status_label.configure(text="Status: Rate Limited")
            else:
                messagebox.showerror("Connection Error", f"Failed to connect. Status code: {response.status_code}\nResponse: {response.text[:100]}")
                self.log(f"API connection test failed: Status {response.status_code}", level="ERROR")
                self.status_label.configure(text=f"Status: API Test Error {response.status_code}")

        except requests.exceptions.RequestException as e:
            messagebox.showerror("Connection Error", f"Could not connect to VirusTotal: {e}")
            self.log(f"API connection test failed: {e}", level="ERROR")
            self.status_label.configure(text="Status: Connection Error")
        except Exception as e:
             messagebox.showerror("Error", f"An unexpected error occurred: {e}")
             self.log(f"API connection test failed with unexpected error: {e}", level="CRITICAL")
             self.status_label.configure(text="Status: Test Error")


    # --- Scan Logic ---
    def start_scan_thread(self, target_func, args):
        """Starts a scan in a separate thread."""
        if self.scanning:
            show_toast(self, "Another scan is already in progress.", bgcolor=COLOR_ERROR, fgcolor="white")
            return

        if not self.api_key:
             messagebox.showerror("API Key Missing", "Please set your VirusTotal API key in Settings before scanning.")
             self.tabs.set("Settings")
             return

        self.scanning = True
        self.scan_thread = threading.Thread(target=target_func, args=args, daemon=True)

        # Reset UI elements
        self.results_textbox.configure(state="normal")
        self.results_textbox.delete("1.0", "end")
        self.results_textbox.configure(state="disabled")
        self.progress_bar.set(0)
        self.progress_label.configure(text="0%")
        self.cancel_button.configure(state="normal")
        self.status_label.configure(text="Status: Starting Scan...")
        self.tabs.set("Results") # Switch to results tab

        self.start_time = time.time()
        self.current_scan_item_count = 0
        # total_scan_items is set within the target function

        self.scan_thread.start()


    def select_file(self):
        """Opens file dialog to select a single file for scanning."""
        # Pydroid 3 Note: Check if filedialog works reliably. May need platform-specific alternatives if not.
        file_path = filedialog.askopenfilename(title="Select File to Scan")
        if file_path:
            self.log(f"Selected file for scanning: {file_path}", level="INFO")
            self.start_scan_thread(self._scan_items_thread, ([file_path],))


    def select_folder(self):
        """Opens directory dialog to select a folder for scanning."""
         # Pydroid 3 Note: Check if filedialog works reliably. May need platform-specific alternatives if not.
        dir_path = filedialog.askdirectory(title="Select Folder to Scan")
        if dir_path:
            self.log(f"Selected folder for scanning: {dir_path}", level="INFO")
            self.status_label.configure(text="Status: Gathering files...")
            self.update() # Force UI update
            # Gather files in main thread briefly (can be slow for huge dirs)
            # Consider moving file gathering to the thread if it blocks UI too much
            items_to_scan = []
            try:
                for root, _, files in os.walk(dir_path):
                    if not self.scanning: break # Allow cancellation during walk
                    for filename in files:
                        file_path = os.path.join(root, filename)
                        # Check exclusions
                        _, ext = os.path.splitext(filename)
                        if ext.lower() in self.exclusions:
                             self.log(f"Skipping excluded file: {file_path}", level="DEBUG")
                             continue
                        items_to_scan.append(file_path)
                self.log(f"Found {len(items_to_scan)} files in folder (after exclusions).", level="INFO")
                if items_to_scan:
                   self.start_scan_thread(self._scan_items_thread, (items_to_scan,))
                else:
                    show_toast(self, "No files found in the selected folder (or all excluded).")
                    self.log("No scannable files found in folder.", level="INFO")
                    self.scan_finished() # Reset UI if nothing to scan

            except Exception as e:
                 self.log(f"Error walking directory {dir_path}: {e}", level="ERROR")
                 messagebox.showerror("Error", f"Could not read folder contents:\n{e}")
                 self.scan_finished()


    def scan_url(self):
        """Initiates scanning of a URL from the entry field."""
        url = self.url_entry.get().strip()
        if not url:
            messagebox.showwarning("Input Error", "Please enter a URL to scan.")
            return
        if not (url.startswith("http://") or url.startswith("https://")):
             messagebox.showwarning("Input Error", "Please enter a valid URL (starting with http:// or https://).")
             return

        self.log(f"Starting URL scan for: {url}", level="INFO")
        self.start_scan_thread(self._scan_urls_thread, ([url],))


    def lookup_hash(self):
        """Initiates lookup of a hash from the entry field."""
        hash_value = self.hash_entry.get().strip().lower() # Use lower case hashes
        if not hash_value:
            messagebox.showwarning("Input Error", "Please enter a file hash (SHA256, SHA1, or MD5) to lookup.")
            return
        # Basic hash format check (length) - adjust if needed
        if len(hash_value) not in [32, 40, 64]:
             messagebox.showwarning("Input Error", f"Invalid hash length ({len(hash_value)}). Expected 32 (MD5), 40 (SHA1), or 64 (SHA256).")
             return

        self.log(f"Starting hash lookup for: {hash_value}", level="INFO")
        # Pass the hash directly as the item to scan
        self.start_scan_thread(self._scan_items_thread, ([hash_value],))


    def cancel_scan(self):
        """Sets the flag to stop the current scan."""
        if self.scanning:
            self.scanning = False # Signal thread to stop
            self.log("Scan cancellation requested.", level="WARN")
            self.status_label.configure(text="Status: Cancelling Scan...")
            self.cancel_button.configure(state="disabled") # Disable until fully stopped


    def scan_finished(self):
        """Actions to perform when a scan thread completes or is cancelled."""
        self.scanning = False
        elapsed_time = time.time() - self.start_time if self.start_time else 0
        self.status_label.configure(text=f"Status: Scan Finished ({self.current_scan_item_count}/{self.total_scan_items} items). Took {elapsed_time:.1f}s")
        self.cancel_button.configure(state="disabled")
        self.progress_bar.set(1) # Ensure progress bar shows 100%
        self.progress_label.configure(text="100%")
        self.log(f"Scan finished. Processed {self.current_scan_item_count}/{self.total_scan_items} items in {elapsed_time:.1f} seconds.", level="INFO")
        show_toast(self, f"Scan complete! Processed {self.current_scan_item_count} items.")
        self.start_time = 0
        self.scan_thread = None


    def update_progress(self, current_item, total_items):
         """Updates the progress bar and label."""
         if total_items > 0:
             progress_fraction = current_item / total_items
             progress_percent = int(progress_fraction * 100)
             self.progress_bar.set(progress_fraction)
             self.progress_label.configure(text=f"{progress_percent}%")

             # Estimate ETA
             if self.start_time and current_item > 0:
                 elapsed = time.time() - self.start_time
                 rate = elapsed / current_item # seconds per item
                 eta = rate * (total_items - current_item)
                 eta_str = f"{int(eta // 60)}m {int(eta % 60)}s" if eta > 60 else f"{int(eta)}s"
                 self.status_label.configure(text=f"Status: Scanning {current_item}/{total_items}... ETA: {eta_str}")
             else:
                 self.status_label.configure(text=f"Status: Scanning {current_item}/{total_items}...")

             # Force UI update periodically, not on every item for performance
             if current_item % 5 == 0 or current_item == total_items:
                 self.update_idletasks()


    def display_result(self, identifier, analysis_result, item_hash=None, is_url=False):
        """Formats and displays a single scan result in the textbox."""
        self.results_textbox.configure(state="normal")

        status = analysis_result.get("status", "UNKNOWN")
        stats = analysis_result.get("stats", {})
        detections = analysis_result.get("detections", {}) # Now a dict
        vt_link = analysis_result.get("vt_link", "#")

        malicious = stats.get("malicious", 0)
        suspicious = stats.get("suspicious", 0)
        undetected = stats.get("undetected", 0)
        harmless = stats.get("harmless", 0)
        timeout = stats.get("timeout", 0)

        # Determine overall status and color tag
        result_status = "ERROR" # Default if parsing fails somehow
        status_tag = "ERROR"
        if status == "completed":
            if malicious > 0:
                result_status = "MALICIOUS"
                status_tag = "MALICIOUS"
            elif suspicious > 0:
                result_status = "SUSPICIOUS"
                status_tag = "SUSPICIOUS"
            else:
                result_status = "CLEAN"
                status_tag = "CLEAN"
        elif status == "error":
             result_status = "ERROR"
             status_tag = "ERROR"

        # Header
        self.results_textbox.insert("end", f"--- Item: {identifier} ---\n", ("INFO",))
        self.results_textbox.insert("end", f"Status: ")
        self.results_textbox.insert("end", f"{result_status}\n", (status_tag,))
        if item_hash and not is_url:
            self.results_textbox.insert("end", f"Hash ({analysis_result.get('hash_type', 'sha256')}): {item_hash}\n", ("INFO",))
        elif is_url:
             self.results_textbox.insert("end", f"URL ID: {item_hash}\n", ("INFO",)) # item_hash holds URL ID here

        # Analysis Stats
        self.results_textbox.insert("end", f"Analysis: ")
        if malicious > 0: self.results_textbox.insert("end", f"Malicious={malicious} ", ("MALICIOUS",))
        if suspicious > 0: self.results_textbox.insert("end", f"Suspicious={suspicious} ", ("SUSPICIOUS",))
        if harmless > 0 or undetected > 0: self.results_textbox.insert("end", f"Clean={harmless+undetected} ", ("CLEAN",))
        if timeout > 0: self.results_textbox.insert("end", f"Timeout={timeout} ", ("ERROR",))
        self.results_textbox.insert("end", "\n")

        # Detections
        if detections:
            self.results_textbox.insert("end", "Detections:\n")
            for engine, result in detections.items():
                category = result.get('category', 'unknown')
                detection_tag = "CLEAN" # Default assume clean unless specified
                if category == 'malicious': detection_tag = "MALICIOUS"
                elif category == 'suspicious': detection_tag = "SUSPICIOUS"
                elif category == 'undetected': detection_tag = "CLEAN"

                res_name = result.get('result', 'n/a') # AV detection name
                self.results_textbox.insert("end", f"- {engine}: ", ("INFO",))
                self.results_textbox.insert("end", f"{res_name if res_name else category}\n", (detection_tag,))
        elif status == "completed":
            self.results_textbox.insert("end", "Detections: None\n", ("CLEAN",))
        elif status == "error":
             self.results_textbox.insert("end", f"Detections: Analysis failed - {analysis_result.get('error_message', 'Unknown error')}\n", ("ERROR",))

        # Link
        self.results_textbox.insert("end", f"VT Link: {vt_link}\n", ("INFO",))
        self.results_textbox.insert("end", "="*60 + "\n")
        self.results_textbox.configure(state="disabled")
        self.results_textbox.see("end")

        # --- Add to History ---
        # Create a text version for history details
        # Corrected index here
        history_detail = self.results_textbox.get("end - 1 line linestart", "end - 1c")

        # Create a shorter summary for history list view
        history_summary = f"[{result_status}] {identifier} (M:{malicious}, S:{suspicious}, C:{harmless+undetected})"

        self.add_history_entry(
            entry_details=history_detail,
            summary=history_summary,
            item_identifier=identifier,
            status=result_status,
            scan_type="url" if is_url else "file" if os.path.exists(identifier) else "hash",
            item_hash=item_hash
        )

    def display_error(self, identifier, error_message):
        """Displays an error message in the results textbox."""
        self.results_textbox.configure(state="normal")
        self.results_textbox.insert("end", f"--- Item: {identifier} ---\n", ("INFO",))
        self.results_textbox.insert("end", f"Status: ERROR\n", ("ERROR",))
        self.results_textbox.insert("end", f"Error: {error_message}\n", ("ERROR",))
        self.results_textbox.insert("end", "="*60 + "\n")
        self.results_textbox.configure(state="disabled")
        self.results_textbox.see("end")
        # Add error entry to history
        self.add_history_entry(
            entry_details=f"Error scanning {identifier}:\n{error_message}",
            summary=f"[ERROR] {identifier}",
            item_identifier=identifier,
            status="ERROR",
            scan_type="file" if os.path.exists(identifier) else "hash" if len(identifier) in [32,40,64] else "url" # Guess type
        )

    def clear_results(self):
        """Clears the results text box."""
        self.results_textbox.configure(state="normal")
        self.results_textbox.delete("1.0", "end")
        self.results_textbox.configure(state="disabled")
        show_toast(self, "Results cleared", bgcolor=COLOR_INFO)

    def copy_results(self):
        """Copies the results text box content to clipboard."""
        try:
            results_content = self.results_textbox.get("1.0", "end-1c")
            self.clipboard_clear()
            self.clipboard_append(results_content)
            show_toast(self, "Results copied to clipboard")
            self.log("Scan results copied.", level="INFO")
        except Exception as e:
            self.log(f"Error copying results: {e}", level="ERROR")
            show_toast(self, "Error copying results", bgcolor=COLOR_ERROR, fgcolor="white")


    # --- Core VirusTotal Interaction ---

    def vt_request(self, endpoint, method='get', data=None, files=None, item_id_for_log=""):
        """Makes a request to the VirusTotal API, handling common errors."""
        if not self.headers:
            self.log(f"API key not set. Cannot make request to {endpoint}.", level="ERROR")
            return {"error": "API key not configured.", "status_code": None}

        url = f"{API_BASE}/{endpoint}"
        self.log(f"Sending {method.upper()} request to VT: /{endpoint} for '{item_id_for_log}'", level="DEBUG")

        try:
            if method.lower() == 'get':
                response = requests.get(url, headers=self.headers, timeout=30) # Increased timeout
            elif method.lower() == 'post':
                response = requests.post(url, headers=self.headers, data=data, files=files, timeout=60) # Longer timeout for posts/uploads
            else:
                 return {"error": f"Unsupported HTTP method: {method}", "status_code": None}

            self.log(f"VT Response Status for /{endpoint}: {response.status_code}", level="DEBUG")

            if response.status_code == 200:
                try:
                    return response.json() # Return parsed JSON on success
                except json.JSONDecodeError:
                     self.log(f"Failed to decode JSON response from {endpoint}.", level="ERROR")
                     return {"error": "Invalid JSON response from API.", "status_code": 200}
            elif response.status_code == 204: # No content (e.g., maybe for comments)
                 return {"data": {}, "status_code": 204} # Return something usable
            elif response.status_code == 400:
                err_msg = response.json().get("error", {}).get("message", "Bad Request")
                self.log(f"VirusTotal API Error (400 - Bad Request) for {endpoint}: {err_msg}", level="ERROR")
                return {"error": f"Bad Request: {err_msg}", "status_code": 400}
            elif response.status_code == 401:
                self.log(f"VirusTotal API Error (401 - Unauthorized) for {endpoint}. Check API key.", level="ERROR")
                # Maybe disable scanning automatically here? Or show persistent warning.
                show_toast(self, "API Key Error (Unauthorized). Check Settings.", duration=5000, bgcolor=COLOR_ERROR, fgcolor="white")
                return {"error": "Authentication failed. Check API key.", "status_code": 401}
            elif response.status_code == 404:
                 # 404 can be normal (hash not found) or an error (bad endpoint)
                 # Check response content if possible
                 try:
                     err_code = response.json().get("error", {}).get("code", "")
                     if err_code == "NotFoundError":
                          self.log(f"Item not found on VirusTotal (404): {item_id_for_log}", level="INFO")
                          return {"error": "Item not found", "status_code": 404, "not_found": True}
                 except json.JSONDecodeError:
                     pass # Ignore if response is not JSON
                 # Assume generic 404 if not specifically "NotFoundError"
                 self.log(f"VirusTotal API Error (404 - Not Found) for endpoint: /{endpoint}", level="ERROR")
                 return {"error": f"API endpoint not found: /{endpoint}", "status_code": 404}
            elif response.status_code == 429:
                self.log(f"VirusTotal API Error (429 - Rate Limit Exceeded) for {endpoint}.", level="WARN")
                show_toast(self, "Rate Limit Exceeded. Waiting before retry...", duration=3000, bgcolor=COLOR_ERROR, fgcolor="white")
                # Implement more sophisticated backoff later if needed
                time.sleep(RATE_LIMIT_SLEEP * 2) # Wait longer if hit limit
                return {"error": "Rate limit exceeded.", "status_code": 429, "rate_limited": True}
            else:
                # Handle other unexpected status codes
                self.log(f"VirusTotal API Error ({response.status_code}) for {endpoint}: {response.text[:200]}", level="ERROR")
                return {"error": f"API error {response.status_code}.", "status_code": response.status_code}

        except requests.exceptions.Timeout:
            self.log(f"Request to VirusTotal timed out: /{endpoint}", level="ERROR")
            return {"error": "Request timed out.", "status_code": None}
        except requests.exceptions.RequestException as e:
            self.log(f"Network error connecting to VirusTotal ({endpoint}): {e}", level="ERROR")
            # Check internet connection maybe?
            show_toast(self, "Network Error. Check connection.", duration=5000, bgcolor=COLOR_ERROR, fgcolor="white")
            return {"error": f"Network error: {e}", "status_code": None}
        except Exception as e:
             self.log(f"Unexpected error during VT request ({endpoint}): {e}", level="CRITICAL")
             return {"error": f"An unexpected error occurred: {e}", "status_code": None}


    def parse_vt_analysis_result(self, analysis_data, item_id):
        """Parses the JSON data from a VT analysis or file/URL report."""
        result = {"stats": {}, "detections": {}, "status": "error", "error_message": "No data found", "vt_link": "#"}
        is_url = False

        if not analysis_data or 'data' not in analysis_data:
            self.log(f"No 'data' key found in VT response for {item_id}", level="WARN")
            return result # Return default error state

        data = analysis_data['data']
        attributes = data.get('attributes', {})
        analysis_id = data.get('id', item_id) # Use analysis ID if available
        item_type = data.get('type', 'unknown') # 'analysis', 'file', 'url'

        if item_type == 'url':
            is_url = True
            # URL reports might store the final URL ID differently
            # Extract the actual URL ID if possible (it's often the analysis_id itself for URLs)
            vt_report_id = url_to_id(attributes.get('url', item_id)) if 'url' in attributes else analysis_id
        elif item_type == 'file':
             # For files, the ID is usually the hash
             vt_report_id = attributes.get('sha256', item_id)
        else: # analysis, assume it's based on item_id passed
             vt_report_id = item_id


        result["vt_link"] = get_vt_report_url(vt_report_id, is_url=is_url)
        result["status"] = attributes.get('status', 'completed') # Assume completed if getting report directly
        result["stats"] = attributes.get('last_analysis_stats', {}) # For file/url reports
        if not result["stats"]: # Try getting stats from analysis object itself
             result["stats"] = attributes.get('stats', {})

        analysis_results = attributes.get('results', {}) # For analysis objects
        if not analysis_results: # Try getting from file/url report structure
             analysis_results = attributes.get('last_analysis_results', {})

        result["detections"] = {
            engine: info for engine, info in analysis_results.items()
            # Optionally filter categories: if info.get('category') in ('malicious', 'suspicious')
        }

        # Extract hash type if available (for files)
        if 'sha256' in attributes: result['hash_type'] = 'sha256'
        elif 'sha1' in attributes: result['hash_type'] = 'sha1'
        elif 'md5' in attributes: result['hash_type'] = 'md5'


        # Handle cases where analysis failed or item wasn't found via direct report
        if result["status"] != 'completed' and not result["stats"]:
            if analysis_data.get("error"): # Check if vt_request returned an error structure
                 result["error_message"] = analysis_data["error"]
                 result["status"] = "error"
            else:
                 # If status isn't completed but no specific error, assume failed analysis
                 result["error_message"] = f"Analysis status: {result['status']}"
                 result["status"] = "error"

        return result


    def get_analysis_report(self, analysis_id, item_identifier):
        """Polls for and retrieves the final analysis report from VirusTotal."""
        poll_start_time = time.time()
        self.log(f"Polling for analysis results: {analysis_id} (Item: {item_identifier})", level="INFO")

        while time.time() - poll_start_time < DEFAULT_POLL_TIMEOUT:
            if not self.scanning: return {"error": "Scan cancelled during polling.", "status": "cancelled"} # Check for cancellation

            self.status_label.configure(text=f"Status: Analyzing '{os.path.basename(item_identifier)}' on VirusTotal...")
            self.update_idletasks()

            # Add rate limiting delay *before* the request inside the loop
            time.sleep(RATE_LIMIT_SLEEP)

            response = self.vt_request(f"analyses/{analysis_id}", item_id_for_log=item_identifier)

            if response.get("error"):
                 # Handle specific errors from vt_request
                 if response.get("rate_limited"):
                     self.log(f"Rate limited while polling for {analysis_id}. Continuing wait.", level="WARN")
                     # The sleep above already handles waiting, just continue the loop
                     continue
                 elif response.get("status_code") == 404:
                      self.log(f"Analysis ID {analysis_id} not found (404).", level="ERROR")
                      return {"error": "Analysis ID not found.", "status": "error"}
                 else:
                     # General error during polling
                     self.log(f"Error polling for analysis {analysis_id}: {response['error']}", level="ERROR")
                     return {"error": f"API Error during polling: {response['error']}", "status": "error"}

            # Check the status within the analysis data
            analysis_status = response.get("data", {}).get("attributes", {}).get("status")
            self.log(f"Analysis status for {analysis_id}: {analysis_status}", level="DEBUG")

            if analysis_status == "completed":
                self.log(f"Analysis complete for {analysis_id}.", level="INFO")
                # Analysis is done, parse the final result structure
                return self.parse_vt_analysis_result(response, analysis_id)
            elif analysis_status == "failed" or analysis_status == "error": # Handle explicit failure states
                 self.log(f"Analysis failed for {analysis_id} (Status: {analysis_status}).", level="ERROR")
                 return {"error": f"VirusTotal analysis failed (status: {analysis_status})", "status": "error"}
            #elif analysis_status in ["queued", "inprogress"]:
                # Continue polling, wait handled by sleep at loop start
            #    pass
            else: # Unexpected status
                 self.log(f"Unexpected analysis status '{analysis_status}' for {analysis_id}. Assuming in progress.", level="WARN")


        # If loop finishes without completion, it timed out
        self.log(f"Polling timed out for analysis {analysis_id}.", level="ERROR")
        return {"error": "Analysis polling timed out.", "status": "error", "timeout": True}


    # --- Main Scan Threads (_scan_items_thread, _scan_urls_thread) ---

    def _scan_items_thread(self, items_to_scan):
        """
        Thread worker for scanning files (by hash or upload) or looking up hashes.
        'items_to_scan' contains file paths or hash strings.
        """
        self.total_scan_items = len(items_to_scan)
        self.log(f"Starting item scan thread for {self.total_scan_items} items.", level="INFO")
        scan_mode = self.config.get("scan_mode", "hash-only")
        hash_algo = self.config.get("hash_algo", "sha256")

        for i, item_path_or_hash in enumerate(items_to_scan):
            self.current_scan_item_count = i + 1
            if not self.scanning:
                self.log("Scan cancelled by user.", level="WARN")
                break

            self.update_progress(self.current_scan_item_count, self.total_scan_items)
            self.log(f"Processing item {i+1}/{self.total_scan_items}: {item_path_or_hash}", level="INFO")

            item_hash = None
            is_file = os.path.isfile(item_path_or_hash)
            item_identifier = os.path.basename(item_path_or_hash) if is_file else item_path_or_hash # Use basename for files


            # 1. Determine Hash (compute if file, use directly if hash string)
            if is_file:
                item_hash = compute_hash(item_path_or_hash, algo=hash_algo)
                if not item_hash:
                    self.log(f"Could not compute hash for file: {item_path_or_hash}", level="ERROR")
                    self.display_error(item_identifier, f"Failed to compute {hash_algo} hash.")
                    # Apply rate limit delay even on error to prevent hammering bad files
                    time.sleep(RATE_LIMIT_SLEEP)
                    continue
            else:
                # Assume it's a hash string provided directly
                # Validate length again just in case
                if len(item_path_or_hash) in [32, 40, 64]:
                    item_hash = item_path_or_hash
                    # Try to guess algo from length for logging/reporting
                    if len(item_hash) == 64: hash_algo = 'sha256'
                    elif len(item_hash) == 40: hash_algo = 'sha1'
                    elif len(item_hash) == 32: hash_algo = 'md5'
                else:
                     self.log(f"Invalid item provided (not a file or valid hash): {item_path_or_hash}", level="ERROR")
                     self.display_error(item_identifier, "Item is not a valid file or hash.")
                     time.sleep(RATE_LIMIT_SLEEP) # Delay
                     continue

            # Rate limit delay *before* making API calls for this item
            time.sleep(RATE_LIMIT_SLEEP)

            # 2. Check VirusTotal for existing report using the hash
            self.status_label.configure(text=f"Status: Checking '{item_identifier}' hash...")
            self.update_idletasks()
            report_response = self.vt_request(f"files/{item_hash}", item_id_for_log=item_identifier)

            analysis_result = None
            need_upload = False

            if report_response.get("not_found"):
                 self.log(f"Hash {item_hash} not found on VT for {item_identifier}.", level="INFO")
                 if is_file and scan_mode == "auto-upload":
                     need_upload = True
                     self.log(f"Scan mode is 'auto-upload', preparing to upload: {item_identifier}", level="INFO")
                 else:
                     # Hash not found, and not uploading
                     analysis_result = {"status": "not_found", "error_message": "Hash not found on VirusTotal. Upload required for analysis.", "stats": {}, "detections": {}}
                     analysis_result["vt_link"] = get_vt_report_url(item_hash, is_url=False) # Link to potential future report

            elif report_response.get("error"):
                 # Error retrieving report (rate limit, auth, etc.)
                 self.log(f"Error fetching report for hash {item_hash}: {report_response['error']}", level="ERROR")
                 analysis_result = {"status": "error", "error_message": report_response['error'], "stats": {}, "detections": {}}
                 if report_response.get("rate_limited"): # Check if error was due to rate limit
                      # Already slept once, maybe wait again or just report error
                      pass # Just report the error for now

            else:
                 # Report found, parse it
                 self.log(f"Found existing report for hash {item_hash} ({item_identifier}).", level="INFO")
                 analysis_result = self.parse_vt_analysis_result(report_response, item_hash)


            # 3. Upload file if needed and allowed
            if need_upload:
                # Pydroid 3 Note: Check file size limits and potential background limitations for large uploads.
                file_size = os.path.getsize(item_path_or_hash)
                # VT Public API limit is 32MB, check before attempting upload
                # VT Premium API limit is much higher (e.g., 650MB+)
                # Let's assume public API limit for now.
                MAX_UPLOAD_SIZE_MB = 32
                if file_size > MAX_UPLOAD_SIZE_MB * 1024 * 1024:
                     self.log(f"File {item_identifier} too large for upload ({file_size / 1024 / 1024 :.1f} MB > {MAX_UPLOAD_SIZE_MB} MB). Skipping upload.", level="WARN")
                     analysis_result = {"status": "skipped", "error_message": f"File exceeds {MAX_UPLOAD_SIZE_MB}MB upload limit.", "stats": {}, "detections": {}}
                else:
                    self.log(f"Uploading file: {item_identifier} ({file_size / 1024 / 1024 :.1f} MB)", level="INFO")
                    self.status_label.configure(text=f"Status: Uploading '{item_identifier}'...")
                    self.update_idletasks()
                    try:
                         with open(item_path_or_hash, 'rb') as f:
                             files_data = {'file': (os.path.basename(item_path_or_hash), f)}
                             # Need to get upload URL first if file > 32MB (even for premium) - simplified here
                             upload_response = self.vt_request("files", method='post', files=files_data, item_id_for_log=item_identifier)

                             if upload_response.get("error"):
                                  self.log(f"Upload failed for {item_identifier}: {upload_response['error']}", level="ERROR")
                                  analysis_result = {"status": "error", "error_message": f"Upload failed: {upload_response['error']}"}
                             elif 'data' in upload_response and 'id' in upload_response['data']:
                                 analysis_id = upload_response['data']['id']
                                 self.log(f"Upload successful for {item_identifier}. Analysis ID: {analysis_id}", level="INFO")
                                 # Now poll for the analysis results
                                 analysis_result = self.get_analysis_report(analysis_id, item_identifier)
                             else:
                                 self.log(f"Upload response for {item_identifier} did not contain analysis ID.", level="ERROR")
                                 analysis_result = {"status": "error", "error_message": "Upload succeeded but no analysis ID received."}

                    except FileNotFoundError:
                         self.log(f"File not found during upload attempt: {item_path_or_hash}", level="ERROR")
                         analysis_result = {"status": "error", "error_message": "File disappeared before upload."}
                    except PermissionError:
                         self.log(f"Permission error during upload attempt: {item_path_or_hash}", level="ERROR")
                         analysis_result = {"status": "error", "error_message": "Permission denied to read file for upload."}
                    except Exception as e:
                         self.log(f"Unexpected error during upload of {item_identifier}: {e}", level="ERROR")
                         analysis_result = {"status": "error", "error_message": f"Upload error: {e}"}


            # 4. Display results
            if analysis_result:
                 # Add the hash algo used to the result for clarity
                 analysis_result['hash_type'] = hash_algo
                 if analysis_result.get("status") == "error":
                      self.display_error(item_identifier, analysis_result.get("error_message", "Unknown error"))
                 elif analysis_result.get("status") == "not_found":
                       self.display_error(item_identifier, analysis_result.get("error_message", "Item not found")) # Treat not found as an info/error
                 elif analysis_result.get("status") == "skipped":
                       self.display_error(item_identifier, analysis_result.get("error_message", "Skipped")) # Display skip reason
                 else:
                     self.display_result(item_identifier, analysis_result, item_hash)
            else:
                 # Should not happen if logic is correct, but handle defensively
                 self.log(f"No analysis result generated for {item_identifier}", level="ERROR")
                 self.display_error(item_identifier, "Failed to obtain analysis results.")

            # Small delay before next item if loop continues
            # time.sleep(0.1) # Already have RATE_LIMIT_SLEEP

        # Scan finished
        self.after(100, self.scan_finished) # Schedule finish actions in main thread


    def _scan_urls_thread(self, urls_to_scan):
        """Thread worker for scanning URLs."""
        self.total_scan_items = len(urls_to_scan)
        self.log(f"Starting URL scan thread for {self.total_scan_items} URLs.", level="INFO")

        for i, url in enumerate(urls_to_scan):
            self.current_scan_item_count = i + 1
            if not self.scanning:
                self.log("Scan cancelled by user.", level="WARN")
                break

            self.update_progress(self.current_scan_item_count, self.total_scan_items)
            self.log(f"Processing URL {i+1}/{self.total_scan_items}: {url}", level="INFO")
            url_id = url_to_id(url) # Use VT's URL ID format

            # Rate limit delay *before* making API calls for this item
            time.sleep(RATE_LIMIT_SLEEP)

            # 1. Submit URL for analysis (or re-analysis)
            self.status_label.configure(text=f"Status: Submitting URL '{url[:30]}...'")
            self.update_idletasks()
            submit_response = self.vt_request("urls", method='post', data={'url': url}, item_id_for_log=url)

            analysis_result = None

            if submit_response.get("error"):
                self.log(f"Failed to submit URL {url}: {submit_response['error']}", level="ERROR")
                # Check if it was a rate limit error specifically
                if submit_response.get("rate_limited"):
                     # Might try getting existing report as fallback if rate limited on submit
                     self.log("Rate limited on URL submit, trying to fetch existing report.", level="WARN")
                     report_response = self.vt_request(f"urls/{url_id}", item_id_for_log=url)
                     if report_response.get("error"):
                          # Failed to get existing report too
                          analysis_result = {"status": "error", "error_message": f"Submit failed ({submit_response['error']}) and couldn't fetch report ({report_response['error']})."}
                     else:
                          # Got existing report successfully
                          analysis_result = self.parse_vt_analysis_result(report_response, url_id)
                else:
                     # Other submit error
                     analysis_result = {"status": "error", "error_message": f"URL Submit Failed: {submit_response['error']}"}

            elif 'data' in submit_response and 'id' in submit_response['data']:
                 analysis_id = submit_response['data']['id'] # This is analysis ID, like u-{hash}-timestamp
                 self.log(f"URL {url} submitted successfully. Analysis ID: {analysis_id}", level="INFO")
                 # 2. Poll for analysis completion
                 analysis_result = self.get_analysis_report(analysis_id, url)
            else:
                 self.log(f"URL submission response for {url} missing analysis ID.", level="ERROR")
                 analysis_result = {"status": "error", "error_message": "URL Submitted but no analysis ID received."}


            # 3. Display result
            if analysis_result:
                 if analysis_result.get("status") == "error":
                      self.display_error(url, analysis_result.get("error_message", "Unknown error"))
                 else:
                      # Pass url_id as the 'hash' for display/history purposes
                      self.display_result(url, analysis_result, url_id, is_url=True)
            else:
                 self.log(f"No analysis result generated for URL {url}", level="ERROR")
                 self.display_error(url, "Failed to obtain analysis results for URL.")

            # Small delay before next item if loop continues
            # time.sleep(0.1) # Already have RATE_LIMIT_SLEEP

        # Scan finished
        self.after(100, self.scan_finished)

    # --- Dashboard Updates ---
    def update_dashboard_stats(self):
         """Updates the statistics displayed on the dashboard."""
         total_scans = len(self.history)
         malicious_count = sum(1 for entry in self.history if entry.get("status") == "MALICIOUS")
         suspicious_count = sum(1 for entry in self.history if entry.get("status") == "SUSPICIOUS")

         if hasattr(self, 'dashboard_total_scans_label'): # Check if UI is built
             self.dashboard_total_scans_label.configure(text=f"Total Scans: {total_scans}")
             self.dashboard_malicious_label.configure(text=f"Malicious Found: {malicious_count}")
             self.dashboard_suspicious_label.configure(text=f"Suspicious Found: {suspicious_count}")

    # --- Overrides & Cleanup ---
    def destroy(self):
        """Override destroy to ensure scan thread is stopped if running."""
        self.log("Application closing...", level="INFO")
        if self.scanning and self.scan_thread and self.scan_thread.is_alive():
            self.log("Attempting to cancel ongoing scan before exit...", level="WARN")
            self.cancel_scan()
            # Give thread a moment to stop - adjust timeout as needed
            self.scan_thread.join(timeout=2.0)
            if self.scan_thread.is_alive():
                self.log("Scan thread did not terminate gracefully.", level="ERROR")
        # Save settings/history one last time? Optional.
        # self.save_settings() # Careful, might trigger UI elements that are being destroyed
        self.save_history()
        super().destroy()


# --- Main Execution ---
if __name__ == "__main__":
    # Set initial theme mode before creating app instance
    # Try loading theme from config if possible, else default to dark
    initial_theme = "dark"
    if os.path.exists(CONFIG_FILE):
         try:
              with open(CONFIG_FILE, 'r') as f:
                   config_data = json.load(f)
                   initial_theme = config_data.get("theme", "dark")
         except Exception:
              pass # Ignore errors, default to dark

    ctk.set_appearance_mode(initial_theme)
    ctk.set_default_color_theme("dark-blue") # Or choose another theme

    app = AntivirusApp()
    app.mainloop()