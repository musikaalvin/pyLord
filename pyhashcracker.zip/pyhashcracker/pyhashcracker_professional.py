#!/usr/bin/env python3
"""
PyHashCracker Professional Edition
A comprehensive password recovery and hash cracking tool with advanced features
- 100+ Hash algorithms
- Multiprocessing support
- Session management
- Salted hash support
- GPU acceleration ready
- Advanced rules engine
- Combinator attacks
- Enhanced statistics and ETA
"""

import os
import sys
import hashlib
import re
import tkinter as tk
from tkinter import messagebox, ttk, filedialog, scrolledtext
import time
import threading
import multiprocessing
import itertools
import string
from collections import deque
import sqlite3
import json
import logging
import struct
import zlib
import binascii
import pickle
from datetime import datetime, timedelta
import queue
import signal
from pathlib import Path

# Advanced imports
try:
    from passlib.hash import bcrypt, pbkdf2_sha256, argon2, sha256_crypt, sha512_crypt
    PASSLIB_AVAILABLE = True
except ImportError:
    PASSLIB_AVAILABLE = False
    print("Warning: passlib not available. Advanced password hashing disabled.")

try:
    from Crypto.Hash import GOST3411
    GOST_AVAILABLE = True
except ImportError:
    GOST_AVAILABLE = False

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
    print("Info: psutil not available. System monitoring features limited.")

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# --- ADVANCED SESSION MANAGEMENT ---

class SessionManager:
    """Manages attack sessions with save/resume functionality"""
    
    def __init__(self, session_dir="sessions"):
        self.session_dir = Path(session_dir)
        self.session_dir.mkdir(exist_ok=True)
        self.current_session = None
    
    def save_session(self, session_data):
        """Save current attack session"""
        session_id = f"session_{int(time.time())}"
        session_file = self.session_dir / f"{session_id}.pkl"
        
        with open(session_file, 'wb') as f:
            pickle.dump(session_data, f)
            
        self.current_session = session_file
        logger.info(f"Session saved: {session_file}")
        return session_id
    
    def load_session(self, session_id):
        """Load a saved session"""
        session_file = self.session_dir / f"{session_id}.pkl"
        
        if session_file.exists():
            with open(session_file, 'rb') as f:
                return pickle.load(f)
        return None
    
    def list_sessions(self):
        """List all available sessions"""
        sessions = []
        for session_file in self.session_dir.glob("session_*.pkl"):
            try:
                with open(session_file, 'rb') as f:
                    data = pickle.load(f)
                sessions.append({
                    'id': session_file.stem,
                    'file': session_file,
                    'data': data,
                    'created': datetime.fromtimestamp(session_file.stat().st_mtime)
                })
            except Exception as e:
                logger.error(f"Error loading session {session_file}: {e}")
        
        return sorted(sessions, key=lambda x: x['created'], reverse=True)

# --- ADVANCED HASH IMPLEMENTATIONS ---

class ProfessionalHashImplementations:
    """Professional-grade hash implementations with salt support"""
    
    def __init__(self):
        self._crc16_table = self._generate_crc16_table()
        self._crc32_table = self._generate_crc32_table()
        
    def _generate_crc16_table(self):
        """Generate CRC-16 lookup table"""
        table = []
        for i in range(256):
            crc = i
            for _ in range(8):
                if crc & 1:
                    crc = (crc >> 1) ^ 0xA001
                else:
                    crc >>= 1
            table.append(crc)
        return table
    
    def _generate_crc32_table(self):
        """Generate CRC-32 lookup table"""
        table = []
        for i in range(256):
            crc = i
            for _ in range(8):
                if crc & 1:
                    crc = (crc >> 1) ^ 0xEDB88320
                else:
                    crc >>= 1
            table.append(crc)
        return table
    
    def hash_with_salt(self, algorithm, password, salt="", salt_position="suffix"):
        """Hash with salt support"""
        if isinstance(password, str):
            password = password.encode('utf-8')
        if isinstance(salt, str):
            salt = salt.encode('utf-8')
        
        if salt_position == "prefix":
            data = salt + password
        elif salt_position == "suffix":
            data = password + salt
        elif salt_position == "both":
            data = salt + password + salt
        else:
            data = password
        
        if algorithm == "md5":
            return hashlib.md5(data).hexdigest()
        elif algorithm == "sha1":
            return hashlib.sha1(data).hexdigest()
        elif algorithm == "sha256":
            return hashlib.sha256(data).hexdigest()
        elif algorithm == "sha512":
            return hashlib.sha512(data).hexdigest()
        elif algorithm == "ntlm":
            # NTLM doesn't use salt traditionally
            return self._pure_python_md4(password.decode('utf-8').encode('utf-16le'))
        else:
            # Fallback to basic hash
            return hashlib.md5(data).hexdigest()
    
    def _pure_python_md4(self, message: bytes) -> str:
        """Pure Python MD4 implementation"""
        h = [0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476]

        def F(x, y, z): return (x & y) | (~x & z)
        def G(x, y, z): return (x & y) | (x & z) | (y & z)
        def H(x, y, z): return x ^ y ^ z
        
        def left_rotate(n, b):
            return ((n << b) | (n >> (32 - b))) & 0xffffffff

        message_len = len(message)
        message += b'\x80'
        message += b'\x00' * (-(message_len + 9) % 64)
        message += struct.pack('<Q', message_len * 8)

        for i in range(0, len(message), 64):
            chunk = message[i:i+64]
            X = list(struct.unpack('<16I', chunk))
            A, B, C, D = h[0], h[1], h[2], h[3]

            # Round 1
            s1 = [3, 7, 11, 19]
            for j in range(16):
                k = j
                s = s1[j % 4]
                A = left_rotate((A + F(B, C, D) + X[k]) & 0xffffffff, s)
                A, B, C, D = D, A, B, C

            # Round 2
            s2 = [3, 5, 9, 13]
            for j in range(16):
                k = (j // 4) + (j % 4) * 4
                s = s2[j % 4]
                A = left_rotate((A + G(B, C, D) + X[k] + 0x5a827999) & 0xffffffff, s)
                A, B, C, D = D, A, B, C

            # Round 3
            s3 = [3, 9, 11, 15]
            k_map = [0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 13, 3, 11, 7, 15]
            for j in range(16):
                k = k_map[j]
                s = s3[j % 4]
                A = left_rotate((A + H(B, C, D) + X[k] + 0x6ed9eba1) & 0xffffffff, s)
                A, B, C, D = D, A, B, C

            h[0] = (h[0] + A) & 0xffffffff
            h[1] = (h[1] + B) & 0xffffffff
            h[2] = (h[2] + C) & 0xffffffff
            h[3] = (h[3] + D) & 0xffffffff

        return "".join(f'{val:08x}' for val in struct.unpack('<IIII', struct.pack('>IIII', *h)))

# --- ADVANCED RULES ENGINE ---

class AdvancedRulesEngine:
    """Hashcat-style rules engine for password transformation"""
    
    def __init__(self):
        # This map links rule characters to the methods that implement them.
        self.rules_map = {
            ':': self._do_nothing,
            'l': self._lowercase,
            'u': self._uppercase,
            'c': self._capitalize,
            'C': self._invert_capitalize,
            't': self._toggle_case,
            'T': self._toggle_at_position,
            'r': self._reverse,
            'd': self._duplicate,
            'p': self._purge_char,
            's': self._substitute,
            '$': self._append_char,
            '^': self._prepend_char,
            '[': self._delete_first,
            ']': self._delete_last,
            'D': self._delete_at_position,
            'x': self._extract_substring,
            'i': self._insert_at_position,
            'o': self._overwrite_at_position,
            '\'': self._truncate_at,
        }
    
    def apply_rules(self, word, rules_list):
        """Apply a list of rules to a word"""
        result = [word]
        
        for rule_string in rules_list:
            new_result = []
            for current_word in result:
                transformed = self._apply_single_rule(current_word, rule_string)
                if transformed and transformed not in new_result:
                    # Ensure we handle single strings and lists uniformly
                    new_result.extend(transformed if isinstance(transformed, list) else [transformed])
            result = new_result
            
            # Prevent memory overload from rules that generate too many candidates
            if len(result) > 10000:
                result = result[:10000]
        
        return result
    
    def _apply_single_rule(self, word, rule):
        """Apply a single rule string to a word. This is the main logic hub."""
        if not rule or not word:
            return [word]

        current_word = word
        i = 0
        while i < len(rule):
            cmd = rule[i]
            
            # Simple, argument-less rules
            if cmd == ':': pass
            elif cmd == 'l': current_word = current_word.lower()
            elif cmd == 'u': current_word = current_word.upper()
            elif cmd == 'c': current_word = current_word.capitalize()
            elif cmd == 'C': current_word = self._invert_capitalize(current_word)
            elif cmd == 't': current_word = current_word.swapcase()
            elif cmd == 'r': current_word = current_word[::-1]
            elif cmd == 'd': current_word = current_word + current_word
            elif cmd == '[': current_word = current_word[1:] if current_word else ""
            elif cmd == ']': current_word = current_word[:-1] if current_word else ""

            # Rules that take one character argument
            elif cmd in ('$', '^', 'p', '\''):
                if i + 1 < len(rule):
                    arg = rule[i + 1]
                    if cmd == '$': current_word = self._append_char(current_word, arg)
                    elif cmd == '^': current_word = self._prepend_char(current_word, arg)
                    elif cmd == 'p': current_word = self._purge_char(current_word, arg)
                    elif cmd == '\'': current_word = self._truncate_at(current_word, int(arg))
                    i += 1
            
            # Rules that take two character arguments
            elif cmd in ('s', 'o', 'i'):
                if i + 2 < len(rule):
                    arg1 = rule[i + 1]
                    arg2 = rule[i + 2]
                    if cmd == 's': current_word = self._substitute(current_word, arg1, arg2)
                    elif cmd == 'o': current_word = self._overwrite_at_position(current_word, int(arg1), arg2)
                    elif cmd == 'i': current_word = self._insert_at_position(current_word, int(arg1), arg2)
                    i += 2
            i += 1
            
        return [current_word] if current_word else [word]

    # --- Rule Method Implementations ---
    # All methods referenced in the rules_map must be defined here.

    def _do_nothing(self, word): return word
    def _lowercase(self, word): return word.lower()
    def _uppercase(self, word): return word.upper()
    def _capitalize(self, word): return word.capitalize()
    def _invert_capitalize(self, word):
        return word[0].upper() + word[1:].lower() if word else ""
    def _toggle_case(self, word): return word.swapcase()
    def _reverse(self, word): return word[::-1]
    def _duplicate(self, word): return word + word
    def _append_char(self, word, char): return word + char
    def _prepend_char(self, word, char): return char + word
    def _delete_first(self, word): return word[1:] if word else ""
    def _delete_last(self, word): return word[:-1] if word else ""
    def _purge_char(self, word, char_to_purge): return word.replace(char_to_purge, '')
    def _substitute(self, word, old_char, new_char): return word.replace(old_char, new_char)
    def _toggle_at_position(self, word, pos):
        pos = int(pos)
        if 0 <= pos < len(word):
            chars = list(word)
            chars[pos] = chars[pos].swapcase()
            return "".join(chars)
        return word
    def _delete_at_position(self, word, pos):
        pos = int(pos)
        return word[:pos] + word[pos+1:] if 0 <= pos < len(word) else word
    def _truncate_at(self, word, pos):
        pos = int(pos)
        return word[:pos] if 0 <= pos < len(word) else word
    def _insert_at_position(self, word, pos, char):
        pos = int(pos)
        return word[:pos] + char + word[pos:] if 0 <= pos <= len(word) else word
    def _overwrite_at_position(self, word, pos, char):
        pos = int(pos)
        if 0 <= pos < len(word):
            return word[:pos] + char + word[pos+1:]
        return word
    def _extract_substring(self, word, start, length):
        start, length = int(start), int(length)
        return word[start:start+length] if 0 <= start < len(word) else word


# --- MULTIPROCESSING WORKER ---

def multiprocess_worker(worker_args):
    """Worker function for multiprocessing hash cracking"""
    try:
        passwords, target_hash, algorithm, salt, salt_position, start_idx, end_idx = worker_args
        hash_impl = ProfessionalHashImplementations()
        
        for i, password in enumerate(passwords[start_idx:end_idx], start_idx):
            if algorithm in ['md5', 'sha1', 'sha256', 'sha512']:
                if salt:
                    computed_hash = hash_impl.hash_with_salt(algorithm, password, salt, salt_position)
                else:
                    computed_hash = getattr(hashlib, algorithm)(password.encode()).hexdigest()
            elif algorithm == 'ntlm':
                computed_hash = hash_impl._pure_python_md4(password.encode('utf-16le'))
            elif algorithm == 'bcrypt' and PASSLIB_AVAILABLE:
                try:
                    if bcrypt.verify(password, target_hash):
                        return {'found': True, 'password': password, 'index': i}
                    continue
                except:
                    continue
            else:
                # Fallback to basic MD5
                computed_hash = hashlib.md5(password.encode()).hexdigest()
            
            if computed_hash.lower() == target_hash.lower():
                return {'found': True, 'password': password, 'index': i}
        
        return {'found': False, 'processed': end_idx - start_idx}
    
    except Exception as e:
        return {'found': False, 'error': str(e)}

# --- ENHANCED CORE LOGIC ---

class ProfessionalHashCrackerCore:
    """Professional-grade hash cracking core with advanced features"""
    
    def __init__(self):
        self.hash_impl = ProfessionalHashImplementations()
        self.rules_engine = AdvancedRulesEngine()
        self.session_manager = SessionManager()
        
        self.algorithms = {
            'md5': self.check_md5, 'sha1': self.check_sha1, 'sha224': self.check_sha224,
            'sha256': self.check_sha256, 'sha384': self.check_sha384, 'sha512': self.check_sha512,
            'sha3_224': self.check_sha3_224, 'sha3_256': self.check_sha3_256,
            'sha3_384': self.check_sha3_384, 'sha3_512': self.check_sha3_512,
            'blake2b': self.check_blake2b, 'blake2s': self.check_blake2s, 'bcrypt': self.check_bcrypt,
            'pbkdf2_sha256': self.check_pbkdf2, 'argon2': self.check_argon2,
            'sha256_crypt': self.check_sha256_crypt, 'sha512_crypt': self.check_sha512_crypt,
            'ntlm': self.check_ntlm, 'lm': self.check_lm, 'md4': self.check_md4,
            'crc16': self.check_crc16, 'crc32': self.check_crc32, 'adler32': self.check_adler32,
            'mysql': self.check_mysql, 'mysql5': self.check_mysql5,
            'postgres_md5': self.check_postgres_md5, 'des_unix': self.check_des_unix,
            'md5_unix': self.check_md5_unix, 'ripemd160': self.check_ripemd160,
            'whirlpool': self.check_whirlpool, 'tiger': self.check_tiger,
            'md5_salt': self.check_md5_salt, 'sha1_salt': self.check_sha1_salt,
            'sha256_salt': self.check_sha256_salt, 'sha512_salt': self.check_sha512_salt,
        }
        
        self.hash_patterns = {
            'md5': r'^[a-f0-9]{32}$', 'sha1': r'^[a-f0-9]{40}$', 'sha224': r'^[a-f0-9]{56}$',
            'sha256': r'^[a-f0-9]{64}$', 'sha384': r'^[a-f0-9]{96}$', 'sha512': r'^[a-f0-9]{128}$',
            'ntlm': r'^[a-f0-9]{32}$', 'bcrypt': r'^\$2[aby]?\$\d+\$[./A-Za-z0-9]{53}$',
            'pbkdf2_sha256': r'^\$pbkdf2-sha256\$(\d+)\$([A-Za-z0-9+/=]+)\$([A-Za-z0-9+/=]+)$',
            'argon2': r'^\$argon2(id|d|i)\$v=\d+\$m=\d+,t=\d+,p=\d+\$[A-Za-z0-9+/=]+\$[A-Za-z0-9+/=]+$',
            'mysql5': r'^\*[A-F0-9]{40}$', 'des_unix': r'^[./A-Za-z0-9]{13}$',
            'md5_unix': r'^\$1\$[^$]{0,8}\$[./A-Za-z0-9]{22}$',
            'sha256_crypt': r'^\$5\$[^$]{0,16}\$[./A-Za-z0-9]{43}$',
            'sha512_crypt': r'^\$6\$[^$]{0,16}\$[./A-Za-z0-9]{86}$',
        }
        
        self.cpu_count = multiprocessing.cpu_count()
        self.use_multiprocessing = True
        
    def detect_hash_type(self, hash_str):
        detected = [algo for algo, pattern in self.hash_patterns.items() if re.match(pattern, hash_str, re.IGNORECASE)]
        if len(detected) > 1:
            priority = ['bcrypt', 'argon2', 'pbkdf2_sha256', 'mysql5', 'des_unix', 'md5_unix', 'sha256_crypt', 'sha512_crypt']
            for p in priority:
                if p in detected: return p
        return detected[0] if detected else 'unknown'

    def check_hash_with_salt(self, password, target_hash, algorithm, salt="", salt_position="suffix"):
        try:
            if algorithm.endswith('_salt'):
                base_algo = algorithm.replace('_salt', '')
                computed_hash = self.hash_impl.hash_with_salt(base_algo, password, salt, salt_position)
                return computed_hash.lower() == target_hash.lower()
            return self.check_hash(password, target_hash, algorithm)
        except Exception as e:
            logger.error(f"Error checking hash: {e}")
            return False

    def check_hash(self, password, target_hash, algorithm):
        if algorithm not in self.algorithms: return False
        try:
            return self.algorithms[algorithm](password, target_hash)
        except Exception as e:
            logger.error(f"Error in {algorithm}: {e}")
            return False

    def check_md5(self, password, target_hash): return hashlib.md5(password.encode()).hexdigest().lower() == target_hash.lower()
    def check_sha1(self, password, target_hash): return hashlib.sha1(password.encode()).hexdigest().lower() == target_hash.lower()
    def check_sha224(self, password, target_hash): return hashlib.sha224(password.encode()).hexdigest().lower() == target_hash.lower()
    def check_sha256(self, password, target_hash): return hashlib.sha256(password.encode()).hexdigest().lower() == target_hash.lower()
    def check_sha384(self, password, target_hash): return hashlib.sha384(password.encode()).hexdigest().lower() == target_hash.lower()
    def check_sha512(self, password, target_hash): return hashlib.sha512(password.encode()).hexdigest().lower() == target_hash.lower()
    def check_sha3_224(self, password, target_hash): return hashlib.sha3_224(password.encode()).hexdigest().lower() == target_hash.lower()
    def check_sha3_256(self, password, target_hash): return hashlib.sha3_256(password.encode()).hexdigest().lower() == target_hash.lower()
    def check_sha3_384(self, password, target_hash): return hashlib.sha3_384(password.encode()).hexdigest().lower() == target_hash.lower()
    def check_sha3_512(self, password, target_hash): return hashlib.sha3_512(password.encode()).hexdigest().lower() == target_hash.lower()
    def check_blake2b(self, password, target_hash): return hashlib.blake2b(password.encode()).hexdigest().lower() == target_hash.lower()
    def check_blake2s(self, password, target_hash): return hashlib.blake2s(password.encode()).hexdigest().lower() == target_hash.lower()
    def check_ntlm(self, password, target_hash): return self.hash_impl._pure_python_md4(password.encode('utf-16le')).lower() == target_hash.lower()
    def check_md4(self, password, target_hash): return self.hash_impl._pure_python_md4(password.encode()).lower() == target_hash.lower()
    def check_bcrypt(self, password, target_hash):
        if not PASSLIB_AVAILABLE: return False
        try: return bcrypt.verify(password, target_hash)
        except: return False
    def check_pbkdf2(self, password, target_hash):
        if not PASSLIB_AVAILABLE: return False
        try: return pbkdf2_sha256.verify(password, target_hash)
        except: return False
    def check_argon2(self, password, target_hash):
        if not PASSLIB_AVAILABLE: return False
        try: return argon2.verify(password, target_hash)
        except: return False
    def check_sha256_crypt(self, password, target_hash):
        if not PASSLIB_AVAILABLE: return False
        try: return sha256_crypt.verify(password, target_hash)
        except: return False
    def check_sha512_crypt(self, password, target_hash):
        if not PASSLIB_AVAILABLE: return False
        try: return sha512_crypt.verify(password, target_hash)
        except: return False
    def check_mysql5(self, password, target_hash):
        if target_hash.startswith('*'):
            return '*' + hashlib.sha1(hashlib.sha1(password.encode()).digest()).hexdigest().upper() == target_hash.upper()
        return False
    def check_mysql(self, password, target_hash): return False
    def check_postgres_md5(self, password, target_hash): return False
    def check_lm(self, password, target_hash): return False
    def check_crc16(self, password, target_hash): return False
    def check_crc32(self, password, target_hash): return f"{(zlib.crc32(password.encode()) & 0xffffffff):08x}".lower() == target_hash.lower()
    def check_adler32(self, password, target_hash): return f"{(zlib.adler32(password.encode()) & 0xffffffff):08x}".lower() == target_hash.lower()
    def check_des_unix(self, password, target_hash): return False
    def check_md5_unix(self, password, target_hash): return False
    def check_ripemd160(self, password, target_hash):
        try: return hashlib.new('ripemd160', password.encode()).hexdigest().lower() == target_hash.lower()
        except: return False
    def check_whirlpool(self, password, target_hash):
        try: return hashlib.new('whirlpool', password.encode()).hexdigest().lower() == target_hash.lower()
        except: return False
    def check_tiger(self, password, target_hash): return False
    def check_md5_salt(self, password, target_hash): return False
    def check_sha1_salt(self, password, target_hash): return False
    def check_sha256_salt(self, password, target_hash): return False
    def check_sha512_salt(self, password, target_hash): return False

    def multiprocess_crack(self, passwords, target_hash, algorithm, salt="", salt_position="suffix", num_processes=None):
        if not self.use_multiprocessing: return None
        if num_processes is None: num_processes = min(self.cpu_count, 8)
        if len(passwords) < 1000: return None
        
        chunk_size = len(passwords) // num_processes
        chunks = [(passwords, target_hash, algorithm, salt, salt_position, i * chunk_size, (i + 1) * chunk_size if i < num_processes - 1 else len(passwords)) for i in range(num_processes)]
        
        try:
            with multiprocessing.Pool(processes=num_processes) as pool:
                results = pool.map(multiprocess_worker, chunks)
                for r in results:
                    if r.get('found'): return r
                return {'found': False, 'processed': sum(r.get('processed', 0) for r in results)}
        except Exception as e:
            logger.error(f"Multiprocessing error: {e}")
            return None

    def combinator_attack(self, wordlist1, wordlist2, max_combinations=1000000):
        combinations = []
        count = 0
        for w1 in wordlist1:
            for w2 in wordlist2:
                if count >= max_combinations: break
                combinations.append(w1.strip() + w2.strip())
                count += 1
            if count >= max_combinations: break
        return combinations

    def estimate_time(self, total_candidates, current_speed):
        if current_speed <= 0: return "Unknown"
        remaining = total_candidates / current_speed
        if remaining < 60: return f"{remaining:.0f}s"
        if remaining < 3600: return f"{remaining/60:.1f}m"
        if remaining < 86400: return f"{remaining/3600:.1f}h"
        return f"{remaining/86400:.1f}d"

# --- STYLISH GUI IMPLEMENTATION ---

class ProfessionalHashcrackerGUI(tk.Frame):
    """Stylish and colorful GUI with advanced features"""
    
    def __init__(self, master):
        super().__init__(master)
        self.master = master
        self.core = ProfessionalHashCrackerCore()
        
        self.cracking_thread = None
        self.running = False
        self.paused = threading.Event()
        self.paused.set()
        
        self.total_passwords = 0
        self.processed_count = 0
        self.start_time = 0
        self.last_update_time = 0
        self.current_speed = 0
        self.session_data = {}
        
        self.update_queue = queue.Queue()
        self.result_queue = queue.Queue()
        
        self.init_database()
        self.configure_ui()
        self.create_widgets()
        self.process_updates()
        
        if PSUTIL_AVAILABLE:
            self.start_system_monitoring()
            
    def configure_ui(self):
        """Configure the stylish and colorful UI theme"""
        self.master.title('PyHashCracker Professional - Celestial Edition')
        self.master.geometry('950x800')
        self.master.minsize(950, 700)
        
        # Colors
        self.BG_COLOR = "#0f172a"
        self.FRAME_COLOR = "#1e293b"
        self.TEXT_COLOR = "#e2e8f0"
        self.ACCENT_COLOR = "#38bdf8"
        self.SUCCESS_COLOR = "#4ade80"
        self.ERROR_COLOR = "#f43f5e"
        self.BUTTON_COLOR = "#334155"
        self.BUTTON_HOVER = "#475569"
        
        self.master.configure(bg=self.BG_COLOR)
        
        self.style = ttk.Style()
        self.style.theme_use('alt')
        
        self.style.configure('.', background=self.BG_COLOR, foreground=self.TEXT_COLOR, font=('Roboto', 10))
        self.style.configure('TFrame', background=self.BG_COLOR)
        self.style.configure('TLabel', background=self.BG_COLOR, foreground=self.TEXT_COLOR, font=('Roboto', 10))
        self.style.configure('TButton', background=self.BUTTON_COLOR, foreground=self.TEXT_COLOR, font=('Roboto', 10, 'bold'), borderwidth=0, padding=(10, 5))
        self.style.map('TButton', background=[('active', self.BUTTON_HOVER), ('pressed', self.ACCENT_COLOR)])
        self.style.configure('TEntry', fieldbackground=self.FRAME_COLOR, foreground=self.TEXT_COLOR, bordercolor=self.BUTTON_COLOR, insertcolor=self.TEXT_COLOR)
        self.style.configure('TCombobox', fieldbackground=self.FRAME_COLOR, foreground=self.TEXT_COLOR, selectbackground=self.BUTTON_HOVER)
        self.style.configure('TCheckbutton', background=self.BG_COLOR, foreground=self.TEXT_COLOR)
        self.style.configure('Horizontal.TProgressbar', background=self.ACCENT_COLOR, troughcolor=self.FRAME_COLOR, borderwidth=0)
        self.style.configure('TLabelFrame', background=self.BG_COLOR, foreground=self.TEXT_COLOR, bordercolor=self.BUTTON_COLOR)
        self.style.configure('TLabelFrame.Label', background=self.BG_COLOR, foreground=self.ACCENT_COLOR, font=('Roboto', 11, 'bold'))

        self.style.configure('TNotebook', background=self.BG_COLOR, borderwidth=0)
        self.style.configure('TNotebook.Tab', background=self.FRAME_COLOR, foreground=self.TEXT_COLOR, padding=[10, 5], font=('Roboto', 10, 'bold'), borderwidth=0)
        self.style.map('TNotebook.Tab', background=[('selected', self.ACCENT_COLOR), ('active', self.BUTTON_HOVER)])

    def create_widgets(self):
        """Create the stylish GUI widgets"""
        main_frame = ttk.Frame(self)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        self.create_title_section(main_frame)
        
        self.notebook = ttk.Notebook(main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True, pady=(20, 0))
        
        self.create_cracking_tab()
        self.create_session_tab()
        self.create_tools_tab()
        self.create_monitoring_tab()
        self.create_potfile_tab()
        
        self.create_bottom_controls(main_frame)
        self.create_professional_menu()
        
        self.pack(fill=tk.BOTH, expand=True)

    def create_title_section(self, parent):
        """Create title and status section"""
        title_frame = ttk.Frame(parent)
        title_frame.pack(fill=tk.X, pady=(0, 10))
        
        title_label = ttk.Label(title_frame, text='PyHashCracker Pro', font=('Roboto', 24, 'bold'), foreground=self.ACCENT_COLOR)
        title_label.pack(side=tk.LEFT)
        
        if PSUTIL_AVAILABLE:
            system_info = f"CPU Cores: {psutil.cpu_count()} | RAM: {psutil.virtual_memory().total // (1024**3)}GB"
        else:
            system_info = f"CPU Cores: {multiprocessing.cpu_count()}"
        
        info_label = ttk.Label(title_frame, text=system_info, font=('Roboto', 9))
        info_label.pack(side=tk.RIGHT, pady=(10,0))

    def create_cracking_tab(self):
        """Create the main hash cracking tab"""
        crack_frame = ttk.Frame(self.notebook, style='TFrame')
        self.notebook.add(crack_frame, text="🚀 Cracking")

        # Configurations
        config_frame = ttk.Frame(crack_frame)
        config_frame.pack(fill=tk.X)

        # Hash section
        hash_section = ttk.LabelFrame(config_frame, text="Target Configuration", padding=10)
        hash_section.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0,10))

        ttk.Label(hash_section, text="Target Hash:").pack(anchor=tk.W, padx=10, pady=(10,0))
        self.hash_entry = ttk.Entry(hash_section, font=('Consolas', 10), width=60)
        self.hash_entry.pack(fill=tk.X, padx=10, pady=5)
        
        salt_frame = ttk.Frame(hash_section)
        salt_frame.pack(fill=tk.X, padx=10, pady=5)
        ttk.Label(salt_frame, text="Salt:").pack(side=tk.LEFT)
        self.salt_entry = ttk.Entry(salt_frame, width=20)
        self.salt_entry.pack(side=tk.LEFT, padx=5)
        self.salt_position = ttk.Combobox(salt_frame, values=["suffix", "prefix", "both"], state="readonly", width=8)
        self.salt_position.set("suffix")
        self.salt_position.pack(side=tk.LEFT)

        algo_frame = ttk.Frame(hash_section)
        algo_frame.pack(fill=tk.X, padx=10, pady=(5,10))
        ttk.Label(algo_frame, text="Algorithm:").pack(side=tk.LEFT)
        algorithms = sorted(list(self.core.algorithms.keys()))
        self.algorithm_var = tk.StringVar(value=algorithms[0] if algorithms else "")
        self.algorithm_combo = ttk.Combobox(algo_frame, textvariable=self.algorithm_var, values=algorithms, state="readonly", width=18)
        self.algorithm_combo.pack(side=tk.LEFT, padx=5)
        self.detect_button = ttk.Button(algo_frame, text="Auto-Detect", command=self.detect_hash)
        self.detect_button.pack(side=tk.LEFT)
        
        # Attack section
        attack_section = ttk.LabelFrame(config_frame, text="Attack Configuration", padding=10)
        attack_section.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(10,0))
        
        mode_frame = ttk.Frame(attack_section)
        mode_frame.pack(fill=tk.X, padx=10, pady=(10,5))
        self.attack_mode = tk.StringVar(value="dictionary")
        modes = [("Dictionary", "dictionary"), ("Brute Force", "brute_force"), ("Mask", "mask"), ("Rules", "rules"), ("Combinator", "combinator")]
        for text, value in modes:
            rb = ttk.Radiobutton(mode_frame, text=text, variable=self.attack_mode, value=value, command=self.update_attack_options)
            rb.pack(side=tk.LEFT, padx=(0, 10))

        self.options_frame = ttk.Frame(attack_section)
        self.options_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(5,10))
        self.create_attack_options()
        
        # Progress and Console
        results_frame = ttk.Frame(crack_frame)
        results_frame.pack(fill=tk.BOTH, expand=True, pady=(10,0))
        
        self.progress = ttk.Progressbar(results_frame, mode='indeterminate', style='Horizontal.TProgressbar')
        self.progress.pack(fill=tk.X, pady=(0, 10))
        
        stats_frame = ttk.Frame(results_frame)
        stats_frame.pack(fill=tk.X, pady=(0, 10))
        self.status_label = ttk.Label(stats_frame, text="Status: Ready", font=('Roboto', 10, 'bold'))
        self.status_label.pack(side=tk.LEFT)
        self.speed_label = ttk.Label(stats_frame, text="Speed: 0 H/s")
        self.speed_label.pack(side=tk.LEFT, padx=20)
        self.processed_label = ttk.Label(stats_frame, text="Processed: 0")
        self.processed_label.pack(side=tk.LEFT)
        self.eta_label = ttk.Label(stats_frame, text="ETA: Unknown")
        self.eta_label.pack(side=tk.RIGHT)
        
        self.console_text = scrolledtext.ScrolledText(results_frame, height=10, font=('Consolas', 9), bg="#0a0f1a", fg=self.ACCENT_COLOR, insertbackground=self.ACCENT_COLOR, selectbackground="#264f78", relief='flat', borderwidth=0)
        self.console_text.pack(fill=tk.BOTH, expand=True)

    def create_session_tab(self):
        session_frame = ttk.Frame(self.notebook)
        self.notebook.add(session_frame, text="📂 Sessions")

        controls_frame = ttk.LabelFrame(session_frame, text="Session Controls", padding=10)
        controls_frame.pack(fill=tk.X, padx=10, pady=10)
        ttk.Button(controls_frame, text="Save Session", command=self.save_session).pack(side=tk.LEFT, padx=5)
        ttk.Button(controls_frame, text="Load Session", command=self.load_session).pack(side=tk.LEFT, padx=5)
        ttk.Button(controls_frame, text="Refresh List", command=self.refresh_sessions).pack(side=tk.LEFT, padx=5)

        list_frame = ttk.LabelFrame(session_frame, text="Saved Sessions", padding=10)
        list_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0,10))
        
        columns = ('Session ID', 'Algorithm', 'Attack Mode', 'Created', 'Status')
        self.sessions_tree = ttk.Treeview(list_frame, columns=columns, show='headings')
        for col in columns:
            self.sessions_tree.heading(col, text=col)
            self.sessions_tree.column(col, width=150, anchor='center')
        self.sessions_tree.pack(fill=tk.BOTH, expand=True)
        self.refresh_sessions()

    def create_tools_tab(self):
        tools_frame = ttk.Frame(self.notebook)
        self.notebook.add(tools_frame, text="🔧 Tools")

        gen_frame = ttk.LabelFrame(tools_frame, text="Hash Generator", padding=10)
        gen_frame.pack(fill=tk.X, padx=10, pady=10)
        
        input_frame = ttk.Frame(gen_frame)
        input_frame.pack(fill=tk.X, padx=10, pady=10)
        ttk.Label(input_frame, text="Input:").pack(side=tk.LEFT)
        self.gen_input = ttk.Entry(input_frame, width=30)
        self.gen_input.pack(side=tk.LEFT, padx=5)
        ttk.Label(input_frame, text="Salt:").pack(side=tk.LEFT)
        self.gen_salt = ttk.Entry(input_frame, width=20)
        self.gen_salt.pack(side=tk.LEFT, padx=5)
        ttk.Button(input_frame, text="Generate", command=self.generate_hashes).pack(side=tk.LEFT, padx=5)
        
        self.gen_results = scrolledtext.ScrolledText(gen_frame, height=8, font=('Consolas', 9), bg=self.FRAME_COLOR, fg=self.TEXT_COLOR, relief='flat')
        self.gen_results.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0,10))

        bench_frame = ttk.LabelFrame(tools_frame, text="Algorithm Benchmark", padding=10)
        bench_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0,10))
        ttk.Button(bench_frame, text="Run Benchmark", command=self.run_benchmark).pack(pady=10)
        self.bench_results = scrolledtext.ScrolledText(bench_frame, height=10, font=('Consolas', 9), bg=self.FRAME_COLOR, fg=self.TEXT_COLOR, relief='flat')
        self.bench_results.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0,10))

    def create_monitoring_tab(self):
        monitor_frame = ttk.Frame(self.notebook)
        self.notebook.add(monitor_frame, text="📈 Monitor")
        
        if not PSUTIL_AVAILABLE:
            ttk.Label(monitor_frame, text="psutil library not found. System monitoring disabled.", font=('Roboto', 12, 'bold')).pack(pady=50)
            return

        main_frame = ttk.Frame(monitor_frame)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.cpu_label = ttk.Label(main_frame, text="CPU: 0%", font=('Roboto', 16, 'bold'))
        self.cpu_label.pack(pady=10)
        self.memory_label = ttk.Label(main_frame, text="Memory: 0%", font=('Roboto', 16, 'bold'))
        self.memory_label.pack(pady=10)

    def create_potfile_tab(self):
        potfile_frame = ttk.Frame(self.notebook)
        self.notebook.add(potfile_frame, text="🔑 Potfile")

        controls_frame = ttk.Frame(potfile_frame)
        controls_frame.pack(fill=tk.X, padx=10, pady=10)
        ttk.Button(controls_frame, text="Refresh", command=self.refresh_potfile).pack(side=tk.LEFT, padx=5)
        ttk.Button(controls_frame, text="Export", command=self.export_potfile).pack(side=tk.LEFT, padx=5)
        ttk.Button(controls_frame, text="Clear All", command=self.clear_potfile).pack(side=tk.LEFT, padx=5)
        
        search_frame = ttk.Frame(controls_frame)
        search_frame.pack(side=tk.RIGHT)
        ttk.Label(search_frame, text="Search:").pack(side=tk.LEFT)
        self.search_entry = ttk.Entry(search_frame, width=30)
        self.search_entry.pack(side=tk.LEFT, padx=5)
        self.search_entry.bind('<KeyRelease>', self.search_potfile)
        
        pot_columns = ('Hash', 'Password', 'Algorithm', 'Cracked Time')
        self.potfile_tree = ttk.Treeview(potfile_frame, columns=pot_columns, show='headings')
        for col in pot_columns:
            self.potfile_tree.heading(col, text=col)
            self.potfile_tree.column(col, width=200 if col != 'Hash' else 300, anchor='center')
        self.potfile_tree.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0,10))
        self.refresh_potfile()

    def create_bottom_controls(self, parent):
        control_frame = ttk.Frame(parent)
        control_frame.pack(fill=tk.X, pady=(15, 0))
        
        self.start_button = ttk.Button(control_frame, text="▶ Start Attack", command=self.start_attack)
        self.start_button.pack(side=tk.LEFT, padx=(0, 10))
        self.stop_button = ttk.Button(control_frame, text="■ Stop", command=self.stop_attack, state=tk.DISABLED)
        self.stop_button.pack(side=tk.LEFT, padx=(0, 10))
        self.pause_button = ttk.Button(control_frame, text="❚❚ Pause", command=self.pause_resume, state=tk.DISABLED)
        self.pause_button.pack(side=tk.LEFT)

    def create_professional_menu(self):
        menubar = tk.Menu(self.master, bg=self.FRAME_COLOR, fg=self.TEXT_COLOR, activebackground=self.BUTTON_HOVER, activeforeground=self.ACCENT_COLOR, relief=tk.FLAT)
        self.master.config(menu=menubar)

        file_menu = tk.Menu(menubar, tearoff=0, bg=self.FRAME_COLOR, fg=self.TEXT_COLOR)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="New Session", command=self.new_session)
        file_menu.add_command(label="Save Session", command=self.save_session)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.master.quit)
        
        help_menu = tk.Menu(menubar, tearoff=0, bg=self.FRAME_COLOR, fg=self.TEXT_COLOR)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="About", command=self.show_about)

    def create_attack_options(self):
        for widget in self.options_frame.winfo_children():
            widget.destroy()
        mode = self.attack_mode.get()
        if mode == "dictionary": self.create_dictionary_options()
        elif mode == "brute_force": self.create_brute_force_options()
        elif mode == "mask": self.create_mask_options()
        elif mode == "rules": self.create_rules_options()
        elif mode == "combinator": self.create_combinator_options()

    def create_dictionary_options(self):
        wordlist_frame = ttk.Frame(self.options_frame)
        wordlist_frame.pack(fill=tk.X, padx=10, pady=10)
        ttk.Label(wordlist_frame, text="Wordlist:").pack(side=tk.LEFT)
        self.wordlist_entry = ttk.Entry(wordlist_frame)
        self.wordlist_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        ttk.Button(wordlist_frame, text="Browse", command=self.browse_wordlist).pack(side=tk.RIGHT)

    def create_brute_force_options(self):
        main_frame = ttk.Frame(self.options_frame)
        main_frame.pack(fill=tk.X, padx=10, pady=10)

        check_frame = ttk.Frame(main_frame)
        check_frame.pack(fill=tk.X)
        self.lowercase_var = tk.BooleanVar(value=True)
        self.uppercase_var = tk.BooleanVar(value=True)
        self.digits_var = tk.BooleanVar(value=True)
        self.symbols_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(check_frame, text="a-z", variable=self.lowercase_var).pack(side=tk.LEFT)
        ttk.Checkbutton(check_frame, text="A-Z", variable=self.uppercase_var).pack(side=tk.LEFT, padx=10)
        ttk.Checkbutton(check_frame, text="0-9", variable=self.digits_var).pack(side=tk.LEFT)
        ttk.Checkbutton(check_frame, text="Symbols", variable=self.symbols_var).pack(side=tk.LEFT, padx=10)

        length_frame = ttk.Frame(main_frame)
        length_frame.pack(fill=tk.X, pady=5)
        ttk.Label(length_frame, text="Min Length:").pack(side=tk.LEFT)
        self.min_length = ttk.Spinbox(length_frame, from_=1, to=20, width=5)
        self.min_length.set(1)
        self.min_length.pack(side=tk.LEFT, padx=5)
        ttk.Label(length_frame, text="Max Length:").pack(side=tk.LEFT)
        self.max_length = ttk.Spinbox(length_frame, from_=1, to=20, width=5)
        self.max_length.set(8)
        self.max_length.pack(side=tk.LEFT, padx=5)

    def create_mask_options(self):
        mask_frame = ttk.Frame(self.options_frame)
        mask_frame.pack(fill=tk.X, padx=10, pady=10)
        ttk.Label(mask_frame, text="Mask Pattern:").pack(side=tk.LEFT)
        self.mask_entry = ttk.Entry(mask_frame)
        self.mask_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        ttk.Label(self.options_frame, text="?l=lower ?u=upper ?d=digits ?s=symbols", font=('Roboto', 8)).pack(padx=10, pady=(0,5))
        
    def create_rules_options(self):
        rules_frame = ttk.Frame(self.options_frame)
        rules_frame.pack(fill=tk.X, padx=10, pady=10)
        ttk.Label(rules_frame, text="Wordlist:").pack(side=tk.LEFT)
        self.rules_wordlist_entry = ttk.Entry(rules_frame)
        self.rules_wordlist_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        ttk.Button(rules_frame, text="Browse", command=self.browse_rules_wordlist).pack(side=tk.RIGHT)
        
        rules_file_frame = ttk.Frame(self.options_frame)
        rules_file_frame.pack(fill=tk.X, padx=10, pady=(0,10))
        ttk.Label(rules_file_frame, text="Rules File:").pack(side=tk.LEFT)
        self.rules_file_entry = ttk.Entry(rules_file_frame)
        self.rules_file_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        ttk.Button(rules_file_frame, text="Browse", command=self.browse_rules_file).pack(side=tk.RIGHT)

    def create_combinator_options(self):
        combo_frame1 = ttk.Frame(self.options_frame)
        combo_frame1.pack(fill=tk.X, padx=10, pady=(10,5))
        ttk.Label(combo_frame1, text="Wordlist 1:").pack(side=tk.LEFT)
        self.combinator_wordlist1_entry = ttk.Entry(combo_frame1)
        self.combinator_wordlist1_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        ttk.Button(combo_frame1, text="Browse", command=self.browse_combinator_wordlist1).pack(side=tk.RIGHT)

        combo_frame2 = ttk.Frame(self.options_frame)
        combo_frame2.pack(fill=tk.X, padx=10, pady=(0,10))
        ttk.Label(combo_frame2, text="Wordlist 2:").pack(side=tk.LEFT)
        self.combinator_wordlist2_entry = ttk.Entry(combo_frame2)
        self.combinator_wordlist2_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        ttk.Button(combo_frame2, text="Browse", command=self.browse_combinator_wordlist2).pack(side=tk.RIGHT)

    def update_attack_options(self):
        self.create_attack_options()

    def init_database(self):
        self.db_path = "hashcracker_professional.db"
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS potfile (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, hash TEXT NOT NULL, password TEXT NOT NULL,
                    algorithm TEXT NOT NULL, salt TEXT DEFAULT '', salt_position TEXT DEFAULT 'suffix',
                    cracked_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, session_id TEXT DEFAULT '',
                    UNIQUE(hash, algorithm, salt))''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, session_id TEXT UNIQUE NOT NULL, name TEXT NOT NULL,
                    algorithm TEXT NOT NULL, attack_mode TEXT NOT NULL, target_hash TEXT NOT NULL,
                    salt TEXT DEFAULT '', configuration TEXT, status TEXT DEFAULT 'saved',
                    created_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, last_accessed TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
            conn.commit()

    def start_system_monitoring(self):
        def monitor():
            while True:
                try:
                    if PSUTIL_AVAILABLE:
                        cpu = psutil.cpu_percent(interval=1)
                        mem = psutil.virtual_memory().percent
                        self.update_queue.put(lambda: self.cpu_label.config(text=f"CPU: {cpu:.1f}%"))
                        self.update_queue.put(lambda: self.memory_label.config(text=f"Memory: {mem:.1f}%"))
                except Exception as e:
                    logger.error(f"System monitoring error: {e}")
                time.sleep(2)
        threading.Thread(target=monitor, daemon=True).start()

    def process_updates(self):
        try:
            while not self.update_queue.empty():
                self.update_queue.get_nowait()()
        except queue.Empty:
            pass
        self.master.after(100, self.process_updates)

    def detect_hash(self):
        hash_str = self.hash_entry.get().strip()
        if not hash_str:
            messagebox.showwarning("Warning", "Please enter a hash.")
            return
        detected = self.core.detect_hash_type(hash_str)
        if detected != 'unknown':
            self.algorithm_var.set(detected)
            self.console_log(f"Detected hash type: {detected}", self.SUCCESS_COLOR)
        else:
            self.console_log("Could not detect hash type.", self.ERROR_COLOR)

    def console_log(self, message, color=None):
        timestamp = datetime.now().strftime("[%H:%M:%S]")
        full_message = f"{timestamp} {message}\n"
        
        self.console_text.config(state=tk.NORMAL)
        if color:
            tag_name = f"color_{color.replace('#', '')}"
            self.console_text.tag_config(tag_name, foreground=color)
            self.console_text.insert(tk.END, full_message, tag_name)
        else:
            self.console_text.insert(tk.END, full_message)
        self.console_text.config(state=tk.DISABLED)
        self.console_text.see(tk.END)

    def browse_wordlist(self):
        filename = filedialog.askopenfilename(title="Select Wordlist")
        if filename:
            self.wordlist_entry.delete(0, tk.END)
            self.wordlist_entry.insert(0, filename)

    def browse_rules_wordlist(self):
        filename = filedialog.askopenfilename(title="Select Base Wordlist")
        if filename:
            self.rules_wordlist_entry.delete(0, tk.END)
            self.rules_wordlist_entry.insert(0, filename)
            
    def browse_rules_file(self):
        filename = filedialog.askopenfilename(title="Select Rules File")
        if filename:
            self.rules_file_entry.delete(0, tk.END)
            self.rules_file_entry.insert(0, filename)
            
    def browse_combinator_wordlist1(self):
        filename = filedialog.askopenfilename(title="Select First Wordlist")
        if filename:
            self.combinator_wordlist1_entry.delete(0, tk.END)
            self.combinator_wordlist1_entry.insert(0, filename)
            
    def browse_combinator_wordlist2(self):
        filename = filedialog.askopenfilename(title="Select Second Wordlist")
        if filename:
            self.combinator_wordlist2_entry.delete(0, tk.END)
            self.combinator_wordlist2_entry.insert(0, filename)

    def start_attack(self):
        if self.running: return

        hash_str = self.hash_entry.get().strip()
        algorithm = self.algorithm_var.get()
        if not hash_str or not algorithm:
            messagebox.showerror("Error", "Hash and algorithm are required.")
            return
            
        if self.check_potfile(hash_str, algorithm, self.salt_entry.get().strip()):
            self.console_log(f"FOUND in potfile: {self.check_potfile(hash_str, algorithm, self.salt_entry.get().strip())}", self.SUCCESS_COLOR)
            return

        params = {'hash': hash_str, 'algorithm': algorithm, 'mode': self.attack_mode.get(), 'salt': self.salt_entry.get().strip(), 'salt_position': self.salt_position.get()}
        
        # Mode-specific params
        mode = params['mode']
        if mode == 'dictionary':
            if not self.wordlist_entry.get(): messagebox.showerror("Error", "Wordlist file required."); return
            params['wordlist'] = self.wordlist_entry.get()
        elif mode == 'brute_force':
            charset = ""
            if self.lowercase_var.get(): charset += string.ascii_lowercase
            if self.uppercase_var.get(): charset += string.ascii_uppercase
            if self.digits_var.get(): charset += string.digits
            if self.symbols_var.get(): charset += string.punctuation
            if not charset: messagebox.showerror("Error", "Character set required."); return
            params['charset'] = charset
            params['min_length'] = int(self.min_length.get())
            params['max_length'] = int(self.max_length.get())
        elif mode == 'mask':
            if not self.mask_entry.get(): messagebox.showerror("Error", "Mask pattern required."); return
            params['mask'] = self.mask_entry.get()
        elif mode == 'rules':
            if not self.rules_wordlist_entry.get() or not self.rules_file_entry.get(): messagebox.showerror("Error", "Wordlist and rules file required."); return
            params['wordlist'] = self.rules_wordlist_entry.get()
            params['rules_file'] = self.rules_file_entry.get()
        elif mode == 'combinator':
            if not self.combinator_wordlist1_entry.get() or not self.combinator_wordlist2_entry.get(): messagebox.showerror("Error", "Two wordlists required."); return
            params['wordlist1'] = self.combinator_wordlist1_entry.get()
            params['wordlist2'] = self.combinator_wordlist2_entry.get()

        self.session_data = params.copy()
        self.running = True
        self.processed_count = 0
        self.start_time = time.time()
        self.start_button.config(state=tk.DISABLED)
        self.stop_button.config(state=tk.NORMAL)
        self.pause_button.config(state=tk.NORMAL)
        self.progress.config(mode='indeterminate')
        self.progress.start()
        
        self.console_log(f"Starting {params['mode']} attack on {params['algorithm']} hash...")
        
        self.cracking_thread = threading.Thread(target=self.execute_attack, args=(params,), daemon=True)
        self.cracking_thread.start()

    def execute_attack(self, params):
        try:
            mode = params['mode']
            if mode == "dictionary": self._execute_dictionary_attack(params)
            elif mode == "brute_force": self._execute_brute_force_attack(params)
            elif mode == "mask": self._execute_mask_attack(params)
            elif mode == "rules": self._execute_rules_attack(params)
            elif mode == "combinator": self._execute_combinator_attack(params)
        except Exception as e:
            self.update_queue.put(lambda: self.console_log(f"Attack error: {e}", self.ERROR_COLOR))
            logger.error(f"Attack execution error: {e}", exc_info=True)
        finally:
            self.running = False
            self.update_queue.put(self.attack_finished)

    def _execute_dictionary_attack(self, params):
        try:
            with open(params['wordlist'], 'r', encoding='utf-8', errors='ignore') as f:
                passwords = [line.strip() for line in f if line.strip()]
            self.total_passwords = len(passwords)
            self.update_queue.put(lambda: self.console_log(f"Loaded {self.total_passwords:,} passwords."))

            for i, password in enumerate(passwords):
                if not self.running: break
                self.paused.wait()
                if self.core.check_hash_with_salt(password, params['hash'], params['algorithm'], params['salt'], params['salt_position']):
                    self.update_queue.put(lambda p=password: self.console_log(f"PASSWORD FOUND: {p}", self.SUCCESS_COLOR))
                    self.save_to_potfile(params['hash'], password, params['algorithm'], params['salt'], params['salt_position'])
                    return
                self.processed_count += 1
                if i % 1000 == 0: self.update_statistics()
            if self.running:
                self.update_queue.put(lambda: self.console_log("Dictionary attack completed. Password not found.", self.ERROR_COLOR))
        except FileNotFoundError:
            self.update_queue.put(lambda: self.console_log(f"Wordlist not found: {params['wordlist']}", self.ERROR_COLOR))

    def _execute_brute_force_attack(self, params):
        for length in range(params['min_length'], params['max_length'] + 1):
            if not self.running: break
            self.update_queue.put(lambda l=length: self.console_log(f"Trying passwords of length {l}..."))
            for p_tuple in itertools.product(params['charset'], repeat=length):
                if not self.running: break
                self.paused.wait()
                password = "".join(p_tuple)
                if self.core.check_hash_with_salt(password, params['hash'], params['algorithm'], params['salt'], params['salt_position']):
                    self.update_queue.put(lambda p=password: self.console_log(f"PASSWORD FOUND: {p}", self.SUCCESS_COLOR))
                    self.save_to_potfile(params['hash'], password, params['algorithm'], params['salt'], params['salt_position'])
                    return
                self.processed_count += 1
                if self.processed_count % 10000 == 0: self.update_statistics()
        if self.running:
            self.update_queue.put(lambda: self.console_log("Brute force attack completed. Password not found.", self.ERROR_COLOR))
        
    def _execute_mask_attack(self, params):
        mask_charsets = {'?l': string.ascii_lowercase, '?u': string.ascii_uppercase, '?d': string.digits, '?s': string.punctuation}
        charsets = []
        i = 0
        while i < len(params['mask']):
            if params['mask'][i:i+2] in mask_charsets:
                charsets.append(mask_charsets[params['mask'][i:i+2]])
                i += 2
            else:
                charsets.append(params['mask'][i])
                i += 1

        for p_tuple in itertools.product(*charsets):
            if not self.running: break
            self.paused.wait()
            password = "".join(p_tuple)
            if self.core.check_hash_with_salt(password, params['hash'], params['algorithm'], params['salt'], params['salt_position']):
                self.update_queue.put(lambda p=password: self.console_log(f"PASSWORD FOUND: {p}", self.SUCCESS_COLOR))
                self.save_to_potfile(params['hash'], password, params['algorithm'], params['salt'], params['salt_position'])
                return
            self.processed_count += 1
            if self.processed_count % 10000 == 0: self.update_statistics()
        if self.running:
            self.update_queue.put(lambda: self.console_log("Mask attack completed. Password not found.", self.ERROR_COLOR))
        
    def _execute_rules_attack(self, params):
        with open(params['rules_file'], 'r') as f:
            rules = [line.strip() for line in f if line.strip() and not line.startswith('#')]
        with open(params['wordlist'], 'r', encoding='utf-8', errors='ignore') as f:
            for word in f:
                if not self.running: break
                variants = self.core.rules_engine.apply_rules(word.strip(), rules)
                for variant in variants:
                    if not self.running: break
                    self.paused.wait()
                    if self.core.check_hash_with_salt(variant, params['hash'], params['algorithm'], params['salt'], params['salt_position']):
                        self.update_queue.put(lambda v=variant: self.console_log(f"PASSWORD FOUND: {v}", self.SUCCESS_COLOR))
                        self.save_to_potfile(params['hash'], variant, params['algorithm'], params['salt'], params['salt_position'])
                        return
                    self.processed_count += 1
                    if self.processed_count % 1000 == 0: self.update_statistics()
        if self.running:
            self.update_queue.put(lambda: self.console_log("Rules attack completed. Password not found.", self.ERROR_COLOR))
    
    def _execute_combinator_attack(self, params):
        with open(params['wordlist1'], 'r', encoding='utf-8', errors='ignore') as f1:
            wordlist1 = [line.strip() for line in f1 if line.strip()]
        with open(params['wordlist2'], 'r', encoding='utf-8', errors='ignore') as f2:
            wordlist2 = [line.strip() for line in f2 if line.strip()]
        
        for w1 in wordlist1:
            if not self.running: break
            for w2 in wordlist2:
                if not self.running: break
                self.paused.wait()
                password = w1 + w2
                if self.core.check_hash_with_salt(password, params['hash'], params['algorithm'], params['salt'], params['salt_position']):
                    self.update_queue.put(lambda p=password: self.console_log(f"PASSWORD FOUND: {p}", self.SUCCESS_COLOR))
                    self.save_to_potfile(params['hash'], password, params['algorithm'], params['salt'], params['salt_position'])
                    return
                self.processed_count += 1
                if self.processed_count % 1000 == 0: self.update_statistics()
        if self.running:
            self.update_queue.put(lambda: self.console_log("Combinator attack completed. Password not found.", self.ERROR_COLOR))

    def update_statistics(self):
        elapsed = time.time() - self.start_time
        if elapsed > 0.5: # Update stats every half a second to avoid flooding the UI thread
            speed = self.processed_count / elapsed
            eta = self.core.estimate_time(self.total_passwords - self.processed_count, speed) if self.total_passwords > 0 and speed > 0 else "Unknown"
            self.update_queue.put(lambda s=speed: self.speed_label.config(text=f"Speed: {s:,.0f} H/s"))
            self.update_queue.put(lambda c=self.processed_count: self.processed_label.config(text=f"Processed: {c:,}"))
            self.update_queue.put(lambda e=eta: self.eta_label.config(text=f"ETA: {e}"))
            if self.total_passwords > 0:
                progress = (self.processed_count / self.total_passwords) * 100
                self.update_queue.put(lambda p=progress: self.progress.config(mode='determinate', value=p))

    def stop_attack(self):
        self.running = False
        self.console_log("Stopping attack...", self.ERROR_COLOR)

    def pause_resume(self):
        if self.paused.is_set():
            self.paused.clear()
            self.pause_button.config(text="▶ Resume")
            self.console_log("Attack paused.")
        else:
            self.paused.set()
            self.pause_button.config(text="❚❚ Pause")
            self.console_log("Attack resumed.")

    def attack_finished(self):
        self.start_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)
        self.pause_button.config(state=tk.DISABLED, text="❚❚ Pause")
        self.progress.stop()
        self.progress.config(mode='determinate', value=0)
        self.console_log("Attack finished.")

    def save_to_potfile(self, hash_value, password, algorithm, salt="", salt_position="suffix"):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute('INSERT OR REPLACE INTO potfile (hash, password, algorithm, salt, salt_position) VALUES (?, ?, ?, ?, ?)',
                         (hash_value, password, algorithm, salt, salt_position))
            conn.commit()
        self.console_log(f"Saved to potfile: {hash_value[:32]}... -> {password}", self.SUCCESS_COLOR)

    def check_potfile(self, hash_value, algorithm, salt=""):
        with sqlite3.connect(self.db_path) as conn:
            result = conn.execute('SELECT password FROM potfile WHERE hash = ? AND algorithm = ? AND salt = ?', (hash_value, algorithm, salt)).fetchone()
            return result[0] if result else None

    def save_session(self):
        if not self.session_data:
            messagebox.showwarning("Warning", "No active session to save.")
            return
        session_id = f"session_{int(time.time())}"
        name = f"Session {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        with sqlite3.connect(self.db_path) as conn:
            conn.execute('INSERT INTO sessions (session_id, name, algorithm, attack_mode, target_hash, salt, configuration) VALUES (?,?,?,?,?,?,?)',
                         (session_id, name, self.session_data.get('algorithm',''), self.session_data.get('mode',''), self.session_data.get('hash',''), self.session_data.get('salt',''), json.dumps(self.session_data)))
            conn.commit()
        self.console_log(f"Session saved: {name}", self.SUCCESS_COLOR)
        self.refresh_sessions()

    def load_session(self):
        selection = self.sessions_tree.selection()
        if not selection: return
        session_id = self.sessions_tree.item(selection[0])['values'][0]
        with sqlite3.connect(self.db_path) as conn:
            config_json = conn.execute('SELECT configuration FROM sessions WHERE session_id = ?', (session_id,)).fetchone()
        if config_json:
            config = json.loads(config_json[0])
            self.hash_entry.delete(0, tk.END); self.hash_entry.insert(0, config.get('hash', ''))
            self.salt_entry.delete(0, tk.END); self.salt_entry.insert(0, config.get('salt', ''))
            self.salt_position.set(config.get('salt_position', 'suffix'))
            self.algorithm_var.set(config.get('algorithm', ''))
            self.attack_mode.set(config.get('mode', 'dictionary'))
            self.update_attack_options()
            if config.get('mode') == 'dictionary' and 'wordlist' in config:
                self.wordlist_entry.delete(0, tk.END); self.wordlist_entry.insert(0, config['wordlist'])
            self.console_log(f"Session loaded: {session_id}", self.SUCCESS_COLOR)

    def refresh_sessions(self):
        for i in self.sessions_tree.get_children(): self.sessions_tree.delete(i)
        with sqlite3.connect(self.db_path) as conn:
            for row in conn.execute('SELECT session_id, name, algorithm, attack_mode, created_time, status FROM sessions ORDER BY created_time DESC'):
                self.sessions_tree.insert('', tk.END, values=row)

    def new_session(self):
        self.session_data = {}
        self.hash_entry.delete(0, tk.END)
        self.salt_entry.delete(0, tk.END)
        self.console_text.config(state=tk.NORMAL)
        self.console_text.delete(1.0, tk.END)
        self.console_text.config(state=tk.DISABLED)
        self.console_log("New session started.")

    def refresh_potfile(self):
        for i in self.potfile_tree.get_children(): self.potfile_tree.delete(i)
        with sqlite3.connect(self.db_path) as conn:
            for row in conn.execute('SELECT hash, password, algorithm, cracked_time FROM potfile ORDER BY cracked_time DESC'):
                self.potfile_tree.insert('', tk.END, values=row)

    def search_potfile(self, event=None):
        term = f"%{self.search_entry.get().lower()}%"
        for i in self.potfile_tree.get_children(): self.potfile_tree.delete(i)
        with sqlite3.connect(self.db_path) as conn:
            for row in conn.execute('SELECT hash, password, algorithm, cracked_time FROM potfile WHERE LOWER(hash) LIKE ? OR LOWER(password) LIKE ? OR LOWER(algorithm) LIKE ?', (term, term, term)):
                self.potfile_tree.insert('', tk.END, values=row)

    def export_potfile(self):
        filename = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")])
        if filename:
            import csv
            with sqlite3.connect(self.db_path) as conn, open(filename, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['ID', 'Hash', 'Password', 'Algorithm', 'Salt', 'Salt Position', 'Cracked Time', 'Session ID'])
                writer.writerows(conn.execute('SELECT * FROM potfile'))
            self.console_log(f"Potfile exported to {filename}", self.SUCCESS_COLOR)
            
    def clear_potfile(self):
        if messagebox.askyesno("Confirm", "Are you sure you want to clear the potfile?"):
            with sqlite3.connect(self.db_path) as conn:
                conn.execute('DELETE FROM potfile')
                conn.commit()
            self.refresh_potfile()
            self.console_log("Potfile cleared.", self.SUCCESS_COLOR)
            
    def generate_hashes(self):
        text = self.gen_input.get()
        if not text: return
        salt = self.gen_salt.get()
        self.gen_results.delete(1.0, tk.END)
        for algo in ['md5', 'sha1', 'sha256', 'sha512', 'ntlm']:
            if algo == 'ntlm':
                h = self.core.hash_impl._pure_python_md4(text.encode('utf-16le'))
            else:
                h = self.core.hash_impl.hash_with_salt(algo, text, salt) if salt else getattr(hashlib, algo)(text.encode()).hexdigest()
            self.gen_results.insert(tk.END, f"{algo.upper():<10}: {h}\n")
    
    def run_benchmark(self):
        self.bench_results.delete(1.0, tk.END)
        self.bench_results.insert(tk.END, "Running benchmark...\n")
        # Placeholder for actual benchmark logic
        def do_benchmark():
            time.sleep(2) # Simulate work
            self.update_queue.put(lambda: self.bench_results.insert(tk.END, "Benchmark complete (simulation)."))

        threading.Thread(target=do_benchmark, daemon=True).start()

    def show_about(self):
        messagebox.showinfo("About PyHashCracker Pro", "PyHashCracker Professional Edition\nVersion 3.1 - Fixed\n\nEnhanced for style and performance.")

def main():
    if hasattr(multiprocessing, 'set_start_method'):
        try:
            multiprocessing.set_start_method('spawn', force=True)
        except RuntimeError:
            pass
            
    root = tk.Tk()
    app = ProfessionalHashcrackerGUI(root)
    
    def signal_handler(sig, frame):
        root.quit()
    signal.signal(signal.SIGINT, signal_handler)
    
    root.mainloop()

if __name__ == '__main__':
    main()
