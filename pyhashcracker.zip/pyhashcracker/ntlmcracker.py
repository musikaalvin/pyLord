"""
Administrator:500: aad3b435b51404eeaad3b435b51404ee :7facdc498ed1680c4fd 1448319a8c04f: ::
    
    """
    

import time
import os
import sys
from passlib.hash import nthash

BATCH_SIZE = 500  # Tune this depending on RAM (increase for speed, decrease for phones)

def batch_generator(file_path, batch_size):
    """Yield batches of lines from file."""
    with open(file_path, 'r', errors='ignore') as f:
        batch = []
        for line in f:
            password = line.strip()
            if password:
                batch.append(password)
                if len(batch) == batch_size:
                    yield batch
                    batch = []
        if batch:
            yield batch

def ntlm_crack(target_hash, wordlist_path):
    print(f"\n[*] Cracking NTLM hash: {target_hash}")
    print(f"[*] Wordlist: {wordlist_path}")
    print(f"[*] Batch size: {BATCH_SIZE}\n")

    total_attempts = 0
    found_password = None
    start_time = time.time()

    # Placeholder for clean live update
    print("Progress Line Placeholder")
    print("Trying Line Placeholder")

    try:
        with open(wordlist_path, 'r', errors='ignore') as counter:
            total_lines = sum(1 for _ in counter)
    except Exception as e:
        print(f"[!] Could not count lines: {e}")
        return

    for batch_index, batch in enumerate(batch_generator(wordlist_path, BATCH_SIZE)):
        total_attempts += len(batch)
        elapsed = time.time() - start_time
        percent = (total_attempts / total_lines) * 100
        eta = (elapsed / total_attempts) * (total_lines - total_attempts) if total_attempts else 0

        # Move cursor up and clear 2 lines
        sys.stdout.write("\033[F\033[K")
        sys.stdout.write("\033[F\033[K")

        print(f"[{total_attempts}/{total_lines}] {percent:.2f}% | Elapsed: {int(elapsed)}s | ETA: {int(eta)}s")
        print(f"Trying batch #{batch_index + 1} (e.g. {batch[0]})")

        for pwd in batch:
            hashed = nthash.hash(pwd)
            if hashed.lower() == target_hash.lower():
                found_password = pwd
                break

        if found_password:
            break

    sys.stdout.write("\033[F\033[K")
    sys.stdout.write("\033[F\033[K")

    if found_password:
        print(f"\n[✔] Password cracked: **{found_password}**")
        return found_password
    else:
        print("\n[-] Password not found.")
        return None

def menu():
    while True:
        print("\n========= Batch NTLM Cracker =========")
        print("1. Crack NTLM hash")
        print("2. Exit")
        choice = input("Select an option: ").strip()

        if choice == "1":
            full_line = input("\nPaste the full hash line (e.g. user:uid:LM:NTLM::):\n").strip()
            parts = full_line.split(":")
            if len(parts) < 4:
                print("[!] Invalid hash format.")
                continue

            ntlm_hash = parts[3].strip()
            wordlist_path = input("\nEnter wordlist file path (or leave blank for default):\n").strip()
            if not wordlist_path:
                wordlist_path = "/storage/emulated/0/pyProjects/pass.txt"

            if not os.path.isfile(wordlist_path):
                print(f"[!] Wordlist not found: {wordlist_path}")
                continue

            ntlm_crack(ntlm_hash, wordlist_path)

        elif choice == "2":
            print("Goodbye, pyLord.")
            break
        else:
            print("[!] Invalid option.")

if __name__ == "__main__":
    try:
        menu()
    except KeyboardInterrupt:
        print("\n[!] Interrupted by user.")