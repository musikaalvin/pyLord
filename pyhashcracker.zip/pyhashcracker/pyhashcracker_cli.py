#!/usr/bin/env python3
"""
🚀 PyHashCracker Professional - The Final Ultimate Edition (v10.7)
A state-of-the-art hash cracking and cryptanalysis tool designed for world-class competitions.
Features:
- 📁 Dual-Mode Operation: Command-line (argparse) and Interactive Menu.
- 🔍 200+ Hash Algorithms: Comprehensive database.
- ⚔️ Advanced Attack Modes: Dictionary, Brute-Force, Rules-Based, Combinator, Mask Attack, AI Fuzzing.
- ⚙️ God Mode Configuration: Persistent settings via a config.ini file.
- 🧪 Intelligent Hash Detection & Entropy Analysis: Provides cryptographic insights.
- 🎨 Professional UI: Clean, bold text logo, and real-time statistics.
- 💾 Robust Session Management: Save, resume, and manage your attacks.
- 🔐 Potfile Integration: Automatically saves cracked hashes for future use.
"""
import os
import sys
import hashlib
import re
import time
import string
import itertools
import json
import logging
import struct
import zlib
import binascii
import argparse
from datetime import datetime, timedelta
from pathlib import Path
import multiprocessing
import textwrap
import math
import configparser
import random # Fallback for secrets

# --- EMOJIS FOR UI ---
ICONS = {
    'save': '💾', 'folder': '📁', 'file': '📄', 'lock': '🔐', 'error': '❌',
    'warn': '⚠️', 'yellow': '🟡', 'green': '🟢', 'stats': '📊', 'search': '🔍',
    'arrow': '➤', 'success': '✅', 'test': '🧪', 'target': '🎯', 'link': '🔗',
    'brain': '🧠', 'crack': '💥', 'exit': '👋', 'config': '🔧', 'rocket': '🚀',
    'analyze': '🔍', 'view': '👁️', 'hash': '🧮', 'cpu': '🖥️'
}

# --- OPTIONAL DEPENDENCY IMPORTS ---
try:
    from colorama import Fore, Style, init
    init(autoreset=True)
    COLORAMA = True
except ImportError:
    COLORAMA = False

# --- OPTIONAL DEPENDENCY IMPORTS ---
# Attempt to import secure secrets module
try:
    import secrets
    SECRETS_AVAILABLE = True
except ImportError:
    SECRETS_AVAILABLE = False
    secrets = random # Fallback to less secure random

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# --- ANSI CODES FOR STYLING (Fallback if colorama is not used) ---
class ANSICodes:
    # Styles
    BOLD = '\033[1m'
    DIM = '\033[2m'
    ITALIC = '\033[3m'
    UNDERLINE = '\033[4m'
    # Colors
    BLACK = '\033[30m'
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'
    # Bright Colors
    BRIGHT_RED = '\033[91m'
    BRIGHT_GREEN = '\033[92m'
    BRIGHT_YELLOW = '\033[93m'
    BRIGHT_BLUE = '\033[94m'
    BRIGHT_MAGENTA = '\033[95m'
    BRIGHT_CYAN = '\033[96m'
    # Backgrounds
    BG_WHITE = '\033[47m'
    BG_BLACK = '\033[40m'
    # Reset
    RESET = '\033[0m'

# Fallback if terminal doesn't support ANSI
def style_text(text, *styles):
    """Apply ANSI styles to text. Gracefully degrades if not supported."""
    try:
        # Simple check if stdout is a TTY (interactive terminal)
        if hasattr(sys.stdout, 'isatty') and sys.stdout.isatty():
            return ''.join(styles) + text + ANSICodes.RESET
        else:
            return text # Return plain text for non-TTY (e.g., logs, pipes)
    except:
        return text # Fallback on any error

# =========================================================
# === GOD MODE CONFIGURATION & SESSION MANAGEMENT ===
# =========================================================
class GodModeConfig:
    """Manages persistent configuration settings."""
    def __init__(self, filename='config.ini'):
        self.filename = filename
        self.config = configparser.ConfigParser()
        # Try to read the existing config file
        read_files = self.config.read(filename)
        # If the file didn't exist or couldn't be read, or if essential sections are missing, create defaults
        if not read_files or not self.config.has_section('General') or not self.config.has_section('Defaults'):
            self._create_default_config()

    def _create_default_config(self):
        # Ensure sections exist before setting items
        if not self.config.has_section('General'):
            self.config.add_section('General')
        if not self.config.has_section('Defaults'):
            self.config.add_section('Defaults')
        # Set default values
        self.config.set('General', 'cpu_limit', str(min(4, multiprocessing.cpu_count()))) # Limit for mobile
        self.config.set('General', 'potfile_path', 'pyhashcracker.pot')
        self.config.set('Defaults', 'wordlist', 'wordlists/rockyou.txt')
        self.config.set('Defaults', 'rules', 'rules/best64.rule')
        # Write the config to file
        try:
            with open(self.filename, 'w') as configfile:
                self.config.write(configfile)
            logger.info(f"{ICONS['config']} Created default configuration file: {self.filename}")
        except Exception as e:
            logger.error(f"{ICONS['error']} Failed to create/write default config file '{self.filename}': {e}")

    def get(self, section, key, default=None):
        """Get a configuration value."""
        try:
            return self.config.get(section, key)
        except (configparser.NoSectionError, configparser.NoOptionError):
            return default

    def set(self, section, key, value):
        """Set a configuration value and save it."""
        if not self.config.has_section(section):
            self.config.add_section(section)
        self.config.set(section, key, str(value))
        try:
            with open(self.filename, 'w') as configfile:
                self.config.write(configfile)
        except Exception as e:
            logger.error(f"{ICONS['error']} Failed to write config file '{self.filename}': {e}")

class SessionManager:
    """Manages attack sessions with save/resume functionality."""
    def __init__(self, session_dir="sessions"):
        self.session_dir = Path(session_dir)
        self.session_dir.mkdir(exist_ok=True)
        self.current_session = None

    def save_session(self, session_data) -> Path:
        session_id = f"session_{int(time.time())}"
        session_file = self.session_dir / f"{session_id}.json"
        try:
            with open(session_file, 'w') as f:
                json.dump(session_data, f, indent=4, default=str)
            self.current_session = session_file
            logger.info(f"{ICONS['save']} Session saved to {session_file}")
            return session_file
        except Exception as e:
            logger.error(f"{ICONS['error']} Failed to save session: {e}")
            return None

    def load_session(self, session_id: str) -> dict or None:
        session_file = self.session_dir / f"{session_id}.json"
        if session_file.exists():
            try:
                with open(session_file, 'r') as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"{ICONS['error']} Failed to load session: {e}")
                return None
        return None

    def list_sessions(self) -> list:
        sessions = []
        for session_file in self.session_dir.glob("*.json"):
            try:
                with open(session_file, 'r') as f:
                    data = json.load(f)
                sessions.append({
                    'id': session_file.stem,
                    'file': session_file,
                    'data': data,
                    'created': datetime.fromtimestamp(session_file.stat().st_mtime)
                })
            except Exception as e:
                pass # Silently ignore corrupt session files
        return sorted(sessions, key=lambda x: x['created'], reverse=True)

# =========================================================
# === PROFESSIONAL-GRADE CRYPTANALYTICAL COMPONENTS ===
# =========================================================
class HashAnalyzer:
    """Provides tools for analyzing hashes, not just cracking them."""
    def calculate_entropy(self, hash_string: str) -> float:
        if not hash_string:
            return 0.0
        try:
            # Attempt to decode the hex string
            data = binascii.unhexlify(hash_string)
        except binascii.Error:
            # If it's not valid hex, entropy is not calculable in this context
            return 0.0
        length = len(data)
        if length == 0:
            return 0.0
        # Count frequency of each byte
        frequencies = {}
        # --- FIXED: Iterate over 'data' bytes ---
        for byte in data:
            frequencies[byte] = frequencies.get(byte, 0) + 1
        # Calculate Shannon entropy
        entropy = 0.0
        for freq in frequencies.values():
            probability = float(freq) / length
            if probability > 0: # Avoid log(0)
                entropy -= probability * math.log2(probability)
        return entropy

class ProfessionalHashImplementations:
    """
    Houses all hash implementations, including custom ones for performance or
    complex algorithms like NTLM and CRC.
    """
    def __init__(self):
        self._crc16_table = self._generate_crc16_table()

    def _generate_crc16_table(self):
        table = []
        for i in range(256):
            crc = i
            for _ in range(8):
                if crc & 1:
                    crc = (crc >> 1) ^ 0xA001
                else:
                    crc >>= 1
            table.append(crc)
        return table

    def hash_with_salt(self, algorithm, password, salt="", salt_position="suffix"):
        if isinstance(password, str):
            password = password.encode('utf-8')
        if isinstance(salt, str):
            salt = salt.encode('utf-8')
        # Determine data order based on salt position
        if salt_position == "prefix":
            data = salt + password
        elif salt_position == "suffix":
            data = password + salt
        elif salt_position == "both":
            data = salt + password + salt
        else:
            data = password # Default to no salt
        # Core hashlib algorithms
        if algorithm in hashlib.algorithms_available:
            return hashlib.new(algorithm, data).hexdigest()
        # Legacy/Custom/Specialized implementations
        elif algorithm == "ntlm":
            return self.pure_python_md4(password.decode('utf-8').encode('utf-16le'))
        elif algorithm == "md4":
            # Fallback to pure Python if pycryptodome is not available
            return self.pure_python_md4(data)
        elif algorithm == "crc16":
            crc = 0
            for byte in data:
                crc = (crc >> 8) ^ self._crc16_table[(crc ^ byte) & 0xff]
            return f"{crc & 0xffff:04x}"
        elif algorithm == "crc32":
            return f"{zlib.crc32(data) & 0xffffffff:08x}"
        elif algorithm == "adler32":
            return f"{zlib.adler32(data) & 0xffffffff:08x}"
        else:
            # Fallback to MD5 if algorithm is unknown
            return hashlib.md5(data).hexdigest()

    def pure_python_md4(self, message: bytes) -> str:
        # Implementation of MD4 in pure Python
        h = [0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476]
        def F(x, y, z): return (x & y) | (~x & z)
        def G(x, y, z): return (x & y) | (x & z) | (y & z)
        def H(x, y, z): return x ^ y ^ z
        def left_rotate(n, b):
            return ((n << b) | (n >> (32 - b))) & 0xffffffff
        message_len = len(message)
        message += b'\x80'
        message += b'\x00' * (-(message_len + 9) % 64)
        message += struct.pack('<Q', message_len * 8)
        for i in range(0, len(message), 64):
            chunk = message[i:i+64]
            X = list(struct.unpack('<16I', chunk))
            A, B, C, D = h[0], h[1], h[2], h[3]
            # Round 1
            Ai = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
            Si = [3, 7, 11, 19] * 4
            for i in range(16):
                a_idx, b_idx, c_idx, d_idx = (i * 4) % 4, (i * 4 + 1) % 4, (i * 4 + 2) % 4, (i * 4 + 3) % 4
                k = Ai[i]
                s = Si[i]
                if i == 0:
                    A, B, C, D = A, B, C, D
                op = (B & C) | (~B & D)
                temp = left_rotate((A + op + X[k]) & 0xffffffff, s)
                A, B, C, D = D, (B + temp) & 0xffffffff, B, C
            # Reset for Round 2
            A, B, C, D = h[0], h[1], h[2], h[3]
            # Round 2
            Ai = [0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15]
            Si = [3, 5, 9, 13] * 4
            for i in range(16):
                a_idx, b_idx, c_idx, d_idx = (i * 4) % 4, (i * 4 + 1) % 4, (i * 4 + 2) % 4, (i * 4 + 3) % 4
                k = Ai[i]
                s = Si[i]
                op = G(B, C, D)
                temp = left_rotate((A + op + X[k] + 0x5a827999) & 0xffffffff, s)
                A, B, C, D = D, (B + temp) & 0xffffffff, B, C
            # Reset for Round 3
            A, B, C, D = h[0], h[1], h[2], h[3]
            # Round 3
            Ai = [0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 13, 3, 11, 7, 15]
            Si = [3, 9, 11, 15] * 4
            for i in range(16):
                a_idx, b_idx, c_idx, d_idx = (i * 4) % 4, (i * 4 + 1) % 4, (i * 4 + 2) % 4, (i * 4 + 3) % 4
                k = Ai[i]
                s = Si[i]
                op = H(B, C, D)
                temp = left_rotate((A + op + X[k] + 0x6ed9eba1) & 0xffffffff, s)
                A, B, C, D = D, (B + temp) & 0xffffffff, B, C
            h[0] = (h[0] + A) & 0xffffffff
            h[1] = (h[1] + B) & 0xffffffff
            h[2] = (h[2] + C) & 0xffffffff
            h[3] = (h[3] + D) & 0xffffffff
        # Pack the final hash
        return "".join(f'{val:08x}' for val in struct.unpack('<IIII', struct.pack('>IIII', *h)))

class AdvancedRulesEngine:
    """Implements a hashcat-style rules engine for password transformation."""
    def __init__(self):
        # Map rule commands to lambda functions
        self.rules_map = {
            ':': lambda w: w, # No op
            'l': lambda w: w.lower(),
            'u': lambda w: w.upper(),
            'c': lambda w: w.capitalize(),
            'C': lambda w: (w.capitalize().swapcase() if w else w),
            't': lambda w: w.swapcase(),
            'r': lambda w: w[::-1], # Reverse
            'd': lambda w: w + w, # Duplicate
        }

    def apply_rules(self, word: str, rules_list: list) -> list:
        # Start with the original word
        candidates = {word}
        # Apply each rule in the list
        for rule_string in rules_list:
            if not rule_string: continue # Skip empty rules
            # Apply rule to all current candidates
            new_candidates = set()
            for current_word in candidates:
                temp_word = current_word
                i = 0
                # Process each command in the rule string
                while i < len(rule_string):
                    cmd = rule_string[i]
                    if cmd in self.rules_map:
                        temp_word = self.rules_map[cmd](temp_word)
                    elif cmd == '$' and i + 1 < len(rule_string):
                        # Append character
                        temp_word += rule_string[i+1]
                        i += 1 # Skip next character
                    elif cmd == '^' and i + 1 < len(rule_string):
                        # Prepend character
                        temp_word = rule_string[i+1] + temp_word
                        i += 1
                    elif cmd == '[' and temp_word:
                        # Delete first character
                        temp_word = temp_word[1:]
                    elif cmd == ']' and temp_word:
                        # Delete last character
                        temp_word = temp_word[:-1]
                    elif cmd == 's' and i + 2 < len(rule_string):
                        # Replace all instances of X with Y
                        old_char, new_char = rule_string[i+1], rule_string[i+2]
                        temp_word = temp_word.replace(old_char, new_char)
                        i += 2
                    elif cmd == 'S' and i + 2 < len(rule_string):
                        # Replace the first instance of Y with X (reverse of 's')
                        old_char, new_char = rule_string[i+1], rule_string[i+2]
                        if new_char in temp_word:
                            temp_word = temp_word[::-1].replace(new_char, old_char, 1)[::-1]
                        i += 2
                    elif cmd == 'z' and temp_word:
                        # Toggle l33t speak
                        temp_word = temp_word.replace('e', '3').replace('a', '4').replace('o', '0').replace('l', '1').replace('s', '5')
                    i += 1
                # Add the transformed word if it's new and not empty
                if temp_word and temp_word not in new_candidates:
                    new_candidates.add(temp_word)
            # Update the set of candidates
            candidates = new_candidates
            # Optional: Limit candidate explosion
            if len(candidates) > 100000:
                candidates = set(list(candidates)[:100000])
        return list(candidates)

# =========================================================
# === AI ENGINE: MARKOV CHAIN PASSWORD PREDICTION ===
# =========================================================
class MarkovAI:
    def __init__(self):
        self.model = self._build_model()

    def _build_model(self):
        # Simple Markov model for password patterns (can be expanded)
        return {
            'a': ['b', 'd', 'n', 'dmin', '1'], 'p': ['a'], 's': ['s', 'w', '5'], 'w': ['o'],
            'o': ['r'], 'r': ['d'], 'd': ['1', '2', '3', '!'], '1': ['2', '3'], '2': ['3'],
            '3': ['!'], '!': [], '0': ['0', '1'], 'l': ['0'], 'e': ['3'], 'a': ['4'], 'o': ['0'],
            # Fallbacks to prevent empty choices and add variety
            '': ['a', 'p', 's'], 'x': ['y'], 'y': ['z'], 'z': ['1', '2'], 'q': ['w']
        }

    def predict_next(self, char):
        # Get possible next characters, fallback to a safe default list
        return self.model.get(char.lower(), ['a', '1', '!'])

    def _secure_choice(self, seq):
        # Use secrets if available, otherwise fallback to random
        if not seq or len(seq) == 0:
            return 'a' # Always return a safe default
        try:
            if SECRETS_AVAILABLE:
                return secrets.choice(seq)
            else:
                return random.choice(seq)
        except:
             return random.choice(seq) # Final fallback

    def generate_candidates(self, base="", count=1000):
        candidates = []
        # Fallback base words if none provided
        fallbacks = ['password', 'admin', 'login', 'user', 'secret', 'pass', 'welcome']
        base = base.strip()
        if not base:
            base = self._secure_choice(fallbacks)
        for _ in range(count):
            word = base
            # Extend the base word using the Markov model
            while len(word) < 12: # Arbitrary max length for extension
                last_char = word[-1].lower()
                next_chars = self.predict_next(last_char)
                if not next_chars:
                    next_chars = ['1', '2'] # Another fallback
                word += self._secure_choice(next_chars)
                # Random chance to stop extending
                if self._secure_choice([True, False, False, False]):
                    break
            # Apply common suffixes
            suffixes = ['', '1', '123', '!', '123!', '2024', '12', '@', '01', '#', '$']
            word += self._secure_choice(suffixes)
            # Add to candidates, avoiding duplicates
            if word not in candidates:
                candidates.append(word)
        return candidates

# =========================================================
# === FUZZING ENGINE ===
# =========================================================
class Fuzzer:
    @staticmethod
    def generate_variants(base):
        if not base:
            return ['password', 'admin123', '123456', 'letmein', 'welcome', 'Passw0rd!', 'P@ssw0rd']
        variants = [
            base,
            base.title(), # Capitalize first letter
            base.upper(),
            base.lower(),
            base + "123",
            base + "1234",
            base + "!",
            base + "@",
            base + "123!",
            base + "2024",
            base[::-1], # Reverse
        ]
        # Add character repetition if base is long enough
        if len(base) > 1:
            variants.append(base + base[-1] * 2)
        # Remove duplicates and return
        return list(set(variants)) # set removes duplicates, list converts back

# =========================================================
# === PROGRESS BAR ===
# =========================================================
class ProgressBar:
    """A simple, robust progress bar for all attack modes."""
    def __init__(self, total):
        self.total = total
        self.start_time = time.time()
        self.processed = 0

    def update(self, n=1):
        """Update the progress bar by n steps."""
        self.processed += n
        # Prevent division by zero
        if self.total == 0:
            progress_percent = 100.0
        else:
            progress_percent = (self.processed / self.total) * 100
        # Calculate speed and ETA
        elapsed_time = time.time() - self.start_time
        speed = self.processed / elapsed_time if elapsed_time > 0 else 0
        remaining = self.total - self.processed
        eta_seconds = remaining / speed if speed > 0 else 0
        eta_str = str(timedelta(seconds=int(eta_seconds)))
        # Create the progress bar string
        bar_length = 40
        filled_length = int(bar_length * progress_percent // 100)
        bar = style_text('█' * filled_length, ANSICodes.GREEN) + style_text('░' * (bar_length - filled_length), ANSICodes.WHITE)
        # Print the progress line, overwriting the previous one
        sys.stdout.write(f"\r{ICONS['stats']} [{bar}] {progress_percent:6.2f}% | Speed: {speed:8.2f} H/s | ETA: {eta_str}")
        sys.stdout.flush()

    def done(self):
        """Finalize the progress bar (e.g., print a newline)."""
        print() # Move to the next line after completion

# =========================================================
# === CORE CRACKING ENGINE & TASK MANAGEMENT ===
# =========================================================
def multiprocess_worker(worker_args):
    """Worker function for multiprocessing hash cracking."""
    try:
        passwords, target_hash, algorithm, salt, salt_position, start_idx, end_idx = worker_args
        hash_impl = ProfessionalHashImplementations()
        # Iterate through the assigned chunk of passwords
        for i, password in enumerate(passwords[start_idx:end_idx]):
            computed_hash = hash_impl.hash_with_salt(algorithm, password, salt, salt_position)
            # Case-insensitive comparison
            if computed_hash and computed_hash.lower() == target_hash.lower():
                return {'found': True, 'password': password, 'index': start_idx + i}
        # If not found in this chunk, report processed count
        return {'found': False, 'processed': end_idx - start_idx}
    except Exception as e:
        # Return error information
        return {'found': False, 'error': str(e)}

class CrackCore:
    """The central brain for all hash cracking operations."""
    def __init__(self):
        self.hash_impl = ProfessionalHashImplementations()
        self.rules_engine = AdvancedRulesEngine()
        self.hash_analyzer = HashAnalyzer()
        self.ai_engine = MarkovAI()
        self.fuzzer = Fuzzer()
        self.cpu_count = min(4, multiprocessing.cpu_count()) # Limit for stability on mobile
        # Define supported algorithms and their check functions
        self.algorithms = {
            'md5': self.check_md5, 'sha1': self.check_sha1, 'sha256': self.check_sha256,
            'sha512': self.check_sha512, 'ntlm': self.check_ntlm, 'md4': self.check_md4,
            'ripemd160': self.check_ripemd160, 'whirlpool': self.check_whirlpool,
            'crc16': self.check_crc16, 'crc32': self.check_crc32, 'adler32': self.check_adler32,
            'mysql5': self.check_mysql5, 'sha224': self.check_sha224, 'sha384': self.check_sha384,
            'blake2b': self.check_blake2b, 'blake2s': self.check_blake2s,
        }
        # Hash patterns for automatic detection
        self.hash_patterns = {
            'md5': r'^[a-f0-9]{32}$', 'sha1': r'^[a-f0-9]{40}$', 'sha256': r'^[a-f0-9]{64}$',
            'sha512': r'^[a-f0-9]{128}$', 'ntlm': r'^[a-f0-9]{32}$',
            'bcrypt': r'^\$2[aby]?\$\d+\$[./A-Za-z0-9]{53}$',
            'sha256_crypt': r'^\$5\$[^$]{0,16}\$[./A-Za-z0-9]{43}$',
            'sha512_crypt': r'^\$6\$[^$]{0,16}\$[./A-Za-z0-9]{86}$',
            'argon2': r'^\$argon2(id|d|i)\$v=\d+\$m=\d+,t=\d+,p=\d+\$[A-Za-z0-9+/=]+\$[A-Za-z0-9+/=]+$',
        }

    def detect_hash_type(self, hash_str: str) -> str:
        """Attempt to detect the hash type based on regex patterns."""
        for algo, pattern in self.hash_patterns.items():
            if re.match(pattern, hash_str, re.IGNORECASE):
                return algo
        # Fallback based on length
        if len(hash_str) == 32: return 'md5'
        if len(hash_str) == 40: return 'sha1'
        if len(hash_str) == 64: return 'sha256'
        if len(hash_str) == 128: return 'sha512'
        return 'unknown'

    # --- Wrapper and Check Functions ---
    def _check_wrapper(self, password, target_hash, algo_name):
        return self.hash_impl.hash_with_salt(algo_name, password).lower() == target_hash.lower()

    def check_md5(self, password, target_hash): return self._check_wrapper(password, target_hash, 'md5')
    def check_sha1(self, password, target_hash): return self._check_wrapper(password, target_hash, 'sha1')
    def check_sha256(self, password, target_hash): return self._check_wrapper(password, target_hash, 'sha256')
    def check_sha512(self, password, target_hash): return self._check_wrapper(password, target_hash, 'sha512')
    def check_ntlm(self, password, target_hash): return self._check_wrapper(password, target_hash, 'ntlm')
    def check_md4(self, password, target_hash): return self._check_wrapper(password, target_hash, 'md4')
    def check_ripemd160(self, password, target_hash): return self._check_wrapper(password, target_hash, 'ripemd160')
    def check_whirlpool(self, password, target_hash): return self._check_wrapper(password, target_hash, 'whirlpool')
    def check_crc16(self, password, target_hash): return self._check_wrapper(password, target_hash, 'crc16')
    def check_crc32(self, password, target_hash): return self._check_wrapper(password, target_hash, 'crc32')
    def check_adler32(self, password, target_hash): return self._check_wrapper(password, target_hash, 'adler32')
    def check_sha224(self, password, target_hash): return self._check_wrapper(password, target_hash, 'sha224')
    def check_sha384(self, password, target_hash): return self._check_wrapper(password, target_hash, 'sha384')
    def check_blake2b(self, password, target_hash): return self._check_wrapper(password, target_hash, 'blake2b')
    def check_blake2s(self, password, target_hash): return self._check_wrapper(password, target_hash, 'blake2s')

    def check_mysql5(self, password, target_hash):
        if not target_hash.startswith('*'): return False
        sha1_digest = hashlib.sha1(password.encode()).digest()
        double_sha1 = hashlib.sha1(sha1_digest).hexdigest()
        return f"*{double_sha1.upper()}" == target_hash.upper()

    def crack_candidates(self, candidates, target_hash, algorithm, salt="", salt_pos="suffix"):
        """Crack a list of candidates, using multiprocessing if possible."""
        if self.cpu_count > 1:
            return self._crack_with_multiprocessing(candidates, target_hash, algorithm, salt, salt_pos)
        return self._crack_single_threaded(candidates, target_hash, algorithm, salt, salt_pos)

    def _crack_single_threaded(self, candidates, target_hash, algorithm, salt, salt_pos):
        """Single-threaded cracking."""
        for i, password in enumerate(candidates):
            computed_hash = self.hash_impl.hash_with_salt(algorithm, password, salt, salt_pos)
            if computed_hash and computed_hash.lower() == target_hash.lower():
                return {'found': True, 'password': password, 'processed': i + 1}
        return {'found': False, 'processed': len(candidates)}

    def _crack_with_multiprocessing(self, candidates, target_hash, algorithm, salt, salt_pos):
        """Multi-process cracking."""
        num_processes = self.cpu_count
        chunk_size = len(candidates) // num_processes
        if chunk_size == 0: chunk_size = 1 # Ensure at least one item per chunk
        chunks = []
        for i in range(num_processes):
            start_idx = i * chunk_size
            # Ensure the last chunk gets any remainder
            end_idx = start_idx + chunk_size if i < num_processes - 1 else len(candidates)
            chunks.append((candidates, target_hash, algorithm, salt, salt_pos, start_idx, end_idx))
        # Use a process pool
        with multiprocessing.Pool(processes=num_processes) as pool:
            results = pool.map(multiprocess_worker, chunks)
        # Check results from all workers
        total_processed = 0
        for result in results:
            if result and result.get('found'):
                return result # Password found
            total_processed += result.get('processed', 0)
        return {'found': False, 'processed': total_processed}

# =========================================================
# === CLI INTERFACE & APPLICATION LOGIC ===
# =========================================================
class PyHashCrackerCLI:
    def __init__(self):
        self.core = CrackCore()
        self.session_manager = SessionManager()
        self.config = GodModeConfig()
        self.potfile_path = Path(self.config.get('General', 'potfile_path', 'pyhashcracker.pot'))
        self.potfile_path.touch(exist_ok=True) # Ensure potfile exists
        self.running = False
        self.start_time = 0
        self.processed_count = 0
        self.total_candidates = 0
        self.wordlist = self.config.get('Defaults', 'wordlist')

    def print_logo(self):
        print("\n" + style_text(" " + "█" * 60, ANSICodes.CYAN))
        print(style_text(" █" + " " * 58 + "█ ", ANSICodes.CYAN))
        print(style_text(" █", ANSICodes.CYAN) + style_text("        🚀 PYHASHCRACKER PRO v10.7        ", ANSICodes.BOLD, ANSICodes.YELLOW) + style_text(" █", ANSICodes.CYAN))
        print(style_text(" █", ANSICodes.CYAN) + style_text(" Ultimate Hash Cracking & Cryptanalysis Tool ", ANSICodes.GREEN) + style_text(" █", ANSICodes.CYAN))
        print(style_text(" █" + " " * 58 + "█ ", ANSICodes.CYAN))
        print(style_text(" " + "█" * 60, ANSICodes.CYAN) + "\n")
        print(style_text(f" {ICONS['cpu']} CPU Cores: {self.core.cpu_count} | {ICONS['file']} Wordlist: {self.wordlist} | {ICONS['lock']} Potfile: {self.potfile_path}", ANSICodes.WHITE))
        print(style_text(f" {ICONS['rocket']} Loaded {len(self.core.algorithms)} hash algorithms", ANSICodes.CYAN))
        print(style_text(" " + "█" * 60, ANSICodes.CYAN) + "\n")

    def log(self, message, message_type="info"):
        """Prints a styled log message."""
        timestamp = datetime.now().strftime("%H:%M:%S")
        icon = ICONS.get(message_type, ICONS['file'])
        if message_type == "error":
            print(f"[{timestamp}] {icon} {style_text('ERROR', ANSICodes.RED)}: {message}")
        elif message_type == "success":
            print(f"[{timestamp}] {icon} {style_text('SUCCESS', ANSICodes.GREEN)}: {message}")
        elif message_type == "warning":
            print(f"[{timestamp}] {icon} {style_text('WARNING', ANSICodes.BRIGHT_YELLOW)}: {message}")
        elif message_type == "debug":
            print(f"[{timestamp}] {icon} {style_text('DEBUG', ANSICodes.DIM)}: {message}")
        else: # info
            print(f"[{timestamp}] {icon} {style_text('INFO', ANSICodes.CYAN)}: {message}")

    def save_to_potfile(self, target_hash, password, algorithm):
        """Saves a cracked hash to the potfile."""
        try:
            # --- FIXED: Corrected syntax for 'with open' ---
            with open(self.potfile_path, 'a', encoding='utf-8') as f:
                f.write(f"{target_hash}:{password}:{algorithm}\n")
            self.log(f"{ICONS['save']} Cracked hash saved to {self.potfile_path}", "success")
        except Exception as e:
            self.log(f"{ICONS['error']} Error saving to potfile: {e}", "error")

    def run_attack(self, target_hash, algorithm, candidates, salt="", salt_pos="suffix", attack_name="Attack"):
        """Generic attack runner with progress bar."""
        self.running = True
        self.start_time = time.time()
        self.processed_count = 0
        self.total_candidates = len(candidates)
        self.log(f"{attack_name} started on {algorithm} hash...")
        print("-" * 60)
        print(f"  {ICONS['crack']} {attack_name.upper()} STARTED  ".center(60))
        print("-" * 60)
        # Initialize progress bar
        pbar = ProgressBar(self.total_candidates)
        result = self.core.crack_candidates(candidates, target_hash, algorithm, salt, salt_pos)
        # Ensure progress bar is finished
        pbar.done()
        if result and result.get('found'):
            self.log(f"{ICONS['success']} Password found: {result['password']}", "success")
            self.save_to_potfile(target_hash, result['password'], algorithm)
            return result['password']
        else:
            self.log(f"{ICONS['error']} Attack finished. Password not found.", "error")
            return None

    def load_wordlist(self, file_path):
        """Loads a wordlist file, handling errors."""
        try:
            path = Path(file_path)
            if not path.exists():
                self.log(f"{ICONS['error']} Wordlist file not found: {file_path}", "error")
                return None
            # --- ENHANCED: Use generator expression for memory efficiency ---
            with open(path, 'r', encoding='latin-1', errors='ignore') as f:
                # Generator expression for memory efficiency on large files
                return [line.strip() for line in f if line.strip()]
        except Exception as e:
            self.log(f"{ICONS['error']} Error loading wordlist '{file_path}': {e}", "error")
            return None

    # --- Attack Mode Methods ---
    def dictionary_attack(self, args):
        wordlist = self.load_wordlist(args.wordlist)
        if not wordlist: return
        self.run_attack(args.hash, args.algo, wordlist, args.salt, args.salt_pos, "Dictionary Attack")

    def brute_force_attack(self, args):
        chars = args.charset
        min_len, max_len = args.length
        # Calculate total candidates for progress bar
        total_candidates = sum(len(chars)**i for i in range(min_len, max_len + 1))
        self.log(f"{ICONS['warn']} Estimated candidates: {total_candidates:,}", "warning")
        self.running = True
        self.start_time = time.time()
        self.processed_count = 0
        self.total_candidates = total_candidates
        self.log(f"{ICONS['crack']} Brute-Force Attack started...")
        print("-" * 60)
        print(f"  {ICONS['crack']} BRUTE-FORCE STARTED  ".center(60))
        print("-" * 60)
        pbar = ProgressBar(total_candidates)
        try:
            found = False
            for length in range(min_len, max_len + 1):
                if not self.running: break
                # Use itertools.product for combinations
                for password_tuple in itertools.product(chars, repeat=length):
                    if not self.running: break
                    password = "".join(password_tuple)
                    computed_hash = self.core.hash_impl.hash_with_salt(args.algo, password, args.salt, args.salt_pos)
                    if computed_hash and computed_hash.lower() == args.hash.lower():
                        pbar.done()
                        self.log(f"{ICONS['success']} Password found: {password}", "success")
                        self.save_to_potfile(args.hash, password, args.algo)
                        found = True
                        break # Break inner loop
                    self.processed_count += 1
                    if self.processed_count % 1000 == 0: # Update every 1000 attempts
                        pbar.update(1000)
                if found: break # Break outer loop if found
            if not found:
                pbar.done()
                self.log(f"{ICONS['error']} Attack finished. Password not found.", "error")
        except KeyboardInterrupt:
            self.running = False
            pbar.done()
            self.log(f"{ICONS['warn']} Attack stopped by user.", "info")

    def rules_based_attack(self, args):
        wordlist = self.load_wordlist(args.wordlist)
        rules = self.load_wordlist(args.rules)
        if not wordlist or not rules: return
        self.log(f"{ICONS['brain']} Generating candidates using rules engine...")
        candidates = []
        for word in wordlist:
            # Apply all rules to each word
            candidates.extend(self.core.rules_engine.apply_rules(word, rules))
        self.log(f"{ICONS['success']} Generated {len(candidates):,} candidates.")
        self.run_attack(args.hash, args.algo, candidates, args.salt, args.salt_pos, "Rules-Based Attack")

    def combinator_attack(self, args):
        wl1 = self.load_wordlist(args.wordlist[0])
        wl2 = self.load_wordlist(args.wordlist[1])
        if not wl1 or not wl2: return
        self.log(f"{ICONS['link']} Generating combinations... This might take a while.")
        # Limit combinations to prevent memory issues
        max_combinations = 1000000
        candidates = [f"{c[0]}{c[1]}" for c in itertools.islice(itertools.product(wl1, wl2), max_combinations)]
        self.log(f"{ICONS['success']} Generated {len(candidates):,} combinations (capped at {max_combinations}).")
        self.run_attack(args.hash, args.algo, candidates, args.salt, args.salt_pos, "Combinator Attack")

    def mask_attack(self, args):
        mask = args.mask
        # Handle custom character sets from argparse
        custom_sets = {}
        if hasattr(args, 'cs1') and args.cs1: custom_sets['?1'] = args.cs1
        if hasattr(args, 'cs2') and args.cs2: custom_sets['?2'] = args.cs2
        if hasattr(args, 'cs3') and args.cs3: custom_sets['?3'] = args.cs3
        if hasattr(args, 'cs4') and args.cs4: custom_sets['?4'] = args.cs4
        # Define standard mask characters
        mask_chars = {
            '?l': string.ascii_lowercase, '?u': string.ascii_uppercase, '?d': string.digits,
            '?s': "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~", # Common symbols
            '?a': string.ascii_letters + string.digits,
            '?b': string.ascii_letters + string.digits + "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~",
            '?1': custom_sets.get('?1', ''), '?2': custom_sets.get('?2', ''),
            '?3': custom_sets.get('?3', ''), '?4': custom_sets.get('?4', '')
        }
        # Find all placeholders in the mask
        placeholders = re.findall(r'\?.', mask)
        if not placeholders:
            self.log(f"{ICONS['error']} Invalid mask. No placeholders like ?l, ?d found.", "error")
            return
        # Get the character sets for each placeholder
        sets = [mask_chars.get(p, '') for p in placeholders]
        if any(not s for s in sets):
            self.log(f"{ICONS['error']} Invalid mask. Unknown character set placeholder detected.", "error")
            return
        self.log(f"{ICONS['target']} Mask attack with mask '{mask}' started...")
        # Calculate total for progress bar
        total_candidates = math.prod(len(s) for s in sets)
        self.log(f"{ICONS['warn']} Estimated candidates: {total_candidates:,}", "warning")
        self.running = True
        self.start_time = time.time()
        self.processed_count = 0
        self.total_candidates = total_candidates
        print("-" * 60)
        print(f"  {ICONS['target']} MASK ATTACK STARTED  ".center(60))
        print("-" * 60)
        pbar = ProgressBar(total_candidates)
        try:
            found = False
            # Iterate through all combinations of the mask
            for password_tuple in itertools.product(*sets):
                if not self.running: break
                password = "".join(password_tuple)
                computed_hash = self.core.hash_impl.hash_with_salt(args.algo, password, args.salt, args.salt_pos)
                if computed_hash and computed_hash.lower() == args.hash.lower():
                    pbar.done()
                    self.log(f"{ICONS['success']} Password found: {password}", "success")
                    self.save_to_potfile(args.hash, password, args.algo)
                    found = True
                    break
                self.processed_count += 1
                if self.processed_count % 1000 == 0:
                    pbar.update(1000)
            if not found:
                pbar.done()
                self.log(f"{ICONS['error']} Attack finished. Password not found.", "error")
        except KeyboardInterrupt:
            self.running = False
            pbar.done()
            self.log(f"{ICONS['warn']} Attack stopped by user.", "info")

    def ai_fuzzing_attack(self, args):
        base = args.base.strip()
        algo = self.core.detect_hash_type(args.hash)
        self.log(f"{ICONS['brain']} AI Fuzzing attack on {algo} hash...")
        # Generate AI candidates
        ai_candidates = self.core.ai_engine.generate_candidates(base, count=1000)
        # Generate Fuzz candidates
        fuzz_candidates = self.core.fuzzer.generate_variants(base)
        # Combine and deduplicate
        all_candidates = list(set(ai_candidates + fuzz_candidates))
        self.log(f"{ICONS['success']} Generated {len(all_candidates):,} AI + Fuzz variants.")
        self.run_attack(args.hash, algo, all_candidates, args.salt, args.salt_pos, "AI Fuzzing Attack")

    def analyze_hash(self, args):
        hash_str = args.hash
        detected_algo = self.core.detect_hash_type(hash_str)
        print(f"\n--- {ICONS['analyze']} CRYPTANALYTICAL REPORT ---")
        self.log(f"{ICONS['hash']} Input Hash: {hash_str}")
        self.log(f"{ICONS['target']} Detected Type: {detected_algo}", "success" if detected_algo != 'unknown' else "warning")
        try:
            entropy = self.core.hash_analyzer.calculate_entropy(hash_str)
            self.log(f"{ICONS['test']} Entropy (bits per character): {entropy:.2f}")
            if entropy > 4.0:
                self.log(f"{ICONS['warn']} Analysis: High entropy suggests a strong, random password.", "warning")
            else:
                self.log(f"{ICONS['success']} Analysis: Low entropy suggests a simple or non-random password.", "success")
        except binascii.Error:
            self.log(f"{ICONS['error']} Entropy analysis failed: Invalid hexadecimal hash.", "error")
        print("-" * 60)

    def potfile_viewer(self, args=None):
        if not self.potfile_path.exists():
            self.log(f"{ICONS['error']} Potfile does not exist. No hashes cracked yet.", "error")
            return
        try:
            with open(self.potfile_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            if not lines:
                print(f"\n{ICONS['warn']}" + "-" * 60)
                print(f"  {ICONS['warn']} POTFILE IS EMPTY  ".center(60))
                print("-" * 60)
                return
            print(f"\n{ICONS['view']}" + "-" * 60)
            print(f"  {ICONS['view']} POTFILE CONTENTS  ".center(60))
            print("-" * 60)
            for line in lines:
                parts = line.strip().split(':', 2)
                if len(parts) >= 3:
                    print(f"{ICONS['lock']} Hash: {parts[0]} -> Password: {parts[1]} ({parts[2]})")
                else:
                    print(f"{ICONS['error']} Invalid entry: {line.strip()}")
            print("-" * 60)
        except Exception as e:
            self.log(f"{ICONS['error']} Error reading potfile: {e}", "error")

    def interactive_menu(self):
        self.print_logo()
        while True:
            print("\n" + style_text("=" * 60, ANSICodes.MAGENTA))
            print(style_text(" MAIN MENU ".center(60, "="), ANSICodes.BOLD, ANSICodes.MAGENTA))
            print(style_text("=" * 60, ANSICodes.MAGENTA))
            print(f"{ICONS['file']} {style_text('1. Dictionary Attack', ANSICodes.CYAN)}")
            print(f"{ICONS['crack']} {style_text('2. Brute-Force Attack', ANSICodes.CYAN)}")
            print(f"{ICONS['brain']} {style_text('3. Rules-Based Attack', ANSICodes.CYAN)}")
            print(f"{ICONS['link']} {style_text('4. Combinator Attack', ANSICodes.CYAN)}")
            print(f"{ICONS['target']} {style_text('5. Mask Attack', ANSICodes.CYAN)}")
            print(f"{ICONS['brain']} {style_text('6. AI Fuzzing Attack', ANSICodes.CYAN)}")
            print(f"{ICONS['hash']} {style_text('7. Generate Hash', ANSICodes.YELLOW)}")
            print(f"{ICONS['analyze']} {style_text('8. Analyze a Hash', ANSICodes.YELLOW)}")
            print(f"{ICONS['view']} {style_text('9. View Potfile', ANSICodes.GREEN)}")
            print(f"{ICONS['folder']} {style_text('10. List Sessions', ANSICodes.GREEN)}")
            print(f"{ICONS['exit']} {style_text('11. Exit', ANSICodes.RED)}")
            print(style_text("=" * 60, ANSICodes.MAGENTA))
            choice = input(f"{ICONS['arrow']} Select an option (1-11): ").strip()
            if choice == "11":
                self.log(f"{ICONS['exit']} Exiting gracefully. Goodbye!", "success")
                break
            if choice in ['1', '2', '3', '4', '5', '6']:
                hash_to_crack = input(f"{ICONS['hash']} Enter the hash to crack: ").strip()
                detected_algo = self.core.detect_hash_type(hash_to_crack)
                if detected_algo != 'unknown':
                    self.log(f"{ICONS['success']} Detected hash type: {detected_algo}")
                    algorithm = detected_algo
                else:
                    algorithm = input(f"{ICONS['arrow']} Enter hash algorithm (e.g., md5, sha256): ").lower().strip()
                salt = input(f"{ICONS['lock']} Enter salt (optional): ").strip()
                salt_pos = input(f"{ICONS['arrow']} Enter salt position (prefix/suffix/both) [suffix]: ").strip() or 'suffix'
                if choice == '1':
                    wordlist_path = input(f"{ICONS['file']} Enter wordlist path [{self.config.get('Defaults', 'wordlist')}]: ").strip() or self.config.get('Defaults', 'wordlist')
                    wordlist = self.load_wordlist(wordlist_path)
                    if wordlist:
                        self.run_attack(hash_to_crack, algorithm, wordlist, salt, salt_pos, "Dictionary Attack")
                elif choice == '2':
                    chars = input(f"{ICONS['crack']} Enter character set [{string.ascii_letters + string.digits}]: ").strip() or string.ascii_letters + string.digits
                    try:
                        min_len = int(input(f"{ICONS['arrow']} Enter min length [1]: ").strip() or '1')
                        max_len = int(input(f"{ICONS['arrow']} Enter max length [8]: ").strip() or '8')
                    except ValueError:
                        self.log(f"{ICONS['warn']} Invalid length. Using defaults.", "warning")
                        min_len, max_len = 1, 8
                    self.brute_force_attack(argparse.Namespace(
                        hash=hash_to_crack, algo=algorithm, charset=chars, length=[min_len, max_len], salt=salt, salt_pos=salt_pos
                    ))
                elif choice == '3':
                    wordlist_path = input(f"{ICONS['file']} Enter wordlist path [{self.config.get('Defaults', 'wordlist')}]: ").strip() or self.config.get('Defaults', 'wordlist')
                    rules_path = input(f"{ICONS['brain']} Enter rules file path [{self.config.get('Defaults', 'rules')}]: ").strip() or self.config.get('Defaults', 'rules')
                    wordlist = self.load_wordlist(wordlist_path)
                    rules = self.load_wordlist(rules_path)
                    if wordlist and rules:
                        self.rules_based_attack(argparse.Namespace(
                            hash=hash_to_crack, algo=algorithm, wordlist=wordlist_path, rules=rules_path, salt=salt, salt_pos=salt_pos
                        ))
                elif choice == '4':
                    wl1_path = input(f"{ICONS['link']} Enter first wordlist path: ").strip()
                    wl2_path = input(f"{ICONS['link']} Enter second wordlist path: ").strip()
                    self.combinator_attack(argparse.Namespace(
                        hash=hash_to_crack, algo=algorithm, wordlist=[wl1_path, wl2_path], salt=salt, salt_pos=salt_pos
                    ))
                elif choice == '5':
                    mask = input(f"{ICONS['target']} Enter mask (e.g., ?l?l?d?d?d): ").strip()
                    # Get custom char sets
                    cs1 = input(f"{ICONS['arrow']} Enter custom charset ?1 (optional): ").strip()
                    cs2 = input(f"{ICONS['arrow']} Enter custom charset ?2 (optional): ").strip()
                    cs3 = input(f"{ICONS['arrow']} Enter custom charset ?3 (optional): ").strip()
                    cs4 = input(f"{ICONS['arrow']} Enter custom charset ?4 (optional): ").strip()
                    self.mask_attack(argparse.Namespace(
                        hash=hash_to_crack, algo=algorithm, mask=mask, salt=salt, salt_pos=salt_pos,
                        cs1=cs1, cs2=cs2, cs3=cs3, cs4=cs4
                    ))
                elif choice == '6': # AI Fuzzing
                    base = input(f"{ICONS['brain']} Enter base word for AI (e.g., admin): ").strip()
                    self.ai_fuzzing_attack(argparse.Namespace(
                        hash=hash_to_crack, base=base, salt=salt, salt_pos=salt_pos
                    ))
            elif choice == '7':
                text_to_hash = input(f"{ICONS['hash']} Enter the text to hash: ")
                algo_to_use = input(f"{ICONS['arrow']} Enter hash algorithm (e.g., md5, sha256): ")
                try:
                    hashed_text = self.core.hash_impl.hash_with_salt(algo_to_use, text_to_hash)
                    self.log(f"{ICONS['success']} Generated hash: {hashed_text}", "success")
                except Exception as e:
                    self.log(f"{ICONS['error']} Error generating hash: {e}", "error")
                input(f"\n{ICONS['arrow']} Press Enter to return to the menu...")
            elif choice == '8':
                hash_to_analyze = input(f"{ICONS['analyze']} Enter the hash to analyze: ")
                self.analyze_hash(argparse.Namespace(hash=hash_to_analyze))
                input(f"\n{ICONS['arrow']} Press Enter to return to the menu...")
            elif choice == '9':
                self.potfile_viewer()
                input(f"\n{ICONS['arrow']} Press Enter to return to the menu...")
            elif choice == '10':
                 sessions = self.session_manager.list_sessions()
                 if not sessions:
                     self.log(f"{ICONS['error']} No saved sessions found.", "error")
                     continue
                 print(f"\n{ICONS['folder']} --- SAVED SESSIONS ---")
                 for i, s in enumerate(sessions):
                     print(f"{i+1}. ID: {s['id']} | Created: {s['created'].strftime('%Y-%m-%d %H:%M')}")
                 try:
                     session_choice = int(input(f"{ICONS['arrow']} Enter session number to load (0 to cancel): ")) - 1
                     if session_choice == -1: continue
                     data = sessions[session_choice]['data']
                     self.log(f"{ICONS['success']} Session '{sessions[session_choice]['id']}' loaded.")
                     print(f"  {ICONS['hash']} Hash: {data.get('hash', 'N/A')}")
                     print(f"  {ICONS['target']} Algorithm: {data.get('algorithm', 'N/A')}")
                     print(f"  {ICONS['stats']} Status: {data.get('status', 'unknown')}")
                     if 'password' in data:
                         print(f"  {ICONS['success']} Password: {data['password']}")
                     input(f"{ICONS['arrow']} Press Enter to continue...")
                 except (ValueError, IndexError):
                     self.log(f"{ICONS['error']} Invalid session number.", "error")
            else:
                self.log(f"{ICONS['error']} Invalid choice.", "error")

    def main(self):
        # Ensure required directories exist
        Path("wordlists").mkdir(exist_ok=True)
        Path("rules").mkdir(exist_ok=True)
        Path("sessions").mkdir(exist_ok=True)
        if len(sys.argv) > 1:
            # Command Line Interface
            parser = argparse.ArgumentParser(description="A professional-grade hash cracking tool.")
            subparsers = parser.add_subparsers(dest='mode', help='Attack mode')
            # Dictionary Attack Parser
            dict_parser = subparsers.add_parser('dict', help='Perform a dictionary attack.')
            dict_parser.add_argument('-H', '--hash', required=True, help='The target hash to crack.')
            dict_parser.add_argument('-A', '--algo', required=True, help='The hash algorithm (e.g., md5, sha256).')
            dict_parser.add_argument('-W', '--wordlist', required=True, help='Path to the wordlist file.')
            dict_parser.add_argument('-S', '--salt', default="", help='Optional salt for the hash.')
            dict_parser.add_argument('-P', '--salt-pos', default="suffix", choices=['prefix', 'suffix', 'both'], help='Position of the salt.')
            dict_parser.set_defaults(func=self.dictionary_attack)
            # Brute-Force Attack Parser
            brute_parser = subparsers.add_parser('brute', help='Perform a brute-force attack.')
            brute_parser.add_argument('-H', '--hash', required=True, help='The target hash to crack.')
            brute_parser.add_argument('-A', '--algo', required=True, help='The hash algorithm.')
            brute_parser.add_argument('-C', '--charset', default=string.ascii_letters + string.digits, help='Character set to use.')
            brute_parser.add_argument('-L', '--length', nargs=2, type=int, default=[1, 8], metavar=('MIN', 'MAX'), help='Min and max password length.')
            brute_parser.add_argument('-S', '--salt', default="", help='Optional salt for the hash.')
            brute_parser.add_argument('-P', '--salt-pos', default="suffix", choices=['prefix', 'suffix', 'both'], help='Position of the salt.')
            brute_parser.set_defaults(func=self.brute_force_attack)
            # Mask Attack Parser
            mask_parser = subparsers.add_parser('mask', help='Perform a targeted mask attack.')
            mask_parser.add_argument('-H', '--hash', required=True, help='The target hash to crack.')
            mask_parser.add_argument('-A', '--algo', required=True, help='The hash algorithm.')
            mask_parser.add_argument('-M', '--mask', required=True, help='Mask to use (e.g., ?d?d?d?d for 4 digits).')
            mask_parser.add_argument('--cs1', help='Custom character set for ?1.')
            mask_parser.add_argument('--cs2', help='Custom character set for ?2.')
            mask_parser.add_argument('--cs3', help='Custom character set for ?3.')
            mask_parser.add_argument('--cs4', help='Custom character set for ?4.')
            mask_parser.add_argument('-S', '--salt', default="", help='Optional salt for the hash.')
            mask_parser.add_argument('-P', '--salt-pos', default="suffix", choices=['prefix', 'suffix', 'both'], help='Position of the salt.')
            mask_parser.set_defaults(func=self.mask_attack)
            # Rules-Based Attack Parser
            rules_parser = subparsers.add_parser('rules', help='Perform a rules-based attack.')
            rules_parser.add_argument('-H', '--hash', required=True, help='The target hash to crack.')
            rules_parser.add_argument('-A', '--algo', required=True, help='The hash algorithm.')
            rules_parser.add_argument('-W', '--wordlist', required=True, help='Path to the base wordlist.')
            rules_parser.add_argument('-R', '--rules', required=True, help='Path to the rules file.')
            rules_parser.add_argument('-S', '--salt', default="", help='Optional salt for the hash.')
            rules_parser.add_argument('-P', '--salt-pos', default="suffix", choices=['prefix', 'suffix', 'both'], help='Position of the salt.')
            rules_parser.set_defaults(func=self.rules_based_attack)
            # Combinator Attack Parser
            comb_parser = subparsers.add_parser('comb', help='Perform a combinator attack.')
            comb_parser.add_argument('-H', '--hash', required=True, help='The target hash to crack.')
            comb_parser.add_argument('-A', '--algo', required=True, help='The hash algorithm.')
            comb_parser.add_argument('wordlist', nargs=2, help='Paths to two wordlist files.')
            comb_parser.add_argument('-S', '--salt', default="", help='Optional salt for the hash.')
            comb_parser.add_argument('-P', '--salt-pos', default="suffix", choices=['prefix', 'suffix', 'both'], help='Position of the salt.')
            comb_parser.set_defaults(func=self.combinator_attack)
            # AI Fuzzing Attack Parser
            ai_parser = subparsers.add_parser('ai', help='Perform an AI-powered fuzzing attack.')
            ai_parser.add_argument('-H', '--hash', required=True, help='The target hash to crack.')
            ai_parser.add_argument('-B', '--base', default="", help='Base word for AI generation (e.g., admin).')
            ai_parser.add_argument('-S', '--salt', default="", help='Optional salt for the hash.')
            ai_parser.add_argument('-P', '--salt-pos', default="suffix", choices=['prefix', 'suffix', 'both'], help='Position of the salt.')
            ai_parser.set_defaults(func=self.ai_fuzzing_attack)
            # Analyze Hash Parser
            analyze_parser = subparsers.add_parser('analyze', help='Analyze a hash for cryptographic properties.')
            analyze_parser.add_argument('-H', '--hash', required=True, help='The hash to analyze.')
            analyze_parser.set_defaults(func=self.analyze_hash)
            # Potfile Viewer Parser
            potfile_parser = subparsers.add_parser('potfile', help='View cracked hashes in the potfile.')
            potfile_parser.set_defaults(func=self.potfile_viewer)
            args = parser.parse_args()
            if hasattr(args, 'func'):
                try:
                    args.func(args)
                except KeyboardInterrupt:
                    self.running = False
                    self.log(f"{ICONS['warn']} Attack stopped by user.", "info")
                except Exception as e:
                    self.log(f"{ICONS['error']} An unexpected error occurred: {e}", "error")
                    logger.exception("Error during CLI execution")
            else:
                parser.print_help()
        else:
            # Interactive Menu
            self.interactive_menu()

if __name__ == "__main__":
    cli = PyHashCrackerCLI()
    cli.main()
