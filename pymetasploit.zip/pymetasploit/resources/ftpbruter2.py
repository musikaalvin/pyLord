use postexploit/ftpbruter2
set RHOST 127.0.0.1
set WORDLIST ftpcreds.txt
run