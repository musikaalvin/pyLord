import pyfiglet,nmap
from collections import OrderedDict

MODULE_TYPE = "recon"
# Module class definition
class ModuleClass:
    def __init__(self):
        self.info = {
            'Name': 'Vulnerability Scanner',
            'Rank':'Good',
            'Platform':'Windows/Linux/Mac',
            'architectures':'x86/64 bit processors',
            'Description': 'Scans for common vulnerbilities ',
            'Author': 'pyLord@cyb3rH4ck3r',
            'Date Release': 'Tue/4/March/2025',
            'Options': OrderedDict([
            ('RHOST', ('', True,'Enter target IP')),
           
               
                ])
                }
    def logo(self):
    	title = 'Vulnerability Scanner'
    	if pyfiglet:
    	       ascii_text = pyfiglet.figlet_format(title, font="standard")
    	       print(f"\033[91m{ascii_text}\033[0m")
    	else:
            print(title)
    def help(self):
    	print("Usage: set RHOST <ip_address> , then run")
   
    def vulnerability_scanner(self,target_ip):
      nm = nmap.PortScanner()
      nm.scan(target_ip, arguments='-sV --script=vuln')
      for host in nm.all_hosts():
        print(f"Host: {host}")
        for proto in nm[host].all_protocols():
            print(f"Protocol: {proto}")
            ports = nm[host][proto].keys()
            for port in ports:
                print(f"Port: {port} State: {nm[host][proto][port]['state']}")
    
    
    def execute(self):
        self.logo()
        target_ip = self.info['Options']['RHOST'][0]
        self.vulnerability_scanner(target_ip)
        
        return f"[+] Scanning {target_ip} ..."
    